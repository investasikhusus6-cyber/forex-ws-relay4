import 'dotenv/config';
import http from 'node:http';
import { WebSocket, WebSocketServer } from 'ws';

const PORT = Number(process.env.PORT || 10000);
const API_KEY = process.env.TWELVEDATA_API_KEY;
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/') {
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ ok: true, service: 'forex-ws-relay', upstream: upstream?.readyState === WebSocket.OPEN ? 'connected' : 'connecting', clients: clients.size }));
    return;
  }
  res.writeHead(404); res.end('Not found');
});
const wss = new WebSocketServer({ noServer: true });
const clients = new Map(); // client -> Set of subscribed symbols
let upstream = null, reconnectTimer = null, heartbeatTimer = null, upstreamRetry = 0;
const symbols = new Set();

function send(client, obj) { if (client.readyState === WebSocket.OPEN) client.send(JSON.stringify(obj)); }
function refreshSymbols() {
  const next = new Set(); for (const set of clients.values()) for (const s of set) next.add(s);
  const added = [...next].filter(s => !symbols.has(s));
  const removed = [...symbols].filter(s => !next.has(s));
  symbols.clear(); for (const s of next) symbols.add(s);
  if (upstream?.readyState === WebSocket.OPEN) {
    if (added.length) upstream.send(JSON.stringify({ action: 'subscribe', params: { symbols: added.join(',') } }));
    if (removed.length) upstream.send(JSON.stringify({ action: 'unsubscribe', params: { symbols: removed.join(',') } }));
  }
}
function connectUpstream() {
  if (!API_KEY) { console.error('TWELVEDATA_API_KEY is missing'); return; }
  if (upstream && [WebSocket.OPEN, WebSocket.CONNECTING].includes(upstream.readyState)) return;
  clearTimeout(reconnectTimer);
  upstream = new WebSocket(`wss://ws.twelvedata.com/v1/quotes/price?apikey=${encodeURIComponent(API_KEY)}`);
  upstream.on('open', () => {
    upstreamRetry = 0;
    console.log('Connected to Twelve Data price stream');
    if (symbols.size) upstream.send(JSON.stringify({ action: 'subscribe', params: { symbols: [...symbols].join(',') } }));
    clearInterval(heartbeatTimer); heartbeatTimer = setInterval(() => { if (upstream?.readyState === WebSocket.OPEN) upstream.send(JSON.stringify({ action: 'heartbeat' })); }, 10000);
    for (const c of clients.keys()) send(c, { event: 'status', message: 'Relay tersambung ke penyedia data; menunggu tick.' });
  });
  upstream.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if ((msg.event === 'price' || msg.type === 'price' || (msg.price != null && msg.symbol)) && Number.isFinite(Number(msg.price))) {
      const symbol = String(msg.symbol || '').toUpperCase();
      for (const [client, subs] of clients) if (subs.has(symbol)) send(client, { event: 'price', symbol, price: Number(msg.price), timestamp: Number(msg.timestamp) || Math.floor(Date.now() / 1000) });
    } else if (msg.event === 'subscribe-status' || msg.status === 'error' || msg.event === 'error') {
      for (const c of clients.keys()) send(c, { ...msg, event: msg.event || 'error' });
      console.log('Provider message:', JSON.stringify(msg));
    }
  });
  upstream.on('error', e => console.error('Upstream WebSocket error:', e.message));
  upstream.on('close', () => {
    clearInterval(heartbeatTimer); upstream = null;
    const delay = Math.min(30000, 1000 * (2 ** Math.min(upstreamRetry++, 5)));
    reconnectTimer = setTimeout(connectUpstream, delay);
  });
}
server.on('upgrade', (req, socket, head) => {
  const origin = req.headers.origin;
  if (allowedOrigins.length && origin && !allowedOrigins.includes(origin)) { socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});
wss.on('connection', ws => {
  clients.set(ws, new Set());
  send(ws, { event: 'status', message: 'Terhubung ke relay; kirim simbol forex untuk berlangganan.' });
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { send(ws, { event: 'error', message: 'Pesan harus berupa JSON valid.' }); return; }
    if (msg.action === 'heartbeat') return;
    if (msg.action === 'subscribe') {
      const symbol = String(msg.symbol || '').toUpperCase().replace(/[^A-Z0-9/._:-]/g, '');
      if (!/^[A-Z]{3}\/[A-Z]{3}$/.test(symbol)) { send(ws, { event: 'error', message: 'Simbol tidak valid. Gunakan format EUR/USD.' }); return; }
      clients.get(ws).add(symbol); refreshSymbols(); connectUpstream();
      send(ws, { event: 'subscribe-status', status: 'requested', message: `Permintaan streaming ${symbol} dikirim.` });
    }
  });
  ws.on('close', () => { clients.delete(ws); refreshSymbols(); });
  ws.on('error', () => { clients.delete(ws); refreshSymbols(); });
});
server.listen(PORT, () => console.log(`Forex relay listening on port ${PORT}`));
if (!API_KEY) console.warn('Set TWELVEDATA_API_KEY in hosting environment.');
