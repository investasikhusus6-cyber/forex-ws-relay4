# Forex WebSocket Relay (Twelve Data → Vercel chart)

This service keeps the Twelve Data API key on the server and forwards price ticks to browser clients. Deploy this folder as a separate Node service (Render Web Service or Railway).

## Environment variables
- `TWELVEDATA_API_KEY`: your Twelve Data key (set in the host dashboard, not in GitHub).
- `ALLOWED_ORIGINS`: optional comma-separated exact frontend origins, e.g. `https://your-site.vercel.app`.
- `PORT`: supplied automatically by most hosts; default 10000.

## Deploy on Render
1. Put the `forex-ws-relay` folder in a GitHub repository. Do not commit `.env` or API keys.
2. Create a Render **Web Service** from that repository. Runtime: Node; Build command `npm install`; Start command `npm start`.
3. Add `TWELVEDATA_API_KEY` and `ALLOWED_ORIGINS` in Render → Environment.
4. Deploy, then open `https://YOUR-SERVICE.onrender.com/health`. It should return JSON with `ok: true`.
5. In the frontend `static/index.html`, replace `wss://YOUR-RENDER-RELAY.onrender.com` with `wss://YOUR-SERVICE.onrender.com`, commit, and redeploy Vercel.

## Protocol
Browser connects to the relay and sends `{"action":"subscribe","symbol":"USD/CAD"}`. Relay forwards only price events for symbols subscribed by that browser. `heartbeat` messages are accepted.

## Important
- Use the Twelve Data symbol format (`USD/CAD`, not Yahoo's `USDCAD=X`).
- Availability, real-time delay, symbol access, and connection limits depend on the Twelve Data plan.
- The `/health` endpoint reveals status only, never the API key.
- If your key was posted publicly or in a shared chat, rotate it in the provider dashboard.
