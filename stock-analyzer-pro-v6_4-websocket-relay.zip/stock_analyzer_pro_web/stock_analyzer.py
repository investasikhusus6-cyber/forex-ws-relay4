#!/usr/bin/env python3
"""
stock_analyzer.py v4 - Analisis saham 5 tahun + real-time + backtest + berita
+ riwayat fundamental + Monte Carlo + skor per kelompok.

Install : pip install yfinance pandas numpy
Contoh  : python stock_analyzer.py BBCA
          python stock_analyzer.py AAPL --market us
          python stock_analyzer.py TLKM BBRI --json
          python stock_analyzer.py BBCA --watch 120 --verbose
          python stock_analyzer.py BBCA --no-news --no-backtest
          python stock_analyzer.py BBCA --news-days 3 --benchmark ^JKSE

Catatan : Bukan nasihat keuangan. Tidak ada alat yang menjamin akurasi 99%.
          Berita hanya bisa MENURUNKAN vonis (rem risiko), tidak pernah menaikkannya.
"""

import argparse
import json
import logging
import re
import sys
import time
import xml.etree.ElementTree as ET
from bisect import bisect_right
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from math import erf, sqrt
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import URLError
from urllib.parse import quote_plus
from urllib.request import Request, urlopen

import numpy as np
import pandas as pd
import yfinance as yf

import data_sources as ds
from fair_value import estimate_fair_value
from fundamentals_history import build_history
from quant import calc_extras, chart_series, monte_carlo

LOG = logging.getLogger("stock_analyzer")

TRADING_DAYS = 252
MIN_ROWS = 30  # minimum for basic analysis; long-window features are gated separately
BENCHMARKS = {"id": "^JKSE", "us": "^GSPC"}
BACKTEST_CACHE: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
NEWS_CACHE: Dict[str, Tuple[float, Dict[str, Any]]] = {}

DEFAULTS: Dict[str, Any] = {
    "years": 5,
    "market": "id",
    "risk_free": 0.06,
    "buy_threshold": 65.0,
    "hold_threshold": 45.0,
    "min_watch_interval": 30,
    "backtest_years": 10,
    "horizon_days": 126,
    "sample_step": 21,
    "significance_alpha": 0.10,
    "max_stale_days": 5,
    "max_gap_days": 10,
    "max_daily_move_pct": 40.0,
    "max_live_deviation_pct": 25.0,
    "min_daily_value": 0.0,
    "benchmark": None,
    "run_backtest": True,
    "run_news": True,
    "news_days": 7,
    "news_min_items": 3,
    "news_show": 5,
    "news_timeout": 10,
    "news_cache_seconds": 600,
    # --- v4 ---
    "fast": False,                   # analisis cepat: tanpa backtest/riwayat/Monte Carlo/berita
    "run_history": True,
    "run_montecarlo": True,
    "mc_sims": 4000,
    "mc_block": 10,
    "mc_seed": 42,
    "time_budget": 40.0,             # detik; modul opsional dilewati bila terlampaui
    "chart_points": 160,
    "min_history_periods": 3,
    "cost_of_equity": {"id": 0.12, "us": 0.095},
    "group_weights": {"performa": 1.0, "teknikal": 1.0, "relatif": 0.6,
                      "fundamental": 1.4, "riwayat": 1.2, "berita": 0.3},
    "limits": {"pe": 1000.0, "pb": 1000.0, "der_pct": 10000.0},
    # --- harga wajar ---
    "run_fair_value": True,
    "terminal_growth": {"id": 0.045, "us": 0.03},   # pertumbuhan jangka panjang (nominal), asumsi
    "fair_value_mos": 0.25,                          # margin keamanan untuk harga masuk
    "fair_value_weights": None,                      # None = bobot bawaan fair_value.DEFAULT_WEIGHTS
    "fair_value_in_score": False,                    # True = ikut skor kelompok fundamental
    "validate_sources": True,                        # validasi silang antar sumber data (mode penuh saja)
}


# ----------------------------------------------------------------- config ---
def load_config(path: Optional[str]) -> Dict[str, Any]:
    cfg = dict(DEFAULTS)
    if not path:
        return cfg
    try:
        with open(path, "r", encoding="utf-8") as fh:
            user = json.load(fh)
        if not isinstance(user, dict):
            raise ValueError("isi config harus berupa object JSON")
        unknown = set(user) - set(DEFAULTS)
        if unknown:
            LOG.warning("Key config diabaikan: %s", ", ".join(sorted(unknown)))
        cfg.update({k: v for k, v in user.items() if k in DEFAULTS})
        LOG.debug("Config dimuat dari %s", path)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise SystemExit(f"Gagal membaca config '{path}': {exc}")
    return cfg


def setup_logging(verbose: bool, debug: bool, log_file: Optional[str]) -> None:
    level = logging.DEBUG if debug else (logging.INFO if verbose else logging.WARNING)
    fmt = "%(asctime)s | %(levelname)-7s | %(message)s"
    handlers: List[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    if log_file:
        try:
            handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
        except OSError as exc:
            raise SystemExit(f"Tidak bisa membuka log file '{log_file}': {exc}")
    logging.basicConfig(level=level, format=fmt, handlers=handlers)


# ------------------------------------------------------------------ cache ---
_TTL: Dict[Tuple[Any, ...], Tuple[float, Any]] = {}


def ttl_cache(seconds: float):
    """Cache in-process sederhana. Hasil kosong/None tidak disimpan (agar kegagalan tidak menempel)."""
    def deco(fn):
        def wrapper(*args, **kwargs):
            key = (fn.__name__,) + args + tuple(sorted(kwargs.items()))
            hit = _TTL.get(key)
            if hit and time.time() - hit[0] < seconds:
                val = hit[1]
            else:
                val = fn(*args, **kwargs)
                frame = isinstance(val, (pd.DataFrame, pd.Series))
                if frame or val:
                    _TTL[key] = (time.time(), val)
            return val.copy() if isinstance(val, (pd.DataFrame, pd.Series)) else val
        wrapper.__name__ = fn.__name__
        wrapper.__doc__ = fn.__doc__
        return wrapper
    return deco


_HIST_CACHE: Dict[Tuple[str, int], Tuple[float, Dict[str, Any]]] = {}


def build_history_cached(ticker: str, years: int, close: pd.Series, cfg: Dict[str, Any],
                         ttl: float = 1800.0) -> Dict[str, Any]:
    """Laporan keuangan jarang berubah: simpan 30 menit agar hitung ulang harga wajar cepat."""
    key = (ticker, int(years))
    hit = _HIST_CACHE.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    res = build_history(ticker, close, cfg)
    if res.get("available"):
        _HIST_CACHE[key] = (time.time(), res)
    return res


# ------------------------------------------------------------------- data ---
def normalize_ticker(raw: str, market: str) -> str:
    t = raw.strip().upper()
    if not t:
        raise ValueError("ticker kosong")
    if market == "id" and "." not in t and not t.startswith("^"):
        t += ".JK"
    return t


def to_naive(s: pd.Series) -> pd.Series:
    out = s.copy()
    idx = out.index
    if getattr(idx, "tz", None) is not None:
        idx = idx.tz_localize(None)
    out.index = idx.normalize()
    return out[~out.index.duplicated(keep="last")]


@ttl_cache(300)
def _fetch_history_cached(ticker: str, years: int, validate: bool) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    LOG.info("Mengambil histori %dy untuk %s (validasi=%s)", years, ticker, validate)
    return ds.get_history(ticker, years, MIN_ROWS, validate)


def fetch_history_ex(ticker: str, years: int, validate: bool = False) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """Histori OHLCV + meta sumber (utama, failover, validator). Melempar RuntimeError bila semua sumber gagal."""
    df, meta = _fetch_history_cached(ticker, years, validate)
    return df.copy(), meta


def fetch_history(ticker: str, years: int) -> pd.DataFrame:
    return fetch_history_ex(ticker, years, False)[0]


@ttl_cache(300)
def fetch_benchmark(symbol: str, years: int) -> Optional[pd.Series]:
    try:
        series = ds.get_benchmark(symbol, years)
        if series is None or series.empty:
            raise RuntimeError("kosong")
        return series
    except Exception as exc:
        LOG.warning("Benchmark %s tidak tersedia (%s)", symbol, exc)
        return None


_INFO_CACHE: Dict[Tuple[str, bool], Tuple[float, Tuple[Dict[str, Any], Dict[str, Any]]]] = {}


def fetch_info_ex(ticker: str, validate: bool = False) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Ringkasan fundamental (digabung antar sumber) + meta. Hasil kosong tidak disimpan di cache."""
    key = (ticker, validate)
    hit = _INFO_CACHE.get(key)
    if hit and time.time() - hit[0] < 300:
        return dict(hit[1][0]), hit[1][1]
    try:
        info, meta = ds.get_info(ticker, validate)
    except Exception as exc:
        LOG.warning("Fundamental tidak tersedia (%s)", exc)
        return {}, {"primary": None, "secondary": [], "filled": [], "conflicts": [], "errors": {"all": str(exc)[:120]}, "notes": []}
    if info:
        _INFO_CACHE[key] = (time.time(), (info, meta))
    return dict(info), meta


def fetch_info(ticker: str) -> Dict[str, Any]:
    return fetch_info_ex(ticker, False)[0]


def fetch_live_price_ex(ticker: str, fallback: float, validate: bool = False) -> Tuple[float, str, Dict[str, Any]]:
    """Harga terbaru + sumbernya ('fast_info' = Yahoo, atau nama sumber lain, atau 'close_terakhir')."""
    price, source, meta = ds.get_live_price(ticker, fallback, validate)
    if source == "close_terakhir":
        LOG.warning("Harga live tidak tersedia, pakai close terakhir")
    return price, source, meta


def fetch_live_price_with_source(ticker: str, fallback: float) -> Tuple[float, str]:
    """Ambil harga terakhir dan tandai sumbernya agar close historis tidak disebut live."""
    price, source, _ = fetch_live_price_ex(ticker, fallback, False)
    return price, source


def fetch_live_price(ticker: str, fallback: float) -> float:
    """Kompatibilitas untuk pemanggil lama."""
    return fetch_live_price_with_source(ticker, fallback)[0]


def with_live_price(close: pd.Series, price: float) -> pd.Series:
    tz = getattr(close.index, "tz", None)
    now = pd.Timestamp.now(tz=tz) if tz else pd.Timestamp.now()
    if close.index[-1].date() == now.date():
        out = close.copy()
        out.iloc[-1] = price
        return out
    return pd.concat([close, pd.Series([price], index=[now])])


# ----------------------------------------------------------------- berita ---
NEGATIONS = {"tidak", "tak", "bukan", "belum", "not", "no", "never", "without"}

LEXICON: Dict[str, float] = {
    # positif (id)
    "naik": 1, "menguat": 1, "untung": 1, "laba": 1, "tumbuh": 1, "positif": 1,
    "ekspansi": 1, "optimistis": 1, "optimis": 1, "outperform": 1, "melonjak": 2,
    "melesat": 2, "rekor": 2, "meroket": 2, "cuan": 1,
    # positif (en)
    "gain": 1, "gains": 1, "rally": 1, "beat": 1, "beats": 1, "growth": 1, "profit": 1,
    "upgrade": 1, "upgraded": 1, "bullish": 1, "strong": 1, "raises": 1, "expands": 1,
    "approval": 1, "surge": 2, "surges": 2, "soar": 2, "soars": 2, "jump": 1, "jumps": 1,
    "record": 1,
    # negatif (id)
    "turun": -1, "melemah": -1, "rugi": -2, "kerugian": -2, "negatif": -1, "tertekan": -1,
    "jatuh": -1, "koreksi": -1, "downgrade": -1, "bearish": -1, "gugatan": -1,
    "denda": -1, "sanksi": -2, "skandal": -2, "anjlok": -2, "merosot": -2, "ambruk": -2,
    "tekanan": -1, "waspada": -1,
    # negatif (en)
    "drop": -1, "drops": -1, "fall": -1, "falls": -1, "slump": -2, "slumps": -2,
    "miss": -1, "misses": -1, "loss": -1, "losses": -1, "lawsuit": -1, "probe": -1,
    "fine": -1, "fined": -1, "scandal": -2, "weak": -1, "cuts": -1, "warns": -1,
    "warning": -1, "recall": -1, "layoffs": -1, "plunge": -2, "plunges": -2,
    "plummet": -2, "plummets": -2, "downgraded": -1,
}

CRITICAL: List[Tuple[str, str]] = [
    ("suspensi/trading halt", r"\bsuspen(si|d|ded|sion)\b|\btrading halt\b|\bdihentikan sementara\b"),
    ("delisting", r"\bdelist"),
    ("gagal bayar/default", r"\bgagal bayar\b|\bdefault(s|ed)?\b"),
    ("pailit/PKPU/bangkrut", r"\bpailit\b|\bpkpu\b|\bbankrupt|\bbangkrut"),
    ("dugaan fraud/korupsi/manipulasi", r"\bfraud\b|\bpenipuan\b|\bkorupsi\b|\bembezzle|\bmanipulasi\b"),
    ("investigasi/penyelidikan", r"\binvestiga|\bpenyelidikan\b|\bpenyidikan\b|\bsubpoena\b"),
]

CATALYST: List[Tuple[str, str]] = [
    ("buyback", r"\bbuy ?back\b"),
    ("dividen", r"\bdividen\b|\bdividend\b"),
    ("akuisisi/merger", r"\bakuisisi\b|\bacquisition\b|\bmerger\b"),
    ("rights issue/stock split", r"\brights issue\b|\bstock split\b|\bsplit saham\b"),
]


def score_headline(title: str) -> Tuple[float, List[str], List[str]]:
    text = title.lower()
    tokens = re.findall(r"[a-z0-9']+", text)
    s = 0.0
    for i, tok in enumerate(tokens):
        w = LEXICON.get(tok)
        if w is None:
            continue
        if any(t in NEGATIONS for t in tokens[max(0, i - 2):i]):
            w = -w
        s += w
    crit = [name for name, pat in CRITICAL if re.search(pat, text)]
    cata = [name for name, pat in CATALYST if re.search(pat, text)]
    s -= 2 * len(crit)
    return max(-3.0, min(3.0, s)) / 3.0, crit, cata


def _news_yf(ticker: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    try:
        raw = yf.Ticker(ticker).news or []
    except Exception as exc:
        LOG.debug("yfinance news gagal: %s", exc)
        return out
    for it in raw:
        try:
            c = it.get("content") or it
            title = c.get("title")
            if not title:
                continue
            if c.get("pubDate"):
                pub = datetime.fromisoformat(str(c["pubDate"]).replace("Z", "+00:00"))
            elif it.get("providerPublishTime"):
                pub = datetime.fromtimestamp(int(it["providerPublishTime"]), timezone.utc)
            else:
                continue
            prov = c.get("provider")
            source = prov.get("displayName") if isinstance(prov, dict) else (it.get("publisher") or "Yahoo Finance")
            cu = c.get("canonicalUrl")
            url = (cu.get("url") if isinstance(cu, dict) else None) or it.get("link") or ""
            out.append({"title": str(title).strip(), "source": source or "Yahoo Finance",
                        "published": pub, "url": url})
        except (ValueError, TypeError, KeyError, AttributeError) as exc:
            LOG.debug("Item yfinance news dilewati: %s", exc)
    return out


def _news_google(query: str, market: str, timeout: int) -> List[Dict[str, Any]]:
    hl, gl, ceid = {"id": ("id", "ID", "ID:id"), "us": ("en-US", "US", "US:en")}.get(
        market, ("en-US", "US", "US:en"))
    url = f"https://news.google.com/rss/search?q={quote_plus(query)}&hl={hl}&gl={gl}&ceid={ceid}"
    out: List[Dict[str, Any]] = []
    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0 (stock_analyzer)"})
        with urlopen(req, timeout=timeout) as resp:
            data = resp.read()
        root = ET.fromstring(data)
    except (URLError, OSError, ET.ParseError, ValueError) as exc:
        LOG.warning("Google News RSS gagal: %s", exc)
        return out
    for item in root.iter("item"):
        try:
            title = (item.findtext("title") or "").strip()
            pub_raw = item.findtext("pubDate")
            if not title or not pub_raw:
                continue
            src_el = item.find("source")
            source = (src_el.text or "").strip() if src_el is not None and src_el.text else "Google News"
            if source and title.endswith(" - " + source):
                title = title[: -len(source) - 3]
            pub = parsedate_to_datetime(pub_raw)
            out.append({"title": title, "source": source, "published": pub,
                        "url": (item.findtext("link") or "").strip()})
        except (ValueError, TypeError) as exc:
            LOG.debug("Item RSS dilewati: %s", exc)
    return out


def _clean_name(name: str) -> str:
    n = re.sub(r"[\"']", "", name or "")
    n = re.sub(r"\b(Tbk|PT|Inc|Corp|Corporation|Ltd|Limited|Co|Company|Plc)\b\.?,?", "", n, flags=re.I)
    return re.sub(r"\s+", " ", n).strip(" ,.")


def _fmt_age(hours: float) -> str:
    return f"{int(hours)}j" if hours < 48 else f"{int(hours // 24)}h"


def fetch_news(ticker: str, info: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    ttl = float(cfg["news_cache_seconds"])
    cached = NEWS_CACHE.get(ticker)
    if cached and time.time() - cached[0] < ttl:
        LOG.debug("Berita %s dari cache", ticker)
        return cached[1]

    market = cfg["market"]
    code = ticker.replace(".JK", "")
    name = _clean_name(info.get("shortName") or info.get("longName") or "")
    terms = [f'"{code}"'] + ([f'"{name}"'] if name and name.upper() != code else [])
    query = f"({' OR '.join(terms)}) {'saham' if market == 'id' else 'stock'} when:{int(cfg['news_days'])}d"
    LOG.info("Query berita: %s", query)

    raw = _news_yf(ticker) + _news_google(query, market, int(cfg["news_timeout"]))
    now = datetime.now(timezone.utc)
    seen, items = set(), []
    for it in raw:
        pub = it["published"]
        if pub.tzinfo is None:
            pub = pub.replace(tzinfo=timezone.utc)
        pub = pub.astimezone(timezone.utc)
        age_h = (now - pub).total_seconds() / 3600
        if age_h < 0 or age_h > cfg["news_days"] * 24:
            continue
        key = re.sub(r"\W+", " ", it["title"].lower()).strip()[:80]
        if key in seen:
            continue
        seen.add(key)
        sent, crit, cata = score_headline(it["title"])
        items.append({"title": it["title"], "source": it["source"], "url": it["url"],
                      "published": pub.isoformat(timespec="minutes"), "age_hours": round(age_h, 1),
                      "sentiment": round(sent, 2), "critical": crit, "catalyst": cata})
    items.sort(key=lambda x: x["age_hours"])
    items = items[:40]

    if not items:
        res: Dict[str, Any] = {"available": False, "reason": "tidak ada berita ditemukan / sumber tidak terjangkau"}
    else:
        w_sum = s_sum = 0.0
        for it in items:
            w = 0.5 ** (it["age_hours"] / 24 / 3)     # waktu paruh 3 hari
            w_sum += w
            s_sum += w * it["sentiment"]
        score = s_sum / w_sum if w_sum else 0.0
        label = "POSITIF" if score >= 0.15 else ("NEGATIF" if score <= -0.15 else "NETRAL")
        res = {
            "available": True,
            "count": len(items),
            "sufficient": len(items) >= int(cfg["news_min_items"]),
            "score": round(score, 3),
            "label": label,
            "sources": len({i["source"] for i in items}),
            "critical_flags": [{"flag": f, "title": i["title"], "url": i["url"]}
                               for i in items for f in i["critical"]],
            "catalysts": sorted({c for i in items for c in i["catalyst"]}),
            "items": items,
        }
    NEWS_CACHE[ticker] = (time.time(), res)
    return res


# -------------------------------------------------------- validasi data ---
def check_data_quality(df: pd.DataFrame, price: float, cfg: Dict[str, Any], price_source: str = "fast_info",
                       sources: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    warnings: List[str] = []
    penalty = 0
    close = df["Close"]
    idx = to_naive(close).index

    if len(close) < 250:
        warnings.append(f"histori hanya {len(close)} hari; fitur jangka panjang (SMA200, Monte Carlo/backtest) terbatas")
        penalty += 10

    if (close <= 0).any():
        warnings.append("ada harga <= 0")
        penalty += 40

    stale = (pd.Timestamp.now().normalize() - idx[-1]).days
    if stale > cfg["max_stale_days"]:
        warnings.append(f"data terakhir {stale} hari lalu (basi / suspensi?)")
        penalty += 20

    gap = pd.Series(idx).diff().dt.days.max()
    if pd.notna(gap) and gap > cfg["max_gap_days"]:
        warnings.append(f"celah data {int(gap)} hari (kemungkinan suspensi)")
        penalty += 15

    rets = close.pct_change()
    mv = float(rets.abs().max() * 100)
    if mv > cfg["max_daily_move_pct"]:
        warnings.append(f"lonjakan harian {mv:.0f}% (split/aksi korporasi mungkin belum akurat)")
        penalty += 15

    flat = float((rets.fillna(0) == 0).mean() * 100)
    if flat > 40:
        warnings.append(f"{flat:.0f}% hari tanpa perubahan harga (likuiditas rendah)")
        penalty += 15

    dev = abs(price / float(close.iloc[-1]) - 1) * 100
    if dev > cfg["max_live_deviation_pct"]:
        warnings.append(f"harga live menyimpang {dev:.0f}% dari close terakhir")
        penalty += 20

    if price_source == "close_terakhir":
        warnings.append("Harga terbaru gagal diambil; analisis memakai harga penutupan terakhir, bukan harga live.")
        penalty += 10

    if sources:
        h = sources.get("history") or {}
        if h.get("failover"):
            fails = ", ".join(f"{a['source']} ({a['reason']})" for a in h["failover"])
            warnings.append(f"Sumber harga utama gagal: {fails}. Data memakai {h.get('primary')}.")
            penalty += 3
        if h.get("switched"):
            warnings.append(f"Sumber harga diganti dari {h['switched']['from']} ke {h['switched']['to']}: {h['switched']['reason']}.")
            penalty += 5
        for v in h.get("validators", []):
            if v.get("status") == "bad":
                warnings.append(f"Harga berbeda signifikan dengan {v['source']} (selisih harga terakhir "
                                f"{v.get('last_close_diff_pct') or 0:.1f}%, return harian maks {v.get('max_return_diff_pct') or 0:.1f}%).")
                penalty += 20
            elif v.get("status") == "warn":
                warnings.append(f"Ada selisih kecil dengan {v['source']} (harga terakhir {v.get('last_close_diff_pct') or 0:.1f}%, "
                                f"return harian maks {v.get('max_return_diff_pct') or 0:.1f}%); ex-dividen/split bisa menjelaskannya.")
                penalty += 8
        live = sources.get("live") or {}
        if live.get("status") == "bad":
            warnings.append(f"Harga live berbeda {live['max_dev_pct']:.1f}% antar sumber.")
            penalty += 10
        elif live.get("status") == "warn":
            warnings.append(f"Harga live berbeda {live['max_dev_pct']:.1f}% antar sumber.")
            penalty += 4
        fcon = (sources.get("fundamentals") or {}).get("conflicts") or []
        if fcon:
            warnings.append("Sumber fundamental berbeda pada: " + ", ".join(c["field"] for c in fcon) + ".")
            penalty += min(10, 3 * len(fcon))

    if cfg["min_daily_value"] > 0 and "Volume" in df:
        val = float((df["Close"] * df["Volume"]).tail(60).mean())
        if val < cfg["min_daily_value"]:
            warnings.append(f"nilai transaksi harian rata-rata {val:,.0f} di bawah minimum")
            penalty += 15

    score = max(0, 100 - penalty)
    grade = "ok" if score >= 85 else ("warn" if score >= 60 else "bad")
    return {"score": score, "grade": grade, "warnings": warnings, "price_source": price_source}


# ------------------------------------------------------------- indikator ---
def calc_rsi(close: pd.Series, period: int = 14) -> float:
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False).mean()
    if loss.iloc[-1] == 0:
        return 100.0
    return float(100 - 100 / (1 + gain.iloc[-1] / loss.iloc[-1]))


def calc_macd(close: pd.Series) -> Dict[str, float]:
    macd = close.ewm(span=12, adjust=False).mean() - close.ewm(span=26, adjust=False).mean()
    signal = macd.ewm(span=9, adjust=False).mean()
    return {"macd": float(macd.iloc[-1]), "signal": float(signal.iloc[-1])}


def calc_max_drawdown(close: pd.Series) -> float:
    peak = close.cummax()
    return float(((close - peak) / peak).min() * 100)


def calc_metrics(close: pd.Series, price: float, rf: float) -> Dict[str, float]:
    rets = close.pct_change().dropna()
    years = max((close.index[-1] - close.index[0]).days / 365.25, 0.1)
    cagr = ((close.iloc[-1] / close.iloc[0]) ** (1 / years) - 1) * 100
    vol = float(rets.std() * np.sqrt(TRADING_DAYS) * 100)
    ann_ret = float(rets.mean() * TRADING_DAYS)
    sharpe = (ann_ret - rf) / (vol / 100) if vol > 0 else 0.0
    downside = np.minimum(rets.to_numpy() - rf / TRADING_DAYS, 0.0)
    dd_dev = float(np.sqrt(np.mean(downside ** 2)) * np.sqrt(TRADING_DAYS))
    sortino = (ann_ret - rf) / dd_dev if dd_dev > 0 else 0.0
    max_dd = calc_max_drawdown(close)
    calmar = cagr / abs(max_dd) if max_dd < 0 else 0.0
    lo, hi = float(close.min()), float(close.max())
    pos = (price - lo) / (hi - lo) * 100 if hi > lo else 50.0
    macd = calc_macd(close)
    return {
        "price": float(price),
        "start_price": float(close.iloc[0]),
        "years": float(years),
        "total_return_pct": float((close.iloc[-1] / close.iloc[0] - 1) * 100),
        "cagr_pct": float(cagr),
        "volatility_pct": vol,
        "sharpe": float(sharpe),
        "sortino": float(sortino),
        "calmar": float(calmar),
        "max_drawdown_pct": max_dd,
        "sma50": (float(close.rolling(50).mean().iloc[-1]) if len(close) >= 50 else None),
        "sma200": (float(close.rolling(200).mean().iloc[-1]) if len(close) >= 200 else None),
        "rsi14": calc_rsi(close),
        "macd": macd["macd"],
        "macd_signal": macd["signal"],
        "low_5y": lo,
        "high_5y": hi,
        "range_pos_pct": float(pos),
    }


def calc_relative(close: pd.Series, bench: pd.Series) -> Optional[Dict[str, Any]]:
    a, b_full = to_naive(close), to_naive(bench)
    regime: Optional[bool] = None
    ret3m: Optional[float] = None
    if len(b_full) >= 200:
        sma = b_full.rolling(200).mean().iloc[-1]
        if np.isfinite(sma):
            regime = bool(b_full.iloc[-1] > sma)
    if len(b_full) > 64:
        ret3m = float((b_full.iloc[-1] / b_full.iloc[-64] - 1) * 100)
    common = a.index.intersection(b_full.index)
    if len(common) < 200:
        return None
    a, b = a.loc[common], b_full.loc[common]
    ra, rb = a.pct_change().dropna(), b.pct_change().dropna()
    var = float(rb.var())
    if var <= 0:
        return None
    beta = float(ra.cov(rb) / var)
    yrs = max((common[-1] - common[0]).days / 365.25, 0.1)
    cagr_a = ((a.iloc[-1] / a.iloc[0]) ** (1 / yrs) - 1) * 100
    cagr_b = ((b.iloc[-1] / b.iloc[0]) ** (1 / yrs) - 1) * 100
    return {"beta": beta, "bench_cagr_pct": float(cagr_b),
            "excess_cagr_pct": float(cagr_a - cagr_b), "corr": float(ra.corr(rb)),
            "bench_above_sma200": regime, "bench_ret_3m_pct": ret3m}


def extract_fundamentals(info: Dict[str, Any], limits: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
    lim = limits or DEFAULTS["limits"]

    def num(key: str) -> Optional[float]:
        try:
            v = float(info.get(key))
            return v if np.isfinite(v) else None
        except (TypeError, ValueError):
            return None

    def pct(key: str) -> Optional[float]:
        v = num(key)
        return v * 100 if v is not None else None

    pe = num("trailingPE")
    if pe is not None and pe > lim["pe"]:
        pe = None                                 # ekstrem: dianggap data tidak valid
    pb = num("priceToBook")
    if pb is not None and not (0 < pb < lim["pb"]):
        pb = None
    der = num("debtToEquity")
    if der is not None and not (0 <= der <= lim["der_pct"]):
        der = None
    dy = num("trailingAnnualDividendYield")
    if dy is None:
        dy = num("dividendYield")
        if dy is not None and dy > 0.5:
            dy = dy / 100
    if dy is not None and not (0 <= dy <= 1.0):
        dy = None
    eg = num("earningsGrowth")
    if eg is None:
        eg = num("earningsQuarterlyGrowth")
    n_an = num("numberOfAnalystOpinions")
    dps_val = num("trailingAnnualDividendRate")
    if dps_val is None:
        dps_val = num("dividendRate")
    return {
        "pe": pe,
        "eps": num("trailingEps"),
        "pb": pb,
        "roe_pct": pct("returnOnEquity"),
        "roa_pct": pct("returnOnAssets"),
        "net_margin_pct": pct("profitMargins"),
        "rev_growth_pct": pct("revenueGrowth"),
        "earn_growth_pct": eg * 100 if eg is not None else None,
        "der_pct": der,
        "div_yield_pct": dy * 100 if dy is not None else None,
        "peg": num("trailingPegRatio") if num("trailingPegRatio") is not None else num("pegRatio"),
        "target_mean": num("targetMeanPrice"),
        "analyst_n": int(n_an) if n_an is not None else None,
        "recommendation": info.get("recommendationKey") or None,
        "book_value": num("bookValue"),
        "dps": dps_val,
        "payout": num("payoutRatio"),
        "shares": num("sharesOutstanding"),
    }


CORE_FUND = ("pe", "pb", "roe_pct", "roa_pct", "net_margin_pct", "div_yield_pct")


def extract_profile(info: Dict[str, Any]) -> Dict[str, Any]:
    text = f"{info.get('sector', '')} {info.get('industry', '')} {info.get('longName', '')}".lower()
    if any(w in text for w in ("bank", "perbankan")):
        prof = "BANK"
    elif any(w in text for w in ("financial", "insurance", "capital markets", "credit services", "mortgage")):
        prof = "FINANCIAL"
    else:
        prof = "NON_FINANCIAL"
    try:
        mcap = float(info.get("marketCap"))
        mcap = mcap if np.isfinite(mcap) else None
    except (TypeError, ValueError):
        mcap = None
    return {"profile": prof, "name": info.get("longName") or info.get("shortName"),
            "sector": info.get("sector"), "industry": info.get("industry"),
            "currency": info.get("currency"), "financial_currency": info.get("financialCurrency"),
            "market_cap": mcap}


# --------------------------------------------------------------- scoring ---
@dataclass
class Criterion:
    name: str
    value: str
    score: int
    lo: int
    hi: int
    note: str
    group: str = "umum"


GROUP_OF = {
    "Pertumbuhan harga (CAGR)": "performa", "Return vs risiko (Sharpe)": "performa",
    "Penurunan terdalam": "performa", "Volatilitas tahunan": "performa",
    "Tren (SMA50/SMA200)": "teknikal", "RSI 14": "teknikal", "Momentum (MACD)": "teknikal",
    "Posisi di rentang historis": "teknikal", "Konfirmasi volume": "teknikal",
    "Kinerja vs indeks": "relatif", "Beta": "relatif", "Rezim pasar (indeks)": "relatif",
    "PER (valuasi laba)": "fundamental", "PBV (valuasi aset)": "fundamental",
    "PBV vs ROE (wajar)": "fundamental", "PEG": "fundamental", "ROE": "fundamental",
    "ROA": "fundamental", "Net margin": "fundamental", "Utang (DER)": "fundamental",
    "Dividend yield": "fundamental",
    "Harga vs harga wajar": "fundamental",
    "Konsistensi laba (tahun profit)": "riwayat", "ROE rata-rata (riwayat)": "riwayat",
    "CAGR laba bersih": "riwayat", "CAGR pendapatan": "riwayat",
    "Valuasi vs riwayat": "riwayat", "Kualitas laba (CFO/NI)": "riwayat",
    "Sentimen berita": "berita",
}
GROUP_LABEL = {
    "performa": "Kinerja harga", "teknikal": "Teknikal", "relatif": "Relatif vs indeks",
    "fundamental": "Fundamental (snapshot)", "riwayat": "Riwayat fundamental", "berita": "Berita",
}
GROUP_ORDER = ["performa", "teknikal", "relatif", "fundamental", "riwayat", "berita", "umum"]
EXTRA_KEYS = ("atr_pct", "vol_ratio", "ret_20d_pct", "high_52w", "low_52w", "from_high_52w_pct")


def band(value: float, cuts: List[float], scores: List[int]) -> int:
    return scores[bisect_right(cuts, value)]


def crit(name: str, value: str, score: int, scores: List[int], note: str) -> Criterion:
    return Criterion(name, value, score, min(scores), max(scores), note, GROUP_OF.get(name, "umum"))


def build_criteria(m: Dict[str, Any], f: Optional[Dict[str, Any]],
                   rel: Optional[Dict[str, Any]], fundamental: bool,
                   news: Optional[Dict[str, Any]] = None,
                   hist: Optional[Dict[str, Any]] = None,
                   profile: str = "NON_FINANCIAL", ke: float = 0.12,
                   min_hist: int = 3) -> List[Criterion]:
    out: List[Criterion] = []
    nonfin = profile == "NON_FINANCIAL"

    # ---------------- kinerja harga ----------------
    s = [-2, 0, 1, 2]
    out.append(crit("Pertumbuhan harga (CAGR)", f"{m['cagr_pct']:.1f}%/thn",
                    band(m["cagr_pct"], [0, 8, 15], s), s,
                    "Rata-rata kenaikan harga per tahun. >15% sangat kuat, <0% merugi."))
    out.append(crit("Return vs risiko (Sharpe)", f"{m['sharpe']:.2f}",
                    band(m["sharpe"], [0, 0.5, 1], s), s,
                    "Return di atas bunga bebas risiko per unit volatilitas. >1 bagus."))
    s = [-2, -1, 0, 1, 2]
    out.append(crit("Penurunan terdalam", f"{m['max_drawdown_pct']:.1f}%",
                    band(m["max_drawdown_pct"], [-60, -40, -25, -15], s), s,
                    "Kerugian terburuk dari puncak ke lembah dalam periode analisis."))
    s = [-2, -1, 1, 2]
    out.append(crit("Volatilitas tahunan", f"{m['volatility_pct']:.1f}%",
                    band(-m["volatility_pct"], [-50, -35, -20], s), s,
                    "Makin rendah makin stabil. >50% tergolong sangat liar."))

    # ---------------- teknikal ----------------
    sma50, sma200 = m.get("sma50"), m.get("sma200")
    s = [-2, 0, 2]
    if sma200 is not None and sma50 is not None:
        above200 = m["price"] > sma200
        golden = sma50 > sma200
        trend_detail = f"harga {'>' if above200 else '<='} SMA200, SMA50 {'>' if golden else '<='} SMA200"
        trend_score = (1 if above200 else -1) + (1 if golden else -1)
        trend_note = "Uptrend jika harga di atas SMA200 dan SMA50 di atas SMA200."
    elif sma50 is not None:
        above50 = m["price"] > sma50
        trend_detail = f"harga {'>' if above50 else '<='} SMA50; SMA200 belum tersedia"
        trend_score = 1 if above50 else -1
        trend_note = "Histori belum mencapai 200 hari; penilaian hanya memakai SMA50 dan keyakinan tren lebih rendah."
    else:
        trend_detail = "histori belum cukup untuk SMA50/SMA200"
        trend_score = 0
        trend_note = "Histori kurang dari 50 hari; sinyal tren dinetralkan karena data belum cukup."
    out.append(crit("Tren (SMA50/SMA200)", trend_detail, trend_score, s, trend_note))
    rsi = m["rsi14"]
    s = [1, 1, -1, -2]
    rsi_note = ("Jenuh jual (potensi murah, tapi bisa pisau jatuh)." if rsi < 30 else
                "Zona sehat." if rsi < 65 else
                "Mulai mahal/panas." if rsi < 75 else "Jenuh beli, rawan koreksi.")
    out.append(crit("RSI 14", f"{rsi:.1f}", band(rsi, [30, 65, 75], s), s, rsi_note))
    bullish = m["macd"] > m["macd_signal"]
    s = [-1, 1]
    out.append(crit("Momentum (MACD)", "bullish" if bullish else "bearish",
                    1 if bullish else -1, s, "MACD di atas garis sinyal = momentum naik."))
    s = [2, 1, 0, -1, -2]
    out.append(crit("Posisi di rentang historis", f"{m['range_pos_pct']:.0f}% dari low ke high",
                    band(m["range_pos_pct"], [25, 50, 75, 90], s), s,
                    "Makin dekat dasar makin murah relatif sejarahnya sendiri."))
    vr, r20 = m.get("vol_ratio"), m.get("ret_20d_pct")
    if vr is not None and r20 is not None:
        if vr >= 1.2 and r20 > 0:
            sc, note = 1, "Kenaikan 20 hari didukung volume di atas rata-rata."
        elif vr >= 1.2 and r20 < 0:
            sc, note = -1, "Penurunan 20 hari disertai volume tinggi (tekanan jual)."
        else:
            sc, note = 0, "Volume tidak memberi konfirmasi kuat ke salah satu arah."
        out.append(crit("Konfirmasi volume", f"vol 20h/120h {vr:.2f}x, harga 20h {r20:+.1f}%",
                        sc, [-1, 0, 1], note))

    # ---------------- relatif vs indeks ----------------
    if rel is not None:
        s = [-2, -1, 1, 2]
        out.append(crit("Kinerja vs indeks", f"{rel['excess_cagr_pct']:+.1f}%/thn vs indeks",
                        band(rel["excess_cagr_pct"], [-5, 0, 5], s), s,
                        f"Selisih CAGR terhadap indeks acuan (CAGR indeks {rel['bench_cagr_pct']:.1f}%)."))
        s = [1, 0, -1, -2]
        out.append(crit("Beta", f"{rel['beta']:.2f}", band(rel["beta"], [0.8, 1.2, 1.6], s), s,
                        "Sensitivitas terhadap pasar. >1.2 bergerak lebih liar dari indeks."))
        if rel.get("bench_above_sma200") is not None:
            up = bool(rel["bench_above_sma200"])
            out.append(crit("Rezim pasar (indeks)", "indeks di atas SMA200" if up else "indeks di bawah SMA200",
                            1 if up else -1, [-1, 1],
                            "Saham cenderung sulit naik melawan pasar yang sedang turun."))

    # ---------------- fundamental snapshot ----------------
    if fundamental and f is not None:
        pe, eps, pb = f.get("pe"), f.get("eps"), f.get("pb")
        if pe is not None and pe > 0:
            s = [2, 1, 0, -1, -2]
            out.append(crit("PER (valuasi laba)", f"{pe:.1f}x", band(pe, [10, 15, 25, 40], s), s,
                            "Makin rendah makin murah (bandingkan dengan rata-rata sektor)."))
        elif (pe is not None and pe <= 0) or (eps is not None and eps <= 0):
            out.append(crit("PER (valuasi laba)", "rugi (EPS negatif)", -2, [-2, 2],
                            "Perusahaan rugi: PER tidak bermakna, dihukum."))
        if pb is not None:
            s = [2, 1, 0, -1]
            out.append(crit("PBV (valuasi aset)", f"{pb:.2f}x", band(pb, [1, 2, 4], s), s,
                            "<1 di bawah nilai buku; >4 premium mahal."))
        roe = f.get("roe_pct")
        if roe is not None:
            s = [-2, -1, 0, 1, 2]
            out.append(crit("ROE", f"{roe:.1f}%", band(roe, [5, 10, 15, 20], s), s,
                            "Efisiensi laba dari modal. >15% bagus."))
        if pb is not None and roe is not None and roe > 0:
            fair = roe / (ke * 100)
            ratio = pb / fair
            s = [2, 1, -1, -2]
            out.append(crit("PBV vs ROE (wajar)", f"PBV {pb:.2f}x vs wajar {fair:.2f}x",
                            band(ratio, [0.8, 1.2, 1.8], s), s,
                            f"PBV wajar ~ ROE / biaya modal ({ke*100:.1f}%, asumsi). Rasio {ratio:.2f}x; <1 = lebih murah dari wajar."))
        roa = f.get("roa_pct")
        if roa is not None:
            s = [-2, -1, 1, 2]
            cuts = [0.5, 1.0, 2.0] if profile == "BANK" else [2.0, 5.0, 9.0]
            out.append(crit("ROA", f"{roa:.2f}%", band(roa, cuts, s), s,
                            "Efisiensi aset. Ambang bank lebih rendah daripada non-keuangan."))
        nm = f.get("net_margin_pct")
        if nm is not None and nonfin:
            s = [-2, -1, 1, 2]
            out.append(crit("Net margin", f"{nm:.1f}%", band(nm, [3, 8, 15], s), s,
                            "Laba bersih per rupiah pendapatan."))
        der = f.get("der_pct")
        if der is not None and nonfin:
            s = [2, 1, -1, -2]
            out.append(crit("Utang (DER)", f"{der:.0f}%", band(der, [50, 100, 200], s), s,
                            "Utang terhadap ekuitas. >200% berisiko."))
        dyv = f.get("div_yield_pct")
        if dyv is not None:
            s = [0, 0, 1, 2]
            out.append(crit("Dividend yield", f"{dyv:.2f}%", band(dyv, [1, 3, 5], s), s,
                            "Imbal hasil tunai tahunan. Tanpa dividen tidak dihukum."))
        peg = f.get("peg")
        hs = hist["summary"] if hist and hist.get("available") else None
        if peg is None and pe is not None and pe > 0 and hs and (hs.get("net_income_cagr") or 0) > 0.01:
            peg = pe / (hs["net_income_cagr"] * 100)
        if peg is not None and 0 < peg < 50:
            s = [2, 1, -1, -2]
            out.append(crit("PEG", f"{peg:.2f}", band(peg, [1, 2, 3], s), s,
                            "PER dibagi pertumbuhan laba. <1 murah relatif pertumbuhannya."))

    # ---------------- riwayat fundamental ----------------
    hs = hist["summary"] if hist and hist.get("available") else None
    if hs and hs.get("periods", 0) >= min_hist:
        frac = hs.get("profit_years_fraction")
        if frac is not None:
            s = [-2, -1, 1, 2]
            out.append(crit("Konsistensi laba (tahun profit)",
                            f"{hs['profit_years']}/{hs['profit_years_total']} tahun laba",
                            band(frac, [0.5, 0.75, 1.0], s), s, "Berapa tahun laporan dengan laba bersih positif."))
        if hs.get("roe_avg") is not None:
            s = [-2, -1, 0, 1, 2]
            out.append(crit("ROE rata-rata (riwayat)", f"{hs['roe_avg']*100:.1f}% ({hs['roe_n']} thn)",
                            band(hs["roe_avg"] * 100, [5, 10, 15, 20], s), s,
                            "Rata-rata ROE dari laporan tahunan, bukan hanya angka terbaru."))
        if hs.get("net_income_cagr") is not None:
            s = [-2, -1, 0, 1, 2]
            out.append(crit("CAGR laba bersih", f"{hs['net_income_cagr']*100:.1f}%/thn",
                            band(hs["net_income_cagr"] * 100, [-5, 3, 10, 20], s), s,
                            "Pertumbuhan majemuk laba bersih dari tahun pertama ke terakhir."))
        if hs.get("revenue_cagr") is not None:
            s = [-2, -1, 0, 1, 2]
            out.append(crit("CAGR pendapatan", f"{hs['revenue_cagr']*100:.1f}%/thn",
                            band(hs["revenue_cagr"] * 100, [-3, 3, 8, 15], s), s,
                            "Pertumbuhan majemuk pendapatan."))
        if fundamental and f is not None:
            order = [("PBV", "pb", "pbv_avg", "pbv_n"), ("PER", "pe", "per_avg", "per_n")]
            if nonfin:
                order.reverse()
            for label, ck, ak, nk in order:
                cur, avg_v = f.get(ck), hs.get(ak)
                if cur is not None and cur > 0 and avg_v and hs.get(nk, 0) >= 3:
                    ratio = cur / avg_v
                    s = [2, 1, -1, -2]
                    out.append(crit("Valuasi vs riwayat", f"{label} {cur:.2f} vs rata-rata {avg_v:.2f} ({ratio:.2f}x)",
                                    band(ratio, [0.8, 1.1, 1.4], s), s,
                                    "Valuasi sekarang dibanding rata-rata historis emiten sendiri."))
                    break
        if nonfin and hs.get("cfo_ni_avg") is not None and hs.get("cfo_ni_n", 0) >= 3:
            s = [-2, -1, 1, 2]
            out.append(crit("Kualitas laba (CFO/NI)", f"{hs['cfo_ni_avg']:.2f}x",
                            band(hs["cfo_ni_avg"], [0.6, 0.9, 1.2], s), s,
                            "Arus kas operasi per laba bersih. <0.6 = laba kurang didukung kas."))

    # ---------------- berita ----------------
    if news and news.get("available") and news.get("sufficient"):
        s = [-1, -1, 0, 1, 1]
        out.append(crit("Sentimen berita", f"{news['label']} ({news['score']:+.2f}, {news['count']} berita)",
                        band(news["score"], [-0.4, -0.15, 0.15, 0.4], s), s,
                        "Skor kamus kata judul berita, bobot kecil karena kasar dan tidak di-backtest."))
    return out


def verdict(criteria: List[Criterion], cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Skor gabungan = rata-rata tertimbang skor tiap kelompok (0-100).
    Kelompok yang datanya tidak ada dilewati, bukan dihitung nol."""
    gw = cfg.get("group_weights", {})
    groups: Dict[str, List[int]] = {}
    for c in criteria:
        g = groups.setdefault(c.group, [0, 0, 0])
        g[0] += c.score
        g[1] += c.lo
        g[2] += c.hi
    sub: Dict[str, float] = {}
    num = den = 0.0
    for name, (sc, lo, hi) in groups.items():
        if hi <= lo:
            continue
        p = (sc - lo) / (hi - lo) * 100
        sub[name] = round(p, 1)
        w = float(gw.get(name, 1.0))
        num += w * p
        den += w
    pct = num / den if den else 0.0
    if pct >= cfg["buy_threshold"]:
        label = "LAYAK BELI"
    elif pct >= cfg["hold_threshold"]:
        label = "TAHAN / PANTAU"
    else:
        label = "TIDAK LAYAK BELI"
    return {"score_pct": round(pct, 1), "raw": sum(c.score for c in criteria),
            "min": sum(c.lo for c in criteria), "max": sum(c.hi for c in criteria),
            "label": label, "groups": sub}


# -------------------------------------------------------------- backtest ---
def _edge(hit: pd.Series, base: float, step: int, h: int, alpha: float) -> Dict[str, Any]:
    n = len(hit)
    if n == 0 or not (0 < base < 1):
        return {"edge_pct": None, "n_eff": 0.0, "p_value": None, "significant": False}
    edge = float(hit.mean()) - base
    n_eff = max(1.0, n * min(1.0, step / h))      # koreksi window yang tumpang tindih
    z = edge / sqrt(base * (1 - base) / n_eff)
    p = 0.5 * (1 - erf(z / sqrt(2)))
    return {"edge_pct": edge * 100, "n_eff": float(n_eff), "p_value": float(p),
            "significant": bool(edge > 0 and p < alpha)}


def _naive_index(ix: Any) -> pd.DatetimeIndex:
    ix = pd.DatetimeIndex(ix)
    if ix.tz is not None:
        ix = ix.tz_localize(None)
    return ix.normalize()


def run_backtest(close: pd.Series, cfg: Dict[str, Any], bench: Optional[pd.Series] = None) -> Dict[str, Any]:
    """Walk-forward tanpa look-ahead. Hanya komponen harga/teknikal: fundamental, berita,
    dan volume historis point-in-time tidak tersedia gratis.
    Sukses = return ke depan > bunga bebas risiko; 'beat' = mengalahkan indeks acuan."""
    h, step = int(cfg["horizon_days"]), int(cfg["sample_step"])
    rf = float(cfg["risk_free"])
    alpha = float(cfg["significance_alpha"])
    win = int(cfg["years"]) * TRADING_DAYS
    warm = 252
    n = len(close)
    if n < warm + h + step:
        return {"available": False, "reason": f"histori {n} hari terlalu pendek untuk backtest"}

    rf_h = (1 + rf) ** (h / TRADING_DAYS) - 1
    rows = []
    for i in range(warm, n - h, step):
        hist = close.iloc[max(0, i + 1 - win): i + 1]
        try:
            m = calc_metrics(hist, float(hist.iloc[-1]), rf)
            label = verdict(build_criteria(m, None, None, False), cfg)["label"]
        except Exception as exc:
            LOG.debug("Backtest titik %d dilewati: %s", i, exc)
            continue
        rows.append((close.index[i], close.index[i + h], label, float(close.iloc[i + h] / close.iloc[i] - 1)))
    if not rows:
        return {"available": False, "reason": "tidak ada titik sinyal valid"}

    bt = pd.DataFrame(rows, columns=["d0", "d1", "label", "fwd"])
    bt["hit"] = bt["fwd"] > rf_h
    base = float(bt["hit"].mean())

    has_bench = False
    if bench is not None and len(bench) > 100:
        b = to_naive(bench).sort_index()
        b0 = b.reindex(_naive_index(bt["d0"]), method="ffill").to_numpy()
        b1 = b.reindex(_naive_index(bt["d1"]), method="ffill").to_numpy()
        with np.errstate(divide="ignore", invalid="ignore"):
            bt["bfwd"] = b1 / b0 - 1
        bt["valid_b"] = np.isfinite(bt["bfwd"])
        bt["beat"] = bt["fwd"] > bt["bfwd"]
        has_bench = bool(bt["valid_b"].sum() >= 10)

    buckets: Dict[str, Dict[str, float]] = {}
    for label, g in bt.groupby("label"):
        bk = {"n": int(len(g)), "hit_rate_pct": float(g["hit"].mean() * 100),
              "avg_fwd_pct": float(g["fwd"].mean() * 100),
              "median_fwd_pct": float(g["fwd"].median() * 100)}
        if has_bench:
            gv = g[g["valid_b"]]
            if len(gv):
                bk["beat_rate_pct"] = float(gv["beat"].mean() * 100)
        buckets[label] = bk

    res: Dict[str, Any] = {"available": True, "samples": int(len(bt)), "horizon_days": h,
                           "base_rate_pct": base * 100, "buckets": buckets,
                           "buy_edge_pct": None, "p_value": None, "significant": False, "n_eff": 0.0,
                           "has_benchmark": has_bench, "base_beat_pct": None,
                           "buy_beat_edge_pct": None, "beat_p_value": None, "significant_beat": False}
    buy = bt[bt["label"] == "LAYAK BELI"]
    if len(buy) > 0:
        e = _edge(buy["hit"], base, step, h, alpha)
        res.update(buy_edge_pct=e["edge_pct"], p_value=e["p_value"],
                   significant=e["significant"], n_eff=e["n_eff"])
        if has_bench:
            valid = bt[bt["valid_b"]]
            base_beat = float(valid["beat"].mean())
            res["base_beat_pct"] = base_beat * 100
            bv = buy[buy["valid_b"]]
            if len(bv):
                eb = _edge(bv["beat"], base_beat, step, h, alpha)
                res.update(buy_beat_edge_pct=eb["edge_pct"], beat_p_value=eb["p_value"],
                           significant_beat=eb["significant"])
    elif has_bench:
        res["base_beat_pct"] = float(bt[bt["valid_b"]]["beat"].mean() * 100)
    return res


def assess_confidence(dq: Dict[str, Any], bt: Optional[Dict[str, Any]],
                      f: Dict[str, Any], full_v: Dict[str, Any],
                      tech_v: Dict[str, Any], news: Optional[Dict[str, Any]],
                      hist: Optional[Dict[str, Any]] = None,
                      skipped: Optional[List[str]] = None,
                      min_hist: int = 3,
                      data_sources: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    pts = 0
    reasons: List[str] = []

    if dq["grade"] == "ok":
        pts += 1
        reasons.append("+1 kualitas data baik")
    elif dq["grade"] == "bad":
        pts -= 2
        reasons.append("-2 kualitas data buruk")
    else:
        reasons.append("0 kualitas data ada peringatan")

    if bt and bt.get("available") and bt.get("buy_edge_pct") is not None and bt.get("n_eff", 0) >= 3:
        if bt["significant"]:
            pts += 2
            reasons.append("+2 sinyal BUY historis terbukti unggul secara statistik")
        elif bt["buy_edge_pct"] <= 0:
            pts -= 2
            reasons.append("-2 sinyal BUY historis tidak mengalahkan base rate")
        else:
            reasons.append("0 keunggulan sinyal BUY historis belum signifikan")
        if bt.get("significant_beat"):
            pts += 1
            reasons.append("+1 sinyal BUY historis juga unggul atas indeks acuan")
    else:
        reasons.append("0 backtest tidak cukup sampel / dilewati")

    filled = sum(1 for k in CORE_FUND if f.get(k) is not None)
    if filled >= 3:
        pts += 1
        reasons.append("+1 data fundamental snapshot memadai")
    else:
        reasons.append("0 data fundamental snapshot minim")

    periods = (hist or {}).get("summary", {}).get("periods", 0) if hist and hist.get("available") else 0
    if periods >= min_hist:
        pts += 1
        reasons.append(f"+1 riwayat laporan {periods} periode tersedia")
    else:
        reasons.append("0 riwayat laporan tahunan kurang / dilewati")

    if tech_v["label"] == full_v["label"]:
        pts += 1
        reasons.append("+1 sinyal teknikal dan gabungan sepakat")
    else:
        reasons.append("0 sinyal teknikal dan gabungan berbeda")

    if news and news.get("available") and news.get("critical_flags"):
        pts -= 1
        reasons.append(f"-1 ada {len(news['critical_flags'])} penanda berita berisiko tinggi")
    elif news and news.get("available") and news.get("sufficient"):
        reasons.append("0 berita memadai, tanpa penanda risiko tinggi")
    else:
        reasons.append("0 berita tidak memadai / dilewati")

    dsrc = data_sources or {}
    judged = [v for v in (dsrc.get("history") or {}).get("validators", []) if v.get("status") in ("ok", "warn", "bad")]
    if judged:
        if any(v["status"] == "bad" for v in judged):
            pts -= 1
            reasons.append("-1 sumber data harga berbeda signifikan")
        elif all(v["status"] == "ok" for v in judged):
            pts += 1
            reasons.append(f"+1 harga divalidasi silang oleh {len(judged)} sumber lain")
        else:
            reasons.append("0 validasi silang harga: ada selisih kecil")
    elif dsrc.get("validation_enabled"):
        reasons.append("0 harga hanya dari satu sumber (belum divalidasi silang)")
    if (dsrc.get("fundamentals") or {}).get("conflicts"):
        pts -= 1
        reasons.append(f"-1 sumber fundamental berbeda pada {len(dsrc['fundamentals']['conflicts'])} field")

    if skipped:
        pts -= 1
        reasons.append("-1 modul dilewati karena batas waktu: " + ", ".join(skipped))

    label = "TINGGI" if pts >= 5 else ("SEDANG" if pts >= 2 else "RENDAH")
    return {"label": label, "points": pts, "reasons": reasons}


# ---------------------------------------------------------------- output ---
def _p(x: Optional[float], d: int = 1, suf: str = "%") -> str:
    return "n/a" if x is None else f"{x:.{d}f}{suf}"


def render(r: Dict[str, Any], cfg: Dict[str, Any]) -> str:
    m, v, dq, bt, conf = r["metrics"], r["verdict"], r["data_quality"], r["backtest"], r["confidence"]
    news, hist, mc, prof = r["news"], r["history"], r["montecarlo"], r["profile"]
    criteria: List[Criterion] = r["_criteria_obj"]
    L: List[str] = []
    bar = "=" * 78
    L += [bar, f" ANALISIS {r['ticker']}  {prof.get('name') or ''}   |   {datetime.now():%Y-%m-%d %H:%M:%S}", bar]
    L.append(f" Profil {prof['profile']} | Sektor {prof.get('sector') or 'n/a'} | Industri {prof.get('industry') or 'n/a'}")
    L.append(f" Harga live       : {m['price']:,.2f}   (high/low 52 minggu {_p(m.get('high_52w'), 2, '')} / {_p(m.get('low_52w'), 2, '')})")
    L.append(f" Periode          : {m['years']:.1f} tahun (awal {m['start_price']:,.2f})")
    L.append(f" Return total     : {m['total_return_pct']:+.1f}%   CAGR {m['cagr_pct']:+.1f}%/thn")
    L.append(f" Risiko           : vol {m['volatility_pct']:.1f}%  Sharpe {m['sharpe']:.2f}  Sortino {m['sortino']:.2f}  "
             f"Calmar {m['calmar']:.2f}  ATR14 {_p(m.get('atr_pct'))}")
    L.append("-" * 78)
    for g in GROUP_ORDER:
        items = [c for c in criteria if c.group == g]
        if not items:
            continue
        sc = v["groups"].get(g)
        L.append(f" [{GROUP_LABEL.get(g, g)}]  skor kelompok {_p(sc, 0, '')}/100")
        for c in items:
            mark = "+" if c.score > 0 else ("-" if c.score < 0 else "=")
            L.append(f"  [{mark}] {c.name:<31} {c.value:<38} ({c.score:+d})")
            L.append(f"        {c.note}")
    L.append("-" * 78)

    fv = r.get("fair_value")
    L.append(" HARGA WAJAR (estimasi multi-metode, bukan target harga)")
    if fv and fv.get("available"):
        a = fv["assumptions"]
        L.append(f"   Harga wajar dasar {fv['base']:,.2f}  (rentang metode {fv['low']:,.2f} - {fv['high']:,.2f})  |  harga sekarang {fv['current_price']:,.2f}")
        L.append(f"   {fv['label']}: potensi {fv['upside_pct']:+.1f}% ke harga wajar | harga masuk margin keamanan {a['mos']*100:.0f}%: {fv['mos_price']:,.2f}")
        L.append(f"   Keyakinan estimasi {fv['confidence']['label']} | asumsi: biaya modal {a['ke']*100:.1f}%, pertumbuhan jangka panjang {a['g']*100:.1f}%")
        for mth in fv["methods"]:
            tag = "dipakai " if mth["included"] else "dikecualikan"
            L.append(f"   [{tag}] {mth['name']:<26} {mth['price']:>12,.2f}  bobot {mth['weight']:.1f}"
                     + ("" if mth["included"] else f"  ({mth['excluded_reason']})"))
        for u in fv["unavailable"]:
            L.append(f"   [tidak dihitung] {u['name']:<22} {u['reason']}")
        for fl in fv["flags"]:
            L.append(f"   ! {fl}")
    else:
        L.append(f"   Belum bisa dihitung: {(fv or {}).get('reason') or 'dilewati'}")
        for ind in (fv or {}).get("indications", []):
            L.append(f"   indikasi tunggal {ind['name']}: {ind['price']:,.2f}")
    L.append("-" * 78)

    if r["risk_flags"]:
        L.append(" RISK / WARNING:")
        for fl in r["risk_flags"]:
            L.append(f"   ! {fl}")
        L.append("-" * 78)

    if hist and hist.get("available"):
        s = hist["summary"]
        L.append(f" RIWAYAT FUNDAMENTAL ({s['periods']} laporan tahunan)")
        for row in hist["rows"]:
            L.append(f"   {row['year']} {row['period']:<3} pendapatan {_p(row['revenue'] and row['revenue'] / 1e9, 0, 'M'):>10} "
                     f"laba {_p(row['net_income'] and row['net_income'] / 1e9, 0, 'M'):>9} "
                     f"ROE {_p(row['roe'] and row['roe'] * 100):>7} NPM {_p(row['npm'] and row['npm'] * 100):>7}")
        L.append(f"   CAGR laba {_p(s.get('net_income_cagr') and s['net_income_cagr'] * 100)} | "
                 f"CAGR pendapatan {_p(s.get('revenue_cagr') and s['revenue_cagr'] * 100)} | "
                 f"tahun laba {s['profit_years']}/{s['profit_years_total']}")
    else:
        L.append(f" RIWAYAT FUNDAMENTAL: tidak tersedia ({(hist or {}).get('reason') or 'dilewati'})")
    L.append("-" * 78)

    if mc and mc.get("available"):
        L.append(f" MONTE CARLO {mc['horizon_days']} hari ({mc['sims']} simulasi, block bootstrap) - sebaran, bukan prediksi")
        for key, name in (("neutral_drift", "netral (tanpa tren)"), ("historical_drift", "jika tren historis berulang")):
            d = mc[key]
            L.append(f"   {name:<28} P5 {d['p5']:+.1f}%  P25 {d['p25']:+.1f}%  P50 {d['p50']:+.1f}%  "
                     f"P75 {d['p75']:+.1f}%  P95 {d['p95']:+.1f}%")
            L.append(f"   {'':<28} peluang rugi {d['prob_loss_pct']:.0f}%, rugi >15% {d['prob_loss_15_pct']:.0f}%, "
                     f"untung >10% {d['prob_gain_10_pct']:.0f}%")
    else:
        L.append(f" MONTE CARLO: tidak tersedia ({(mc or {}).get('reason') or 'dilewati'})")
    L.append("-" * 78)

    if news and news.get("available"):
        L.append(f" BERITA        : {news['count']} berita/{cfg['news_days']} hari dari {news['sources']} sumber | "
                 f"sentimen {news['label']} ({news['score']:+.2f})"
                 + ("" if news["sufficient"] else "  [kurang dari minimum, tidak dihitung]"))
        for it in news["items"][: int(cfg["news_show"])]:
            mk = "+" if it["sentiment"] > 0.1 else ("-" if it["sentiment"] < -0.1 else "=")
            title = it["title"] if len(it["title"]) <= 70 else it["title"][:67] + "..."
            L.append(f"   [{mk}] {_fmt_age(it['age_hours']):>4} {it['source'][:16]:<16} {title}")
        if news["catalysts"]:
            L.append(f"   * Katalis terdeteksi: {', '.join(news['catalysts'])}")
    else:
        L.append(f" BERITA        : tidak tersedia ({(news or {}).get('reason') or 'dilewati'})")
    L.append("-" * 78)

    src = r.get("data_sources") or {}
    hm = src.get("history") or {}
    if hm:
        L.append(f" SUMBER DATA   : harga {hm.get('primary')} | aktif: {', '.join(src.get('providers_active', [])) or '-'}"
                 f" | statement {((src.get('statements') or {}).get('source')) or '-'}")
        for vd in hm.get("validators", []):                 # bukan 'v': nama itu dipakai untuk vonis
            L.append(f"   validator {vd['source']:<13} {vd['status']:<10} selisih harga terakhir "
                     f"{_p(vd.get('last_close_diff_pct'), 2)} | return harian maks {_p(vd.get('max_return_diff_pct'), 2)} ({vd.get('common_days', 0)} hari)")
        if not hm.get("validators"):
            L.append("   belum divalidasi silang (hanya satu sumber aktif, mode cepat, atau validasi dimatikan)")
        for c in (src.get("fundamentals") or {}).get("conflicts", []):
            L.append(f"   konflik fundamental {c['field']}: " + ", ".join(f"{k}={v:,.4g}" for k, v in c["values"].items()))
    L.append(f" VALIDASI DATA : skor {dq['score']}/100 ({dq['grade']})")
    for w in dq["warnings"]:
        L.append(f"   ! {w}")
    L.append("-" * 78)
    if bt and bt.get("available"):
        L.append(f" BACKTEST      : {bt['samples']} titik sinyal, horizon {bt['horizon_days']} hari, "
                 f"base rate untung > bunga bebas risiko {bt['base_rate_pct']:.0f}%"
                 + (f", base rate mengalahkan indeks {bt['base_beat_pct']:.0f}%" if bt.get("base_beat_pct") is not None else ""))
        for lab in ("LAYAK BELI", "TAHAN / PANTAU", "TIDAK LAYAK BELI"):
            b = bt["buckets"].get(lab)
            if b:
                L.append(f"   {lab:<18} n={b['n']:<3} hit {b['hit_rate_pct']:.0f}%  "
                         f"rata-rata {b['avg_fwd_pct']:+.1f}%  median {b['median_fwd_pct']:+.1f}%"
                         + (f"  mengalahkan indeks {b['beat_rate_pct']:.0f}%" if b.get("beat_rate_pct") is not None else ""))
        if bt["buy_edge_pct"] is not None:
            p = f"{bt['p_value']:.3f}" if bt["p_value"] is not None else "n/a"
            L.append(f"   Keunggulan sinyal BUY vs base rate: {bt['buy_edge_pct']:+.1f} poin (p={p}, "
                     f"sampel efektif {bt['n_eff']:.1f})")
            if bt.get("buy_beat_edge_pct") is not None:
                L.append(f"   Keunggulan BUY mengalahkan indeks: {bt['buy_beat_edge_pct']:+.1f} poin "
                         f"(p={bt['beat_p_value']:.3f})")
        else:
            L.append("   Tidak ada sinyal BUY pada histori saham ini.")
        L.append("   Backtest hanya menguji komponen harga/teknikal (fundamental, berita, volume tidak diuji).")
    else:
        L.append(f" BACKTEST      : tidak tersedia ({(bt or {}).get('reason') or 'dilewati'})")
    L.append("-" * 78)
    L.append(f" SKOR     : {v['score_pct']:.1f}/100  (rata-rata tertimbang per kelompok)")
    L.append(f" KEYAKINAN: {conf['label']}  (poin {conf['points']})")
    for rs in conf["reasons"]:
        L.append(f"   {rs}")
    L.append(f" VONIS    : {v['final_label']}")
    for dr in v["downgrade_reasons"]:
        L.append(f"   (diturunkan dari {v['label']}: {dr})")
    L.append("-" * 78)
    L.append(" Bukan nasihat keuangan. Berita dan keyakinan hanya bisa menurunkan vonis, tidak menaikkannya.")
    L.append(" Keyakinan mengukur keandalan data dan sinyal, bukan kepastian harga.")
    L.append(bar)
    return "\n".join(L)


# ------------------------------------------------------------------ main ---
def build_risk_flags(m: Dict[str, Any], f: Dict[str, Any], rel: Optional[Dict[str, Any]],
                     hist: Optional[Dict[str, Any]], profile: str, news: Optional[Dict[str, Any]],
                     dq: Dict[str, Any], mc: Optional[Dict[str, Any]],
                     fair: Optional[Dict[str, Any]] = None) -> List[str]:
    flags: List[str] = []
    if m["max_drawdown_pct"] < -50:
        flags.append(f"Penurunan terdalam {m['max_drawdown_pct']:.0f}% dalam periode analisis.")
    if m["volatility_pct"] > 50:
        flags.append(f"Volatilitas tahunan sangat tinggi ({m['volatility_pct']:.0f}%).")
    if m.get("atr_pct") is not None and m["atr_pct"] > 5:
        flags.append(f"Rentang gerak harian besar (ATR 14 hari {m['atr_pct']:.1f}% dari harga).")
    if (f.get("eps") is not None and f["eps"] <= 0) or (f.get("pe") is not None and f["pe"] <= 0):
        flags.append("Perusahaan rugi (EPS negatif).")
    if f.get("roe_pct") is not None and f["roe_pct"] < 0:
        flags.append("ROE negatif.")
    if profile == "NON_FINANCIAL" and f.get("der_pct") is not None and f["der_pct"] > 200:
        flags.append(f"DER tinggi ({f['der_pct']:.0f}%).")
    if rel and rel.get("beta") is not None and rel["beta"] > 1.6:
        flags.append(f"Beta tinggi ({rel['beta']:.2f}): bergerak jauh lebih liar dari indeks.")
    hs = hist["summary"] if hist and hist.get("available") else None
    if hs and hs.get("periods", 0) >= 3:
        if hs.get("net_income_cagr") is not None and hs["net_income_cagr"] < 0:
            flags.append(f"Laba bersih menyusut {hs['net_income_cagr']*100:.1f}%/thn dalam riwayat laporan.")
        if hs.get("profit_years_total") and hs["profit_years"] < hs["profit_years_total"]:
            flags.append(f"Ada tahun rugi: hanya {hs['profit_years']}/{hs['profit_years_total']} tahun laba.")
        if profile == "NON_FINANCIAL" and hs.get("cfo_ni_avg") is not None and hs.get("cfo_ni_n", 0) >= 3 \
                and hs["cfo_ni_avg"] < 0.6:
            flags.append(f"Laba kurang didukung kas (CFO/laba rata-rata {hs['cfo_ni_avg']:.2f}x).")
    if mc and mc.get("available"):
        p15 = mc["neutral_drift"]["prob_loss_15_pct"]
        if p15 >= 35:
            flags.append(f"Monte Carlo (netral): peluang rugi >15% dalam {mc['horizon_days']} hari = {p15:.0f}%.")
    if news and news.get("available") and news.get("critical_flags"):
        flags.append(f"{len(news['critical_flags'])} judul berita memuat kata risiko tinggi (cek manual).")
    for w in dq.get("warnings", []):
        flags.append("Data: " + w)
    if fair and fair.get("available") and fair.get("premium_pct") is not None and fair["premium_pct"] > 40:
        flags.append(f"Harga {fair['premium_pct']:.0f}% di atas harga wajar estimasi (cek asumsi dan data).")
    return flags


def build_valuation_reference(price: float, fundamentals: Dict[str, Any],
                               hist: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Referensi harga berbasis multiple historis sendiri; bukan nilai intrinsik.

    Sengaja mengembalikan unavailable jika data/riwayat tidak cukup. PER dan PBV
    historis dapat terdistorsi siklus bisnis, aksi korporasi, atau perubahan struktur.
    """
    if not hist or not hist.get("available") or price is None or price <= 0:
        return {"available": False, "reason": "Riwayat fundamental atau harga tidak cukup."}
    summary = hist.get("summary") or {}
    estimates = []
    eps = fundamentals.get("eps")
    pe_avg, pe_n = summary.get("per_avg"), summary.get("per_n", 0)
    if eps is not None and eps > 0 and pe_avg is not None and 0 < pe_avg <= 60 and pe_n >= 3:
        estimates.append({"method": "PER historis", "price": float(eps * pe_avg), "multiple": float(pe_avg)})
    pb, pb_avg, pb_n = fundamentals.get("pb"), summary.get("pbv_avg"), summary.get("pbv_n", 0)
    if pb is not None and pb > 0 and pb_avg is not None and 0 < pb_avg <= 15 and pb_n >= 3:
        book_per_share = price / pb
        estimates.append({"method": "PBV historis", "price": float(book_per_share * pb_avg), "multiple": float(pb_avg)})
    estimates = [e for e in estimates if np.isfinite(e["price"]) and e["price"] > 0]
    if not estimates:
        per_n = int(pe_n or 0)
        pbv_n = int(pb_n or 0)
        reasons = []
        if eps is None or eps <= 0:
            reasons.append("EPS terbaru tidak tersedia atau negatif")
        if per_n < 3:
            reasons.append(f"PER historis valid hanya {per_n}/3 periode minimum")
        if pb is None or pb <= 0:
            reasons.append("PB/nilai buku per saham terbaru tidak tersedia atau tidak positif")
        if pbv_n < 3:
            reasons.append(f"PBV historis valid hanya {pbv_n}/3 periode minimum")
        return {"available": False,
                "reason": "; ".join(reasons) if reasons else "Data historis belum cukup untuk menghitung referensi valuasi.",
                "per_periods": per_n, "pbv_periods": pbv_n,
                "hint": "Pastikan riwayat harga dan laporan keuangan tahunan tersedia. Multiple historis dihitung hanya dari data valid; tidak ada angka yang ditebak."}
    values = sorted(e["price"] for e in estimates)
    mid = len(values) // 2
    reference = values[mid] if len(values) % 2 else (values[mid - 1] + values[mid]) / 2
    return {
        "available": True,
        "current_price": float(price),
        "reference_price": float(reference),
        "low_estimate": float(values[0]),
        "high_estimate": float(values[-1]),
        "gap_pct": float((reference / price - 1) * 100),
        "methods": estimates,
        "label": "di bawah referensi historis" if reference > price * 1.05 else ("di atas referensi historis" if reference < price * 0.95 else "dekat referensi historis"),
        "disclaimer": "Referensi multiple historis, bukan nilai intrinsik atau target harga. Tidak memperhitungkan perubahan prospek dan bukan sinyal beli otomatis."
    }


def analyze(ticker: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
    t0 = time.monotonic()
    cfg = dict(cfg)
    fast = bool(cfg.get("fast"))
    if fast:
        cfg.update(run_backtest=False, run_history=False, run_montecarlo=False, run_news=False)
    budget = float(cfg.get("time_budget", 40.0))
    skipped: List[str] = []

    def over(name: str) -> bool:
        if time.monotonic() - t0 > budget:
            skipped.append(name)
            return True
        return False

    years = int(cfg["years"])
    rf = float(cfg["risk_free"])
    fetch_years = max(years, int(cfg["backtest_years"])) if cfg["run_backtest"] else years

    validate_sources = bool(cfg.get("validate_sources", True)) and not fast
    full, hist_meta = fetch_history_ex(ticker, fetch_years, validate_sources)
    cutoff = full.index[-1] - pd.DateOffset(years=years)
    df = full[full.index >= cutoff]
    if len(df) < MIN_ROWS:
        raise RuntimeError(f"Data '{ticker}' dalam {years} tahun hanya {len(df)} hari; minimal {MIN_ROWS} hari untuk analisis dasar.")

    price, price_source, live_meta = fetch_live_price_ex(ticker, float(df["Close"].iloc[-1]), validate_sources)
    close = with_live_price(df["Close"], price)
    metrics = calc_metrics(close, price, rf)
    metrics.update(calc_extras(df))

    bench = None
    rel = None
    if cfg["benchmark"]:
        bench = fetch_benchmark(cfg["benchmark"], fetch_years)
        if bench is not None:
            rel = calc_relative(close, bench)

    info, info_meta = fetch_info_ex(ticker, validate_sources)
    profile = extract_profile(info)
    fundamentals = extract_fundamentals(info, cfg.get("limits"))
    sources_meta: Dict[str, Any] = {
        "history": hist_meta, "live": live_meta, "fundamentals": info_meta, "statements": {"source": None},
        "providers_active": [p.name for p in ds.active_providers(ticker)], "validation_enabled": validate_sources}
    dq = check_data_quality(df, price, cfg, price_source, sources_meta)

    news: Optional[Dict[str, Any]] = None
    if cfg["run_news"] and not over("berita"):
        try:
            news = fetch_news(ticker, info, cfg)
        except Exception as exc:
            LOG.warning("Modul berita gagal: %s", exc)
            news = {"available": False, "reason": str(exc)}

    hist: Optional[Dict[str, Any]] = None
    if cfg["run_history"] and not over("riwayat fundamental"):
        hist = build_history_cached(ticker, years, full["Close"], cfg)
        sources_meta["statements"] = {"source": (hist or {}).get("source")}

    coe = cfg.get("cost_of_equity", 0.12)
    ke = float(coe.get(cfg["market"], 0.12)) if isinstance(coe, dict) else float(coe)
    min_hist = int(cfg.get("min_history_periods", 3))

    valuation_reference = build_valuation_reference(price, fundamentals, hist)
    fair_value: Optional[Dict[str, Any]] = None
    if cfg.get("run_fair_value", True):
        tg = cfg.get("terminal_growth", 0.04)
        g_term = float(tg.get(cfg["market"], 0.04)) if isinstance(tg, dict) else float(tg)
        try:
            fair_value = estimate_fair_value(
                price, fundamentals, profile, hist, valuation_reference,
                {"ke": ke, "g": g_term, "mos": cfg.get("fair_value_mos", 0.25),
                 "weights": cfg.get("fair_value_weights"),
                 "data_conflicts": [
                     f"Sumber data berbeda untuk {c['field']}: " + ", ".join(f"{k} {v:,.4g}" for k, v in c["values"].items())
                     for c in (info_meta.get("conflicts") or [])
                     if c["field"] in ("trailingEps", "bookValue", "sharesOutstanding", "trailingPE")]})
        except Exception as exc:
            LOG.warning("Harga wajar gagal: %s", exc)
            fair_value = {"available": False, "reason": f"perhitungan gagal: {exc}"}

    criteria = build_criteria(metrics, fundamentals, rel, True, news, hist,
                              profile["profile"], ke, min_hist)
    if cfg.get("fair_value_in_score") and fair_value and fair_value.get("available"):
        sc_f = [2, 1, 0, -1, -2]
        ratio_f = fair_value["current_price"] / fair_value["base"]
        criteria.append(crit("Harga vs harga wajar", f"{fair_value['premium_pct']:+.1f}% vs harga wajar",
                             band(ratio_f, [0.7, 0.85, 1.15, 1.4], sc_f), sc_f,
                             "Harga di bawah estimasi harga wajar = margin keamanan; di atas = premi. Estimasi sensitif pada asumsi."))
    v = verdict(criteria, cfg)
    price_only = {k: x for k, x in metrics.items() if k not in EXTRA_KEYS}
    tech_v = verdict(build_criteria(price_only, None, None, False), cfg)

    bt: Optional[Dict[str, Any]] = None
    if cfg["run_backtest"] and not over("backtest"):
        key = (ticker, fetch_years, years, cfg["horizon_days"], cfg["sample_step"], cfg["benchmark"],
               cfg["buy_threshold"], cfg["hold_threshold"], cfg["risk_free"])
        if key not in BACKTEST_CACHE:
            BACKTEST_CACHE[key] = run_backtest(full["Close"], cfg, bench)
        bt = BACKTEST_CACHE[key]

    mc: Optional[Dict[str, Any]] = None
    if cfg["run_montecarlo"] and not over("monte carlo"):
        try:
            mc = monte_carlo(close, int(cfg["horizon_days"]), int(cfg["mc_sims"]),
                             int(cfg["mc_block"]), int(cfg["mc_seed"]))
        except Exception as exc:
            LOG.warning("Monte Carlo gagal: %s", exc)
            mc = {"available": False, "reason": str(exc)}

    conf = assess_confidence(dq, bt, fundamentals, v, tech_v, news, hist, skipped, min_hist, sources_meta)
    risk_flags = build_risk_flags(metrics, fundamentals, rel, hist, profile["profile"], news, dq, mc, fair_value)

    v["final_label"] = v["label"]
    v["downgrade_reasons"] = []
    if v["label"] == "LAYAK BELI":
        if conf["label"] == "RENDAH":
            v["downgrade_reasons"].append("keyakinan rendah")
        if news and news.get("available") and news.get("critical_flags"):
            v["downgrade_reasons"].append("ada berita berisiko tinggi, cek manual")
        if (fundamentals.get("eps") is not None and fundamentals["eps"] <= 0):
            v["downgrade_reasons"].append("perusahaan rugi (EPS negatif)")
        if v["downgrade_reasons"]:
            v["final_label"] = "TAHAN / PANTAU"

    elapsed = time.monotonic() - t0
    LOG.info("%s -> %s (skor %.1f, keyakinan %s, %.1fs)", ticker, v["final_label"],
             v["score_pct"], conf["label"], elapsed)
    return {"ticker": ticker, "timestamp": datetime.now().isoformat(timespec="seconds"),
            "mode": "fast" if fast else "full", "elapsed_sec": round(elapsed, 2), "skipped": skipped,
            "profile": profile, "metrics": metrics, "relative": rel, "fundamentals": fundamentals,
            "valuation_reference": valuation_reference, "fair_value": fair_value,
            "data_sources": sources_meta,
            "criteria": [asdict(c) for c in criteria], "data_quality": dq,
            "news": news, "history": hist, "backtest": bt, "montecarlo": mc,
            "chart": chart_series(close, int(cfg["chart_points"])),
            "risk_flags": risk_flags, "confidence": conf, "verdict": v,
            "_criteria_obj": criteria}


def run_once(tickers: List[str], cfg: Dict[str, Any], as_json: bool) -> int:
    failures = 0
    payload = []
    results = []
    for t in tickers:
        try:
            r = analyze(t, cfg)
        except Exception as exc:
            failures += 1
            LOG.error("Gagal menganalisis %s: %s", t, exc)
            print(f"[ERROR] {t}: {exc}", file=sys.stderr)
            continue
        results.append(r)
        if as_json:
            payload.append({k: x for k, x in r.items() if k != "_criteria_obj"})
        else:
            print(render(r, cfg))
    if as_json:
        print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
    elif len(results) > 1:
        print("\nPERINGKAT (skor gabungan)")
        print("-" * 78)
        for i, r in enumerate(sorted(results, key=lambda x: x["verdict"]["score_pct"], reverse=True), 1):
            print(f" {i:>2}. {r['ticker']:<10} {r['verdict']['score_pct']:>5.1f}  {r['verdict']['final_label']:<18} "
                  f"keyakinan {r['confidence']['label']:<7} CAGR {r['metrics']['cagr_pct']:+.1f}%")
    return failures


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Analisis saham 5 tahun + real-time + riwayat fundamental + backtest + berita.")
    p.add_argument("tickers", nargs="+", help="Kode saham, contoh: BBCA TLKM AAPL (beberapa kode = peringkat)")
    p.add_argument("--market", choices=["id", "us"], default="id",
                   help="id = tambah .JK (default), us = ticker apa adanya")
    p.add_argument("--years", type=int, help="Tahun histori analisis (default 5)")
    p.add_argument("--risk-free", type=float, help="Bunga bebas risiko, desimal (default 0.06)")
    p.add_argument("--benchmark", help="Simbol indeks acuan (default ^JKSE / ^GSPC)")
    p.add_argument("--fast", action="store_true", help="Analisis cepat: tanpa backtest, riwayat, Monte Carlo, berita")
    p.add_argument("--no-backtest", action="store_true", help="Lewati backtest")
    p.add_argument("--no-news", action="store_true", help="Lewati modul berita")
    p.add_argument("--no-history", action="store_true", help="Lewati riwayat fundamental")
    p.add_argument("--no-mc", action="store_true", help="Lewati Monte Carlo")
    p.add_argument("--time-budget", type=float, help="Batas waktu detik untuk modul opsional (default 40)")
    p.add_argument("--news-days", type=int, help="Rentang berita dalam hari (default 7)")
    p.add_argument("--watch", type=int, metavar="DETIK", help="Mode real-time, ulangi tiap N detik")
    p.add_argument("--json", action="store_true", help="Output JSON")
    p.add_argument("--config", help="Path file config JSON")
    p.add_argument("--log-file", help="Tulis log ke file")
    p.add_argument("-v", "--verbose", action="store_true", help="Log INFO")
    p.add_argument("--debug", action="store_true", help="Log DEBUG")
    p.add_argument("--diagnose-sources", action="store_true",
                   help="Uji tiap sumber data untuk saham pertama (memakai kuota API), lalu keluar")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    setup_logging(args.verbose, args.debug, args.log_file)
    if args.diagnose_sources:
        try:
            target = normalize_ticker(args.tickers[0], args.market)
        except ValueError as exc:
            print(f"Ticker tidak valid: {exc}", file=sys.stderr)
            return 2
        print(json.dumps(ds.diagnose(target), indent=2, ensure_ascii=False))
        return 0
    cfg = load_config(args.config)
    cfg["market"] = args.market
    if args.years:
        cfg["years"] = args.years
    if args.risk_free is not None:
        cfg["risk_free"] = args.risk_free
    if args.no_backtest:
        cfg["run_backtest"] = False
    if args.no_news:
        cfg["run_news"] = False
    if args.fast:
        cfg["fast"] = True
    if args.no_history:
        cfg["run_history"] = False
    if args.no_mc:
        cfg["run_montecarlo"] = False
    if args.time_budget is not None:
        cfg["time_budget"] = max(1.0, args.time_budget)
    if args.news_days:
        if not (1 <= args.news_days <= 30):
            print("--news-days harus 1..30", file=sys.stderr)
            return 2
        cfg["news_days"] = args.news_days
    cfg["benchmark"] = args.benchmark or cfg["benchmark"] or BENCHMARKS[args.market]
    if not (1 <= int(cfg["years"]) <= 20):
        print("--years harus 1..20", file=sys.stderr)
        return 2

    try:
        tickers = [normalize_ticker(t, args.market) for t in args.tickers]
    except ValueError as exc:
        print(f"Ticker tidak valid: {exc}", file=sys.stderr)
        return 2

    if not args.watch:
        return 1 if run_once(tickers, cfg, args.json) == len(tickers) else 0

    interval = max(int(args.watch), int(cfg["min_watch_interval"]))
    if interval != args.watch:
        LOG.warning("Interval dinaikkan ke %ds untuk menghindari rate limit", interval)
    try:
        while True:
            run_once(tickers, cfg, args.json)
            print(f"\nUpdate berikutnya {interval} detik lagi (Ctrl+C untuk berhenti)\n")
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nDihentikan.")
        return 0


if __name__ == "__main__":
    sys.exit(main())