"""fair_value.py - Estimasi harga wajar saham dari beberapa metode independen.

Prinsip:
- Tidak ada angka tunggal yang "benar". Hasilnya rentang + harga dasar (median tertimbang)
  + tingkat keyakinan + tabel sensitivitas terhadap biaya modal dan pertumbuhan.
- Metode yang datanya tidak ada atau tidak andal DILEWATI dengan alasan, bukan ditebak.
- Hasil model (justified PBV, DDM, DCF) sangat sensitif pada asumsi; asumsi ditampilkan terbuka.
- Bukan target harga dan bukan sinyal beli otomatis.

Metode:
  per_hist   PER historis emiten x EPS terbaru        (dari referensi valuasi historis)
  pbv_hist   PBV historis emiten x nilai buku/saham   (dari referensi valuasi historis)
  graham     sqrt(22.5 x EPS x nilai buku/saham)       (batas atas konservatif emiten matang)
  pbv_roe    nilai buku/saham x (ROE - g) / (ke - g)   (PBV wajar dari profitabilitas)
  ddm        DPS x (1 + g) / (ke - g)                  (model dividen Gordon)
  dcf        arus kas bebas 5 tahun, pertumbuhan menurun ke g, nilai akhir Gordon (bukan bank)
"""
import math
from typing import Any, Dict, List, Optional, Tuple

DEFAULT_WEIGHTS: Dict[str, float] = {
    "per_hist": 0.5, "pbv_hist": 0.5, "graham": 0.5, "pbv_roe": 1.0, "ddm": 0.5, "dcf": 1.0,
}
NAMES: Dict[str, str] = {
    "per_hist": "PER historis x EPS", "pbv_hist": "PBV historis x nilai buku",
    "graham": "Graham Number", "pbv_roe": "PBV wajar dari ROE",
    "ddm": "Model dividen (Gordon)", "dcf": "DCF arus kas bebas",
}
GRAHAM_MULTIPLIER = 22.5
DCF_YEARS = 5
ROE_CAP = 0.40
MIN_SPREAD = 0.03            # ke - g minimum agar rumus Gordon tidak meledak
OUTLIER_FACTOR = 3.0         # terhadap median metode lain (bila >= 3 metode)
PRICE_BAND = (0.1, 10.0)     # estimasi di luar 0,1x - 10x harga dianggap data diragukan
DISCLAIMER = ("Estimasi dari model dan data Yahoo Finance, bukan target harga dan bukan sinyal beli. "
              "Hasil sangat sensitif pada asumsi (biaya modal, pertumbuhan); lihat tabel sensitivitas. "
              "Periksa laporan keuangan resmi dan prospek bisnis sebelum bertindak.")


def _pos(x: Any) -> bool:
    return x is not None and isinstance(x, (int, float)) and math.isfinite(x) and x > 0


def _clip(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def weighted_median(items: List[Tuple[float, float]]) -> float:
    """Median tertimbang; jika tepat di tengah dua nilai, ambil rata-ratanya."""
    items = sorted(items)
    total = sum(w for _, w in items)
    half, cum = total / 2.0, 0.0
    for i, (p, w) in enumerate(items):
        cum += w
        if cum > half + 1e-12:
            return p
        if abs(cum - half) <= 1e-12 and i + 1 < len(items):
            return (p + items[i + 1][0]) / 2.0
    return items[-1][0]


def dcf_per_share(base_fcf: float, shares: float, ke: float, g1: float, g_t: float,
                  years: int = DCF_YEARS) -> float:
    """Pertumbuhan menurun linear dari g1 (tahun 1) ke g_t (tahun terakhir), lalu nilai akhir Gordon."""
    pv, fcf = 0.0, base_fcf
    for t in range(1, years + 1):
        g_now = g1 + (g_t - g1) * (t - 1) / max(1, years - 1)
        fcf *= 1 + g_now
        pv += fcf / (1 + ke) ** t
    terminal = fcf * (1 + g_t) / (ke - g_t)
    pv += terminal / (1 + ke) ** years
    return pv / shares


def _context(price: float, f: Dict[str, Any], profile: Dict[str, Any],
             hist: Optional[Dict[str, Any]], params: Dict[str, Any]) -> Dict[str, Any]:
    flags: List[str] = list(params.get("data_conflicts") or [])
    summary = hist["summary"] if hist and hist.get("available") else {}
    rows = [r for r in (hist["rows"] if hist and hist.get("available") else []) if r.get("period") == "FY"]

    cur, fin_cur = profile.get("currency"), profile.get("financial_currency")
    fx_mismatch = bool(cur and fin_cur and str(cur).upper() != str(fin_cur).upper())
    if fx_mismatch:
        flags.append(f"Mata uang laporan ({fin_cur}) berbeda dari mata uang perdagangan ({cur}): metode berbasis "
                     "EPS dan arus kas dinonaktifkan agar tidak salah kurs.")

    eps, pe = f.get("eps"), f.get("pe")
    eps_ok = _pos(eps) and not fx_mismatch
    if eps_ok and _pos(pe) and abs(eps * pe / price - 1) > 0.35:
        eps_ok = False
        flags.append("EPS dan PER dari sumber tidak konsisten dengan harga (selisih >35%); metode berbasis EPS dilewati.")

    pb, book = f.get("pb"), f.get("book_value")
    bvps = price / pb if _pos(pb) else (book if _pos(book) else None)
    bvps_ok = _pos(bvps)
    if _pos(pb) and _pos(book) and abs((price / pb) / book - 1) > 0.30:
        bvps_ok = False
        flags.append("PBV dan nilai buku per saham dari sumber tidak konsisten (selisih >30%); metode berbasis nilai buku dilewati.")

    roe_snap = f.get("roe_pct") / 100 if f.get("roe_pct") is not None else None
    roe_derived = False
    if roe_snap is None and eps_ok and bvps_ok:
        # Yahoo sering tidak menyediakan ROE untuk emiten kecil; EPS / nilai buku per saham setara ROE
        # (laba per saham dibagi ekuitas per saham) dan memakai dua angka yang sudah lolos pemeriksaan konsistensi.
        roe_snap, roe_derived = eps / bvps, True
    roe_hist = summary.get("roe_avg") if summary.get("roe_n", 0) >= 3 else None
    loss_making = (eps is not None and eps <= 0) or (roe_snap is not None and roe_snap <= 0)
    if loss_making:
        flags.append("Perusahaan rugi saat ini (EPS/ROE negatif): metode berbasis laba dikecualikan dan estimasi kurang andal.")
        roe_hist = None                       # ROE historis tidak boleh menutupi kondisi rugi sekarang
    roe_vals = [v for v in (roe_snap, roe_hist) if v is not None and v > 0]
    roe_used = sum(roe_vals) / len(roe_vals) if roe_vals else None
    roe_capped = False
    if roe_used is not None and roe_used > ROE_CAP:
        roe_used, roe_capped = ROE_CAP, True

    dps = f.get("dps")
    if not _pos(dps) and _pos(f.get("div_yield_pct")):
        dps = price * f["div_yield_pct"] / 100.0
    shares = f.get("shares")
    if not _pos(shares) and _pos(profile.get("market_cap")):
        shares = profile["market_cap"] / price
    if not _pos(shares) and rows and _pos(rows[-1].get("shares_outstanding")):
        shares = rows[-1]["shares_outstanding"]

    growth_pts = [x for x in (summary.get("net_income_cagr"), summary.get("revenue_cagr")) if x is not None]
    fcfs = [r.get("fcf") for r in rows[-3:] if r.get("fcf") is not None]
    return {"roe_derived": roe_derived, "loss_making": loss_making, "fx_mismatch": fx_mismatch, "eps": eps, "eps_ok": eps_ok, "bvps": bvps, "bvps_ok": bvps_ok,
            "pb": pb, "roe_snap": roe_snap, "roe_used": roe_used, "roe_capped": roe_capped,
            "dps": dps if _pos(dps) else None, "payout": f.get("payout"), "shares": shares if _pos(shares) else None,
            "growth_pts": growth_pts, "ni_cagr": summary.get("net_income_cagr"), "fcfs": fcfs,
            "periods": summary.get("periods", 0) if summary else 0, "flags": flags}


def _compute(price: float, f: Dict[str, Any], profile: Dict[str, Any], hist: Optional[Dict[str, Any]],
             vref: Optional[Dict[str, Any]], params: Dict[str, Any],
             only_keys: Optional[set] = None) -> Dict[str, Any]:
    ke, g = float(params["ke"]), float(params["g"])
    weights = {**DEFAULT_WEIGHTS, **(params.get("weights") or {})}
    ctx = _context(price, f, profile, hist, params)
    prof = profile.get("profile", "NON_FINANCIAL")
    est: List[Dict[str, Any]] = []
    na: List[Dict[str, str]] = []

    def ok(key: str, value: float, note: str) -> None:
        w = weights.get(key, 1.0)
        if prof != "NON_FINANCIAL" and key == "pbv_roe":
            w *= 1.5                                   # untuk bank, PBV-ROE adalah metode utama
        est.append({"key": key, "name": NAMES[key], "price": float(value), "weight": float(w), "note": note})

    def no(key: str, reason: str) -> None:
        na.append({"key": key, "name": NAMES[key], "reason": reason})

    # --- multiple historis (dari referensi valuasi yang sudah ada)
    by_name = {m.get("method"): m for m in (vref.get("methods", []) if vref and vref.get("available") else [])}
    for key, label, needs_eps in (("per_hist", "PER historis", True), ("pbv_hist", "PBV historis", False)):
        m = by_name.get(label)
        if m is None:
            no(key, (vref or {}).get("reason") or "multiple historis belum memadai (butuh minimal 3 periode valid)")
        elif needs_eps and not ctx["eps_ok"]:
            no(key, "EPS tidak tersedia/tidak konsisten atau beda mata uang laporan")
        elif not needs_eps and not ctx["bvps_ok"]:
            no(key, "nilai buku per saham tidak tersedia/tidak konsisten")
        else:
            ok(key, m["price"], f"Rata-rata multiple historis {m['multiple']:.2f}x diterapkan ke data terbaru.")

    # --- Graham
    if ctx["eps_ok"] and ctx["bvps_ok"]:
        ok("graham", math.sqrt(GRAHAM_MULTIPLIER * ctx["eps"] * ctx["bvps"]),
           f"sqrt(22,5 x EPS {ctx['eps']:.2f} x nilai buku {ctx['bvps']:.2f}). Cenderung rendah untuk saham bertumbuh.")
    else:
        no("graham", "butuh EPS positif dan nilai buku per saham yang konsisten")

    # --- PBV wajar dari ROE
    pb, roe_snap = ctx["pb"], ctx["roe_snap"]
    if not ctx["bvps_ok"]:
        no("pbv_roe", "nilai buku per saham tidak tersedia/tidak konsisten")
    elif (pb is not None and pb > 15) or (roe_snap is not None and roe_snap > 0.5):
        no("pbv_roe", "ROE/PBV ekstrem (kemungkinan distorsi buyback atau ekuitas kecil); model tidak andal")
    elif ctx["loss_making"]:
        no("pbv_roe", "perusahaan rugi saat ini: ROE tidak bisa dipakai untuk PBV wajar")
    elif ctx["roe_used"] is None:
        no("pbv_roe", "ROE positif tidak tersedia")
    elif ke - g < MIN_SPREAD:
        no("pbv_roe", "biaya modal terlalu dekat dengan pertumbuhan jangka panjang")
    elif ctx["roe_used"] <= g + 0.005:
        no("pbv_roe", f"ROE {ctx['roe_used']*100:.1f}% tidak melebihi pertumbuhan jangka panjang {g*100:.1f}%")
    else:
        fair_pbv = (ctx["roe_used"] - g) / (ke - g)
        cap = " (ROE dibatasi 40%)" if ctx["roe_capped"] else ""
        src = " ROE diturunkan dari EPS / nilai buku karena sumber tidak menyediakannya." if ctx["roe_derived"] else ""
        ok("pbv_roe", ctx["bvps"] * fair_pbv,
           f"PBV wajar {fair_pbv:.2f}x = (ROE {ctx['roe_used']*100:.1f}%{cap} - g {g*100:.1f}%) / (ke {ke*100:.1f}% - g)." + src)

    # --- Model dividen
    if ctx["dps"] is None:
        no("ddm", "tidak ada dividen")
    elif ctx["loss_making"]:
        no("ddm", "perusahaan rugi: dividen tidak berkelanjutan")
    elif _pos(f.get("div_yield_pct")) and f["div_yield_pct"] < 1.0:
        no("ddm", "dividen terlalu kecil (<1%) untuk model dividen yang bermakna")
    elif ctx["payout"] is not None and ctx["payout"] > 1.0:
        no("ddm", "payout ratio di atas 100%: dividen tidak berkelanjutan")
    else:
        g_d = min(g, max(0.0, ctx["ni_cagr"])) if ctx["ni_cagr"] is not None else g
        if ke - g_d < MIN_SPREAD:
            no("ddm", "biaya modal terlalu dekat dengan pertumbuhan dividen")
        else:
            ok("ddm", ctx["dps"] * (1 + g_d) / (ke - g_d),
               f"DPS {ctx['dps']:.2f} x (1+{g_d*100:.1f}%) / (ke {ke*100:.1f}% - {g_d*100:.1f}%).")

    # --- DCF arus kas bebas
    if prof != "NON_FINANCIAL":
        no("dcf", "arus kas bebas tidak cocok untuk bank/keuangan")
    elif ctx["fx_mismatch"]:
        no("dcf", "beda mata uang laporan dan perdagangan")
    elif len(ctx["fcfs"]) < 2:
        no("dcf", "butuh minimal 2 tahun data arus kas bebas")
    elif ctx["fcfs"][-1] <= 0 or sum(ctx["fcfs"]) / len(ctx["fcfs"]) <= 0:
        no("dcf", "arus kas bebas terbaru/rata-rata tidak positif")
    elif ctx["shares"] is None:
        no("dcf", "jumlah saham beredar tidak tersedia")
    elif ke - g < MIN_SPREAD:
        no("dcf", "biaya modal terlalu dekat dengan pertumbuhan jangka panjang")
    else:
        base_fcf = sum(ctx["fcfs"]) / len(ctx["fcfs"])
        g1 = _clip(sum(ctx["growth_pts"]) / len(ctx["growth_pts"]), 0.0, 0.12) if ctx["growth_pts"] else g
        g1 = max(g1, g)
        ok("dcf", dcf_per_share(base_fcf, ctx["shares"], ke, g1, g),
           f"FCF rata-rata {len(ctx['fcfs'])} tahun, tumbuh {g1*100:.1f}% menurun ke {g*100:.1f}% dalam 5 tahun, diskonto {ke*100:.1f}%.")

    # --- saring estimasi tak wajar
    valid = []
    for e in est:
        r = e["price"] / price
        if not math.isfinite(e["price"]) or e["price"] <= 0:
            e["excluded"] = "hasil tidak valid"
        elif not (PRICE_BAND[0] <= r <= PRICE_BAND[1]):
            e["excluded"] = f"{r:.1f}x harga pasar: di luar rentang wajar, data diragukan"
        else:
            valid.append(e)
    if only_keys is not None:
        # Mode sensitivitas: himpunan metode dikunci sama dengan kasus dasar supaya tabel hanya
        # mencerminkan efek asumsi, bukan metode yang keluar-masuk akibat aturan outlier.
        for e in est:
            if "excluded" not in e and e["key"] not in only_keys:
                e["excluded"] = "tidak dipakai pada kasus dasar"
        valid = []
    if len(valid) >= 3:
        prices = sorted(e["price"] for e in valid)
        med = prices[len(prices) // 2] if len(prices) % 2 else (prices[len(prices) // 2 - 1] + prices[len(prices) // 2]) / 2
        for e in valid:
            if e["price"] > OUTLIER_FACTOR * med or e["price"] < med / OUTLIER_FACTOR:
                e["excluded"] = f"outlier terhadap median metode lain ({med:,.0f})"
    inc = [e for e in est if "excluded" not in e]
    base = low = high = None
    if len(inc) >= 2:
        base = weighted_median([(e["price"], e["weight"]) for e in inc])
        low, high = min(e["price"] for e in inc), max(e["price"] for e in inc)
    return {"est": est, "na": na, "inc": inc, "base": base, "low": low, "high": high, "ctx": ctx}


def sensitivity(price: float, f: Dict[str, Any], profile: Dict[str, Any], hist: Optional[Dict[str, Any]],
                vref: Optional[Dict[str, Any]], params: Dict[str, Any], keys: set) -> Dict[str, Any]:
    ke0, g0 = float(params["ke"]), float(params["g"])
    ke_vals = [round(ke0 + d, 4) for d in (-0.02, -0.01, 0.0, 0.01, 0.02) if ke0 + d >= 0.05]
    g_vals = [round(g0 + d, 4) for d in (-0.01, 0.0, 0.01) if -0.02 <= g0 + d <= 0.08]
    grid = []
    for g in g_vals:
        row = []
        for ke in ke_vals:
            if ke - g < MIN_SPREAD:
                row.append(None)
                continue
            r = _compute(price, f, profile, hist, vref, {**params, "ke": ke, "g": g}, only_keys=keys)
            row.append(float(r["base"]) if r["base"] is not None else None)
        grid.append(row)
    return {"ke_values": ke_vals, "g_values": g_vals, "grid": grid}


def estimate_fair_value(price: float, f: Dict[str, Any], profile: Dict[str, Any],
                        hist: Optional[Dict[str, Any]], vref: Optional[Dict[str, Any]],
                        params: Dict[str, Any]) -> Dict[str, Any]:
    """params: ke, g, mos (margin of safety), weights (opsional)."""
    if not _pos(price):
        return {"available": False, "reason": "harga tidak valid"}
    mos = _clip(float(params.get("mos", 0.25)), 0.0, 0.8)
    r = _compute(price, f, profile, hist, vref, params)
    ctx = r["ctx"]
    methods = [{**e, "included": "excluded" not in e, "excluded_reason": e.get("excluded")} for e in r["est"]]
    unavailable = r["na"]
    analyst = None
    if _pos(f.get("target_mean")) and (f.get("analyst_n") or 0) >= 3:
        analyst = {"target": float(f["target_mean"]), "n": int(f["analyst_n"]),
                   "gap_pct": float((f["target_mean"] / price - 1) * 100),
                   "note": "Konsensus analis ditampilkan sebagai pembanding; tidak masuk perhitungan."}
    assumptions = {"ke": float(params["ke"]), "g": float(params["g"]), "mos": mos,
                   "roe_used": ctx["roe_used"], "graham_multiplier": GRAHAM_MULTIPLIER, "dcf_years": DCF_YEARS,
                   "weights": {k: v for k, v in {**DEFAULT_WEIGHTS, **(params.get("weights") or {})}.items()}}
    out: Dict[str, Any] = {
        "current_price": float(price), "methods": methods, "unavailable": unavailable,
        "assumptions": assumptions, "analyst": analyst, "flags": ctx["flags"], "disclaimer": DISCLAIMER,
        "currency": profile.get("currency"),
    }
    inc = r["inc"]
    if r["base"] is None:
        reason = ("hanya satu metode yang bisa dihitung; tidak cukup untuk harga wajar" if len(inc) == 1
                  else "metode yang bisa dihitung kurang dari dua (data fundamental/riwayat belum memadai)")
        indicative = None
        if len(inc) == 1:
            e = inc[0]
            indicative = {"name": e["name"], "price": float(e["price"]), "note": e["note"],
                          "upside_pct": float((e["price"] / price - 1) * 100)}
        out.update(available=False, reason=reason, indicative=indicative,
                   indications=[{"name": e["name"], "price": e["price"]} for e in inc])
        return out

    base, low, high = r["base"], r["low"], r["high"]
    ratio = price / base
    label = ("DI BAWAH HARGA WAJAR" if ratio < 0.85 else "DI ATAS HARGA WAJAR" if ratio > 1.15 else "MENDEKATI HARGA WAJAR")
    dispersion = high / low if low > 0 else None
    pts, reasons = 0, []
    n = len(inc)
    if n >= 3:
        pts += 1; reasons.append(f"+1 {n} metode independen dipakai")
    if n >= 4:
        pts += 1; reasons.append("+1 empat metode atau lebih")
    if dispersion is not None and dispersion <= 1.6:
        pts += 1; reasons.append(f"+1 metode sepakat (rentang {dispersion:.2f}x)")
    elif dispersion is not None and dispersion > 2.5:
        pts -= 1; reasons.append(f"-1 metode sangat berbeda (rentang {dispersion:.2f}x)")
    if ctx["periods"] >= 3:
        pts += 1; reasons.append(f"+1 riwayat laporan {ctx['periods']} periode")
    if ctx["flags"]:
        pts -= 1; reasons.append("-1 ada inkonsistensi data/mata uang")
    conf = "TINGGI" if pts >= 3 else ("SEDANG" if pts >= 1 else "RENDAH")
    out.update(
        available=True, base=float(base), low=float(low), high=float(high),
        mos_price=float(base * (1 - mos)), upside_pct=float((base / price - 1) * 100),
        premium_pct=float((price / base - 1) * 100), label=label, in_range=bool(low <= price <= high),
        dispersion=float(dispersion) if dispersion is not None else None,
        confidence={"label": conf, "points": pts, "reasons": reasons},
        sensitivity=sensitivity(price, f, profile, hist, vref, params, {e["key"] for e in inc}),
    )
    return out
