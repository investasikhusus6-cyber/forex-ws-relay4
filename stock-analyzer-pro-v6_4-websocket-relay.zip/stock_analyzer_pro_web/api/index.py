import hmac
import json
import logging
import math
import os
import re
import sys
import time
from datetime import datetime
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parents[1] / ".env")
except ImportError:
    pass  # Environment variables supplied by the host still work without python-dotenv

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from flask import Flask, jsonify, request, send_from_directory

try:
    from flask_cors import CORS
except ImportError:  # CORS hanya perlu jika frontend dihosting di domain lain
    CORS = None

import pandas as pd
import yfinance as yf
import data_sources as ds
import stock_analyzer as sa

log = logging.getLogger("stock_analyzer.web")

app = Flask(__name__, static_folder="../static", static_url_path="")
if CORS:
    CORS(app)

TICKER_RE = re.compile(r"^[A-Z0-9.\-^=]{1,15}$")
VERSION = "v6.3.6"
TIME_BUDGET = float(os.environ.get("ANALYZER_TIME_BUDGET", "40"))


def clean(obj):
    """Ganti float NaN/Inf dengan None agar JSON selalu valid di browser."""
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    return obj


def respond(payload, status=200):
    body = json.dumps(clean(payload), ensure_ascii=False, allow_nan=False, default=str)
    return app.response_class(body, status=status, mimetype="application/json")

# Daftar saham populer untuk pencarian instan (dipakai juga jika pencarian Yahoo gagal).
POPULAR = [
    ("BBCA", "Bank Central Asia", "id"), ("BBRI", "Bank Rakyat Indonesia", "id"),
    ("BMRI", "Bank Mandiri", "id"), ("BBNI", "Bank Negara Indonesia", "id"),
    ("BRIS", "Bank Syariah Indonesia", "id"), ("ARTO", "Bank Jago", "id"),
    ("TLKM", "Telkom Indonesia", "id"), ("EXCL", "XL Axiata", "id"),
    ("ISAT", "Indosat Ooredoo Hutchison", "id"), ("TOWR", "Sarana Menara Nusantara", "id"),
    ("ASII", "Astra International", "id"), ("UNTR", "United Tractors", "id"),
    ("UNVR", "Unilever Indonesia", "id"), ("ICBP", "Indofood CBP Sukses Makmur", "id"),
    ("INDF", "Indofood Sukses Makmur", "id"), ("MYOR", "Mayora Indah", "id"),
    ("HMSP", "HM Sampoerna", "id"), ("GGRM", "Gudang Garam", "id"),
    ("KLBF", "Kalbe Farma", "id"), ("SIDO", "Industri Jamu Sido Muncul", "id"),
    ("CPIN", "Charoen Pokphand Indonesia", "id"), ("AMRT", "Sumber Alfaria Trijaya", "id"),
    ("ACES", "Aspirasi Hidup Indonesia", "id"), ("MAPI", "Mitra Adiperkasa", "id"),
    ("ADRO", "Adaro Energy Indonesia", "id"), ("PTBA", "Bukit Asam", "id"),
    ("ITMG", "Indo Tambangraya Megah", "id"), ("ANTM", "Aneka Tambang", "id"),
    ("INCO", "Vale Indonesia", "id"), ("MDKA", "Merdeka Copper Gold", "id"),
    ("AMMN", "Amman Mineral Internasional", "id"), ("MEDC", "Medco Energi Internasional", "id"),
    ("PGAS", "Perusahaan Gas Negara", "id"), ("BREN", "Barito Renewables Energy", "id"),
    ("BRPT", "Barito Pacific", "id"), ("TPIA", "Chandra Asri Pacific", "id"),
    ("SMGR", "Semen Indonesia", "id"), ("JSMR", "Jasa Marga", "id"),
    ("GOTO", "GoTo Gojek Tokopedia", "id"), ("EMTK", "Elang Mahkota Teknologi", "id"),
    ("BUKA", "Bukalapak.com", "id"),
    ("WIRG", "WIR Asia", "id"), ("DMMX", "Digital Mediatama Maxima", "id"),
    ("MCAS", "M Cash Integrasi", "id"), ("NFCX", "NFC Indonesia", "id"),
    ("DIVA", "Distribusi Voucher Nusantara", "id"),
    ("AAPL", "Apple Inc.", "us"), ("MSFT", "Microsoft", "us"), ("GOOGL", "Alphabet (Google)", "us"),
    ("AMZN", "Amazon.com", "us"), ("NVDA", "NVIDIA", "us"), ("TSLA", "Tesla", "us"),
    ("META", "Meta Platforms", "us"), ("NFLX", "Netflix", "us"),
]


@app.after_request
def no_stale_assets(resp):
    # Hindari browser/CDN menampilkan versi lama index.html / app.js
    if request.path in ("/", "/app.js", "/style.css", "/index.html"):
        resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/")
def home():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/health")
def health():
    return jsonify(ok=True, service="Stock Analyzer Pro", version=VERSION, time_budget=TIME_BUDGET,
                   sources=[p.name for p in ds.active_providers()])


def local_search(q, limit):
    q = q.upper()
    hits = []
    for code, name, market in POPULAR:
        up = name.upper()
        if code == q:
            rank = 0
        elif code.startswith(q):
            rank = 1
        elif q in up:
            rank = 2
        elif q in code:
            rank = 3
        else:
            continue
        hits.append((rank, code, name, market))
    hits.sort(key=lambda h: (h[0], h[1]))
    return [{"symbol": c, "name": n, "market": m, "exchange": "IDX" if m == "id" else "US"}
            for _, c, n, m in hits[:limit]]


def yahoo_search(q, limit):
    try:
        try:
            res = yf.Search(q, max_results=limit, news_count=0, timeout=6)
        except TypeError:
            res = yf.Search(q, max_results=limit, news_count=0)
        out = []
        for it in (res.quotes or []):
            sym = str(it.get("symbol") or "").upper()
            if not sym or it.get("quoteType") not in ("EQUITY", "ETF"):
                continue
            out.append({"symbol": sym,
                        "name": it.get("shortname") or it.get("longname") or sym,
                        "market": "id" if sym.endswith(".JK") else "us",
                        "exchange": it.get("exchDisp") or ""})
        return out
    except Exception as exc:
        log.warning("Pencarian Yahoo gagal: %s", exc)
        return []


@app.get("/api/search")
def search():
    q = re.sub(r"[^A-Za-z0-9 .\-&]", "", (request.args.get("q") or "").strip())[:30]
    if len(q) < 1:
        return jsonify(ok=True, results=[])
    limit = 8
    results = local_search(q, limit)
    if len(results) < limit:
        seen = {r["symbol"].replace(".JK", "") for r in results}
        for r in yahoo_search(q, limit):
            key = r["symbol"].replace(".JK", "")
            if key not in seen:
                seen.add(key)
                results.append(r)
    return jsonify(ok=True, results=results[:limit])


def pick_markets(ticker, market):
    """Urutan pasar yang dicoba. 'auto': .JK -> id, simbol bersufiks/indeks -> apa adanya,
    selain itu coba Indonesia dulu lalu pasar AS."""
    if market != "auto":
        return [market]
    if ticker.endswith(".JK"):
        return ["id"]
    if "." in ticker or ticker.startswith("^"):
        return ["us"]
    return ["id", "us"]


class AnalysisError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


def flag(name, default=True):
    v = request.args.get(name)
    return default if v is None else v not in ("0", "false", "off")


def analyze_one(ticker, market, years, fast, opts):
    """Analisis satu saham; market 'auto' mencoba Indonesia dulu lalu pasar AS."""
    last_exc = None
    for mk in pick_markets(ticker, market):
        cfg = dict(sa.DEFAULTS)
        cfg.update(market=mk, years=years, benchmark=sa.BENCHMARKS[mk], fast=fast,
                   time_budget=TIME_BUDGET,
                   run_backtest=opts.get("backtest", True), run_news=opts.get("news", True),
                   run_history=opts.get("history", True), run_montecarlo=opts.get("mc", True))
        # Asumsi harga wajar opsional (desimal, sudah divalidasi oleh parse_fair_params)
        if opts.get("ke") is not None:
            cfg["cost_of_equity"] = opts["ke"]
        if opts.get("g") is not None:
            cfg["terminal_growth"] = opts["g"]
        if opts.get("mos") is not None:
            cfg["fair_value_mos"] = opts["mos"]
        try:
            r = sa.analyze(sa.normalize_ticker(ticker, mk), cfg)
        except RuntimeError as exc:
            last_exc = exc
            # Pindah pasar hanya jika kode benar-benar tidak ditemukan, bukan data pendek.
            if "Tidak ada data" in str(exc):
                continue
            raise AnalysisError(422, str(exc))
        except Exception as exc:
            log.exception("Analisis %s gagal", ticker)
            raise AnalysisError(500, str(exc))
        r.pop("_criteria_obj", None)
        r["resolved_market"] = mk
        return r
    log.info("Tidak ditemukan: %s (%s)", ticker, last_exc)
    raise AnalysisError(404, f"Kode '{ticker}' tidak ditemukan. Coba cari lewat kolom pencarian, "
                             "atau pilih pasar secara manual (mis. BBCA.JK untuk Indonesia).")


def parse_common():
    market = (request.args.get("market") or "auto").lower()
    try:
        years = int(request.args.get("years", 5))
    except ValueError:
        raise AnalysisError(400, "Periode tidak valid.")
    if market not in ("auto", "id", "us") or not 1 <= years <= 20:
        raise AnalysisError(400, "Parameter market/periode tidak valid.")
    return market, years


def _pct_or_fraction(raw, name):
    """Terima 0.12 atau 12 (persen) untuk kemudahan pemakaian manual."""
    try:
        v = float(raw)
    except (TypeError, ValueError):
        raise AnalysisError(400, f"Parameter {name} harus berupa angka.")
    if abs(v) > 1:
        v = v / 100.0
    return v


def parse_fair_params():
    """Baca ke (biaya modal), g (pertumbuhan jangka panjang), mos (margin keamanan) bila ada."""
    out = {}
    ke = request.args.get("ke")
    g = request.args.get("g")
    mos = request.args.get("mos")
    if ke is not None:
        out["ke"] = _pct_or_fraction(ke, "ke")
        if not 0.04 <= out["ke"] <= 0.30:
            raise AnalysisError(400, "Biaya modal (ke) harus antara 4% dan 30%.")
    if g is not None:
        out["g"] = _pct_or_fraction(g, "g")
        if not -0.02 <= out["g"] <= 0.08:
            raise AnalysisError(400, "Pertumbuhan jangka panjang (g) harus antara -2% dan 8%.")
    if mos is not None:
        out["mos"] = _pct_or_fraction(mos, "mos")
        if not 0.0 <= out["mos"] <= 0.80:
            raise AnalysisError(400, "Margin keamanan (mos) harus antara 0% dan 80%.")
    if "ke" in out and "g" in out and out["g"] > out["ke"] - 0.02:
        raise AnalysisError(400, "g harus lebih kecil dari biaya modal (ke) minus 2 poin persen.")
    return out


def parse_ticker(raw):
    t = (raw or "").strip().upper()
    if not t:
        raise AnalysisError(400, "Masukkan kode saham.")
    if not TICKER_RE.match(t):
        raise AnalysisError(400, f"Kode '{t[:20]}' tidak valid: hanya huruf, angka, titik, atau tanda hubung.")
    return t


@app.get("/api/analyze")
def analyze():
    try:
        ticker = parse_ticker(request.args.get("ticker"))
        market, years = parse_common()
        fast = (request.args.get("mode") or "full").lower() == "fast"
        opts = {"backtest": flag("backtest"), "news": flag("news"), "history": flag("history"), "mc": flag("mc")}
        opts.update(parse_fair_params())
        return respond({"ok": True, "data": analyze_one(ticker, market, years, fast, opts)})
    except AnalysisError as e:
        return respond({"ok": False, "error": e.message}, e.status)


_LAST_DIAG = [0.0]
DIAG_COOLDOWN = float(os.environ.get("SOURCES_COOLDOWN", "10"))


@app.get("/api/sources")
def sources():
    """Uji tiap sumber data terhadap satu saham. Memakai kuota API: dibatasi frekuensinya, dan dapat
    dilindungi dengan SOURCES_TOKEN (parameter ?token=). Kunci API tidak pernah ditampilkan."""
    required = os.environ.get("SOURCES_TOKEN")
    if required and not hmac.compare_digest(str(request.args.get("token", "")), required):
        return respond({"ok": False, "error": "Token diperlukan untuk menguji sumber data."}, 403)
    try:
        ticker = parse_ticker(request.args.get("ticker"))
        market, _ = parse_common()
        t = sa.normalize_ticker(ticker, pick_markets(ticker, market)[0])
    except AnalysisError as e:
        return respond({"ok": False, "error": e.message}, e.status)
    now = time.time()
    if now - _LAST_DIAG[0] < DIAG_COOLDOWN:
        return respond({"ok": False, "error": f"Terlalu sering. Tunggu {DIAG_COOLDOWN:.0f} detik antar uji sumber."}, 429)
    _LAST_DIAG[0] = now
    return respond({"ok": True, "data": ds.diagnose(t)})


@app.get("/api/fairvalue")
def fairvalue():
    """Hitung ulang harga wajar dengan asumsi sendiri. Tanpa backtest/Monte Carlo/berita agar cepat;
    harga dan laporan keuangan memakai cache sehingga ringan setelah analisis pertama."""
    try:
        ticker = parse_ticker(request.args.get("ticker"))
        market, years = parse_common()
        opts = {"backtest": False, "news": False, "history": True, "mc": False}
        opts.update(parse_fair_params())
        r = analyze_one(ticker, market, years, False, opts)
        return respond({"ok": True, "data": {
            "ticker": r["ticker"], "resolved_market": r["resolved_market"], "timestamp": r["timestamp"],
            "profile": r["profile"], "price": r["metrics"]["price"],
            "fair_value": r.get("fair_value"), "valuation_reference": r.get("valuation_reference"),
            "elapsed_sec": r["elapsed_sec"]}})
    except AnalysisError as e:
        return respond({"ok": False, "error": e.message}, e.status)


def summarize_for_compare(r):
    m, f, v = r["metrics"], r["fundamentals"], r["verdict"]
    return {
        "ticker": r["ticker"], "name": r["profile"].get("name"), "profile": r["profile"]["profile"],
        "market": r["resolved_market"], "price": m["price"], "score": v["score_pct"],
        "label": v["final_label"], "confidence": r["confidence"]["label"], "groups": v["groups"],
        "cagr_pct": m["cagr_pct"], "volatility_pct": m["volatility_pct"], "sharpe": m["sharpe"],
        "max_drawdown_pct": m["max_drawdown_pct"], "rsi14": m["rsi14"],
        "from_high_52w_pct": m.get("from_high_52w_pct"),
        "pe": f.get("pe"), "pb": f.get("pb"), "roe_pct": f.get("roe_pct"), "div_yield_pct": f.get("div_yield_pct"),
        "data_quality": r["data_quality"]["score"], "risk_flags": len(r["risk_flags"]),
        "fair_gap_pct": (r.get("fair_value") or {}).get("upside_pct"),
        "fair_label": (r.get("fair_value") or {}).get("label"),
    }



# Daftar kandidat pembanding yang dikurasi berdasarkan kelompok bisnis umum.
# Ini fallback yang transparan, bukan klasifikasi sektor real-time.
PEER_GROUPS = {
    "bank besar": {"BBCA.JK", "BBRI.JK", "BMRI.JK", "BBNI.JK", "BBTN.JK", "BNGA.JK", "NISP.JK", "BDMN.JK", "MEGA.JK", "PNBN.JK", "BJBR.JK", "BJTM.JK"},
    "bank digital/syariah": {"BRIS.JK", "ARTO.JK", "BBYB.JK", "BANK.JK", "AGRO.JK", "AMAR.JK", "DNAR.JK", "BBSI.JK"},
    "telekomunikasi": {"TLKM.JK", "EXCL.JK", "ISAT.JK", "FREN.JK"},
    "menara dan infrastruktur telekomunikasi": {"TOWR.JK", "TBIG.JK", "MTEL.JK", "CENT.JK"},
    "barang konsumsi": {"UNVR.JK", "ICBP.JK", "INDF.JK", "MYOR.JK", "ROTI.JK", "GOOD.JK", "ULTJ.JK", "CLEO.JK", "CMRY.JK", "KEJU.JK", "STTP.JK", "HOKI.JK"},
    "rokok": {"HMSP.JK", "GGRM.JK", "WIIM.JK", "ITIC.JK"},
    "pertambangan batu bara": {"ADRO.JK", "PTBA.JK", "ITMG.JK", "AADI.JK", "HRUM.JK", "INDY.JK", "BUMI.JK", "DOID.JK", "GEMS.JK", "MBAP.JK", "BYAN.JK"},
    "logam dan mineral": {"ANTM.JK", "INCO.JK", "MDKA.JK", "AMMN.JK", "NCKL.JK", "MBMA.JK", "TINS.JK", "ZINC.JK", "DKFT.JK"},
    "energi dan gas": {"MEDC.JK", "PGAS.JK", "RAJA.JK", "ELSA.JK", "AKRA.JK", "ENRG.JK"},
    "petrokimia dan bahan kimia": {"BRPT.JK", "TPIA.JK", "ESSA.JK", "AGII.JK", "CHEM.JK"},
    "semen dan bahan bangunan": {"SMGR.JK", "INTP.JK", "WSBP.JK", "WTON.JK", "SMBR.JK"},
    "ritel": {"AMRT.JK", "ACES.JK", "MAPI.JK", "MIDI.JK", "LPPF.JK", "ERAA.JK", "RALS.JK", "MAPA.JK", "BELI.JK"},
    "unggas/pakan ternak": {"CPIN.JK", "JPFA.JK", "MAIN.JK"},
    "kesehatan dan farmasi": {"KLBF.JK", "SIDO.JK", "MIKA.JK", "HEAL.JK", "PRDA.JK", "SILO.JK", "DVLA.JK", "TSPC.JK", "MERK.JK"},
    "perkebunan sawit": {"AALI.JK", "LSIP.JK", "SIMP.JK", "DSNG.JK", "SSMS.JK", "TBLA.JK", "TAPG.JK", "SGRO.JK"},
    "properti dan kawasan": {"BSDE.JK", "CTRA.JK", "PWON.JK", "SMRA.JK", "ASRI.JK", "LPKR.JK", "DMAS.JK", "KIJA.JK", "PPRO.JK", "APLN.JK"},
    "konstruksi dan infrastruktur": {"JSMR.JK", "WIKA.JK", "PTPP.JK", "ADHI.JK", "WSKT.JK", "TOTL.JK", "SSIA.JK", "NRCA.JK"},
    "solusi dan ekosistem digital": {"WIRG.JK", "DMMX.JK", "MCAS.JK", "NFCX.JK", "DIVA.JK", "KREN.JK", "LUCK.JK", "MLPT.JK", "EDGE.JK", "WIFI.JK", "CYBR.JK"},
    "teknologi digital/platform": {"GOTO.JK", "BUKA.JK", "EMTK.JK", "BELI.JK", "WIFI.JK", "EDGE.JK", "MLPT.JK", "DMMX.JK", "MCAS.JK", "NFCX.JK", "DIVA.JK", "WIRG.JK", "KREN.JK", "LUCK.JK", "CYBR.JK"},
    "teknologi AS": {"AAPL", "MSFT", "GOOGL", "AMZN", "META", "ORCL", "CRM", "IBM", "ADBE", "INTU", "NOW", "CSCO"},
    "semikonduktor": {"NVDA", "AMD", "AVGO", "QCOM", "TXN", "INTC", "MU", "AMAT", "LRCX", "KLAC"},
    "kendaraan listrik": {"TSLA", "RIVN", "LCID", "NIO", "XPEV", "LI"},
}

PEER_NAMES = {code + (".JK" if market == "id" else ""): name for code, name, market in POPULAR}
PEER_NAMES.update({
    "BBTN.JK": "Bank Tabungan Negara", "BNGA.JK": "Bank CIMB Niaga", "NISP.JK": "Bank OCBC NISP",
    "BDMN.JK": "Bank Danamon", "MEGA.JK": "Bank Mega", "PNBN.JK": "Bank Pan Indonesia",
    "BJBR.JK": "Bank BJB", "BJTM.JK": "Bank Jatim", "BBYB.JK": "Bank Neo Commerce",
    "BANK.JK": "Bank Aladin Syariah", "AGRO.JK": "Bank Raya Indonesia", "AMAR.JK": "Bank Amar Indonesia",
    "DNAR.JK": "Bank Oke Indonesia", "BBSI.JK": "Krom Bank Indonesia", "FREN.JK": "Smartfren Telecom",
    "TBIG.JK": "Tower Bersama Infrastructure", "MTEL.JK": "Dayamitra Telekomunikasi", "CENT.JK": "Centratama Telekomunikasi",
    "ROTI.JK": "Nippon Indosari Corpindo", "GOOD.JK": "Garudafood Putra Putri Jaya", "ULTJ.JK": "Ultrajaya Milk Industry",
    "CLEO.JK": "Sariguna Primatirta", "CMRY.JK": "Cisarua Mountain Dairy", "KEJU.JK": "Mulia Boga Raya",
    "STTP.JK": "Siantar Top", "HOKI.JK": "Buyung Poetra Sembada", "WIIM.JK": "Wismilak Inti Makmur",
    "ITIC.JK": "Indonesian Tobacco", "AADI.JK": "Adaro Andalan Indonesia", "HRUM.JK": "Harum Energy",
    "INDY.JK": "Indika Energy", "BUMI.JK": "Bumi Resources", "DOID.JK": "Delta Dunia Makmur",
    "GEMS.JK": "Golden Energy Mines", "MBAP.JK": "Mitrabara Adiperdana", "BYAN.JK": "Bayan Resources",
    "NCKL.JK": "Trimegah Bangun Persada", "MBMA.JK": "Merdeka Battery Materials", "TINS.JK": "Timah",
    "ZINC.JK": "Kapuas Prima Coal", "DKFT.JK": "Central Omega Resources", "RAJA.JK": "Rukun Raharja",
    "ELSA.JK": "Elnusa", "AKRA.JK": "AKR Corporindo", "ENRG.JK": "Energi Mega Persada",
    "ESSA.JK": "ESSA Industries Indonesia", "AGII.JK": "Samator Indo Gas", "CHEM.JK": "Chemstar Indonesia",
    "INTP.JK": "Indocement Tunggal Prakarsa", "WSBP.JK": "Waskita Beton Precast", "WTON.JK": "Wijaya Karya Beton",
    "SMBR.JK": "Semen Baturaja", "MIDI.JK": "Midi Utama Indonesia", "LPPF.JK": "Matahari Department Store",
    "ERAA.JK": "Erajaya Swasembada", "RALS.JK": "Ramayana Lestari Sentosa", "MAPA.JK": "Map Aktif Adiperkasa",
    "JPFA.JK": "Japfa Comfeed Indonesia", "MAIN.JK": "Malindo Feedmill", "AALI.JK": "Astra Agro Lestari",
    "LSIP.JK": "PP London Sumatra Indonesia", "SIMP.JK": "Salim Ivomas Pratama", "DSNG.JK": "Dharma Satya Nusantara",
    "SSMS.JK": "Sawit Sumbermas Sarana", "TBLA.JK": "Tunas Baru Lampung", "TAPG.JK": "Triputra Agro Persada",
    "SGRO.JK": "Sampoerna Agro", "BSDE.JK": "Bumi Serpong Damai", "CTRA.JK": "Ciputra Development",
    "PWON.JK": "Pakuwon Jati", "SMRA.JK": "Summarecon Agung", "ASRI.JK": "Alam Sutera Realty",
    "LPKR.JK": "Lippo Karawaci", "DMAS.JK": "Puradelta Lestari", "KIJA.JK": "Kawasan Industri Jababeka",
    "PPRO.JK": "PP Properti", "APLN.JK": "Agung Podomoro Land", "WIKA.JK": "Wijaya Karya",
    "PTPP.JK": "PP (Persero)", "ADHI.JK": "Adhi Karya", "WSKT.JK": "Waskita Karya",
    "TOTL.JK": "Total Bangun Persada", "SSIA.JK": "Surya Semesta Internusa", "NRCA.JK": "Nusa Raya Cipta",
    "WIFI.JK": "Solusi Sinergi Digital", "EDGE.JK": "Indointernet", "MLPT.JK": "Multipolar Technology",
    "KREN.JK": "Kresna Graha Investama", "LUCK.JK": "Sentral Mitra Informatika", "CYBR.JK": "ITSEC Asia",
    "BELI.JK": "Global Digital Niaga", "ORCL": "Oracle", "CRM": "Salesforce", "IBM": "IBM",
    "ADBE": "Adobe", "INTU": "Intuit", "NOW": "ServiceNow", "CSCO": "Cisco Systems",
    "AMD": "Advanced Micro Devices", "AVGO": "Broadcom", "QCOM": "Qualcomm", "TXN": "Texas Instruments",
    "INTC": "Intel", "MU": "Micron Technology", "AMAT": "Applied Materials", "LRCX": "Lam Research",
    "KLAC": "KLA Corporation", "RIVN": "Rivian", "LCID": "Lucid Group", "NIO": "NIO Inc.",
    "XPEV": "XPeng", "LI": "Li Auto",
})


def _market_universe(ticker):
    """Kandidat fallback dari seluruh simbol yang dikenal proyek, dibatasi pasar yang sama."""
    is_id = ticker.endswith(".JK")
    symbols = set()
    for members in PEER_GROUPS.values():
        symbols.update(members)
    for code, _name, market in POPULAR:
        if market == ("id" if is_id else "us"):
            symbols.add(code + ".JK" if market == "id" and not code.endswith(".JK") else code)
    return {s for s in symbols if s.endswith(".JK") == is_id and s != ticker}


def _dynamic_peer_group(ticker):
    """Coba inferir grupo usando sector/industry de Yahoo Finance; no depende de que el ticker esté curado."""
    try:
        info = yf.Ticker(ticker).info or {}
    except Exception as exc:
        log.info("Metadata sector unavailable for %s: %s", ticker, exc)
        info = {}
    sector = str(info.get("sector") or "").strip().lower()
    industry = str(info.get("industry") or "").strip().lower()
    text = f"{sector} {industry}"
    # La coincidencia sectorial es una heurística inicial, visible al usuario; no equivale a pares perfectos.
    rules = [
        (("real estate", "reit", "property", "real estate development"), "properti dan kawasan"),
        (("bank", "financial services", "credit services", "capital markets", "insurance", "financial data"), "bank besar"),
        (("telecom", "communication services", "wireless", "integrated telecommunication"), "telekomunikasi"),
        (("software", "internet content", "electronic gaming", "information technology", "technology", "digital"), "teknologi digital/platform"),
        (("semiconductor", "semiconductors"), "semikonduktor"),
        (("coal", "thermal coal", "coking coal"), "pertambangan batu bara"),
        (("oil", "gas", "energy", "uranium", "oil & gas"), "energi dan gas"),
        (("metal", "mineral", "gold", "copper", "aluminum", "steel", "materials"), "logam dan mineral"),
        (("chemical", "chemicals", "petrochemical"), "petrokimia dan bahan kimia"),
        (("cement", "building materials"), "semen dan bahan bangunan"),
        (("retail", "specialty retail", "department stores", "consumer cyclical"), "ritel"),
        (("food", "beverage", "consumer defensive", "packaged foods", "tobacco"), "barang konsumsi"),
        (("farm products", "agricultural inputs", "agriculture", "palm oil"), "perkebunan sawit"),
        (("construction", "engineering", "infrastructure", "industrials"), "konstruksi dan infrastruktur"),
        (("healthcare", "biotechnology", "drug manufacturers", "medical devices", "pharmaceutical"), "kesehatan dan farmasi"),
    ]
    for needles, group in rules:
        if any(n in text for n in needles) and group in PEER_GROUPS:
            members = PEER_GROUPS[group]
            peers = sorted(members - {ticker})
            if peers:
                return group, peers, "metadata"
    # Bila sektor tak dikenali, tetap sediakan kandidat dari pasar yang sama agar fitur dapat dipakai
    # untuk ticker di luar daftar kurasi. Labelnya secara eksplisit menandai bahwa sektor belum terverifikasi.
    candidates = sorted(_market_universe(ticker))
    return ("Saham pasar yang sama — sektor belum terverifikasi", candidates, "market_fallback") if candidates else (None, [], "unavailable")


def find_peer_group(ticker):
    normalized = ticker.upper()
    if normalized.endswith(".JK"):
        normalized = normalized[:-3] + ".JK"
    for group, members in PEER_GROUPS.items():
        if normalized in members:
            return group, sorted(members - {normalized}), "curated"
    # Alias tanpa suffix untuk kode IDX yang diketik pengguna.
    for group, members in PEER_GROUPS.items():
        aliases = {x[:-3] if x.endswith(".JK") else x for x in members}
        if normalized in aliases:
            match = next(x for x in members if (x[:-3] if x.endswith(".JK") else x) == normalized)
            return group, sorted(members - {match}), "curated"
    return _dynamic_peer_group(normalized)


@app.get("/api/peers")
def peers():
    try:
        ticker = parse_ticker(request.args.get("ticker"))
        market = (request.args.get("market") or "auto").lower()
        if market not in ("auto", "id", "us"):
            raise AnalysisError(400, "Pasar tidak valid.")
        normalized = ticker if ticker.endswith(".JK") or "." in ticker or ticker.startswith("^") else (ticker + ".JK" if market == "id" else ticker)
        group, candidates, match_method = find_peer_group(normalized)
        # Bila mode auto, coba kode Indonesia untuk kelompok IDX yang dikenal.
        if not candidates and market == "auto" and not ticker.endswith(".JK"):
            group, candidates, match_method = find_peer_group(ticker + ".JK")
        results = []
        for candidate in candidates:
            plain = candidate[:-3] if candidate.endswith(".JK") else candidate
            results.append({"ticker": plain, "name": PEER_NAMES.get(candidate, plain),
                            "market": "id" if candidate.endswith(".JK") else "us"})
        return respond({"ok": True, "ticker": ticker, "group": group, "peers": results, "match_method": match_method,
                        "note": ("Kelompok diestimasi dari metadata sektor/industri; verifikasi model bisnis dan laporan terbaru." if match_method == "metadata" else ("Ticker belum punya klasifikasi sektor yang cocok. Kandidat ditampilkan dari pasar yang sama dan bukan semuanya peer langsung." if match_method == "market_fallback" else "Daftar kandidat berbasis kelompok bisnis umum yang dikurasi; verifikasi sektor dan model bisnis dari laporan terbaru."))})
    except AnalysisError as e:
        return respond({"ok": False, "error": e.message}, e.status)


@app.get("/api/compare")
def compare():
    try:
        market, years = parse_common()
        raw = [x for x in re.split(r"[,\s;]+", (request.args.get("tickers") or "").upper()) if x]
        tickers = list(dict.fromkeys(raw))
        if len(tickers) < 2:
            raise AnalysisError(400, "Masukkan minimal 2 kode saham, pisahkan dengan koma.")
        tickers = [parse_ticker(t) for t in tickers]
    except AnalysisError as e:
        return respond({"ok": False, "error": e.message}, e.status)

    def work(t):
        try:
            return summarize_for_compare(analyze_one(t, market, years, True, {}))
        except AnalysisError as e:
            return {"ticker": t, "error": e.message}
        except Exception as e:  # jangan biarkan satu saham menggagalkan seluruh perbandingan
            log.exception("Compare %s gagal", t)
            return {"ticker": t, "error": str(e)}

    with ThreadPoolExecutor(max_workers=min(4, len(tickers))) as pool:
        rows = list(pool.map(work, tickers))
    ok = sorted([r for r in rows if "error" not in r], key=lambda r: r["score"], reverse=True)
    bad = [r for r in rows if "error" in r]
    return respond({"ok": True, "results": ok + bad})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)

# Forex candles: prefer Twelve Data when an API key is configured; fallback Yahoo (may be delayed).
def _forex_history(pair, interval):
    key = os.environ.get("TWELVEDATA_API_KEY", "").strip()
    td_intervals = {"1d": "1day", "4h": "4h", "1h": "1h", "15m": "15min", "5m": "5min"}
    if key:
        symbol = pair.replace("=X", "")
        if len(symbol) == 6 and "/" not in symbol:
            symbol = symbol[:3] + "/" + symbol[3:]
        params = urlencode({"symbol": symbol, "interval": td_intervals[interval], "outputsize": 500, "apikey": key, "format": "JSON"})
        raw = ds._get_json("https://api.twelvedata.com/time_series?" + params)
        if isinstance(raw, dict) and raw.get("status") == "error":
            raise RuntimeError(str(raw.get("message", "Twelve Data error"))[:160])
        values = raw.get("values") if isinstance(raw, dict) else None
        if values:
            frame = pd.DataFrame(values)
            frame["datetime"] = pd.to_datetime(frame["datetime"], errors="coerce")
            for col in ("open", "high", "low", "close", "volume"):
                if col not in frame: frame[col] = 0
                frame[col] = pd.to_numeric(frame[col], errors="coerce")
            frame = frame.dropna(subset=["datetime", "close"]).sort_values("datetime").set_index("datetime")
            frame = frame.rename(columns={"open":"Open", "high":"High", "low":"Low", "close":"Close", "volume":"Volume"})
            for col in ("Open", "High", "Low"):
                if col not in frame: frame[col] = frame["Close"]
            return frame, "Twelve Data API (ketersediaan real-time tergantung paket/kuota)"
        raise RuntimeError("Twelve Data tidak mengembalikan candle untuk simbol/timeframe ini")
    period_interval = {"1d": ("1d", "6mo"), "4h": ("1h", "60d"), "1h": ("1h", "30d"), "15m": ("15m", "5d"), "5m": ("5m", "1d")}
    yi, span = period_interval[interval]
    frame = yf.Ticker(pair).history(period=span, interval=yi, auto_adjust=False)
    if interval == "4h" and not frame.empty:
        frame = frame.resample("4h").agg({"Open":"first", "High":"max", "Low":"min", "Close":"last", "Volume":"sum"}).dropna(subset=["Close"])
    return frame, "Yahoo Finance (dapat tertunda; bukan feed tick real-time terjamin)"

# Local-only WebSocket config. Do not expose the Twelve Data key from a public deployment.
@app.get("/api/forex-stream-config")
def forex_stream_config():
    # Twelve Data requires the API key in its WebSocket URL. Exposing it to the
    # browser is acceptable only for local testing; production should use a
    # private streaming relay on a persistent server. Vercel serverless is not
    # suitable for hosting a persistent inbound WebSocket relay.
    if os.environ.get("VERCEL") or os.environ.get("ALLOW_BROWSER_FOREX_STREAM", "1") != "1":
        return respond({"ok": False, "error": "Streaming browser langsung hanya diizinkan untuk tes lokal. Gunakan relay WebSocket privat untuk deployment publik."}, 403)
    key = os.environ.get("TWELVEDATA_API_KEY", "").strip()
    if not key:
        return respond({"ok": False, "error": "TWELVEDATA_API_KEY belum diatur."}, 503)
    return respond({"ok": True, "api_key": key})

# Forex technical-analysis endpoint (provider-aware; historical candles are loaded by REST).
@app.get("/api/forex")
def forex_analysis():
    pair = (request.args.get("pair", "EURUSD=X").strip().upper())
    interval = request.args.get("interval", "1d").strip().lower()
    allowed = {"1d": ("1d", "6mo"), "4h": ("1h", "60d"), "1h": ("1h", "30d"), "15m": ("15m", "5d"), "5m": ("5m", "1d")}
    if interval not in allowed:
        return respond({"ok": False, "error": "Timeframe tidak didukung."}, 400)
    if not re.fullmatch(r"[A-Z]{6}=X", pair):
        return respond({"ok": False, "error": "Pasangan harus format forex Yahoo Finance, contoh EURUSD=X."}, 400)
    try:
        hist, data_source = _forex_history(pair, interval)
        if hist is None or hist.empty:
            return respond({"ok": False, "error": "Data forex tidak tersedia. Coba timeframe lain."}, 404)
        hist = hist.dropna(subset=["Close"])
        close = hist["Close"].astype(float)
        def ema(series, n): return series.ewm(span=n, adjust=False).mean()
        e20, e50 = ema(close, 20), ema(close, 50)
        delta = close.diff(); gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean(); loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
        rs = gain / loss.replace(0, float("nan")); rsi = 100 - (100 / (1 + rs))
        macd = ema(close, 12) - ema(close, 26); signal = ema(macd, 9)
        last = float(close.iloc[-1]); rsi_v = float(rsi.iloc[-1]) if rsi.notna().any() else 50
        bullish = int(last > float(e20.iloc[-1])) + int(float(e20.iloc[-1]) > float(e50.iloc[-1])) + int(float(macd.iloc[-1]) > float(signal.iloc[-1])) + int(rsi_v >= 50 and rsi_v < 70)
        bearish = int(last < float(e20.iloc[-1])) + int(float(e20.iloc[-1]) < float(e50.iloc[-1])) + int(float(macd.iloc[-1]) < float(signal.iloc[-1])) + int(rsi_v <= 50 and rsi_v > 30)
        trend = "BULLISH" if bullish >= 3 else ("BEARISH" if bearish >= 3 else "SIDEWAYS / MIXED")
        recent = hist.tail(120)
        data = [{"time": idx.strftime("%Y-%m-%d %H:%M"), "open": float(row.Open), "high": float(row.High), "low": float(row.Low), "close": float(row.Close), "ema20": float(e20.loc[idx]), "ema50": float(e50.loc[idx])} for idx, row in recent.iterrows()]
        # Swing-based support/resistance: local pivots in the latest 80 bars.
        window = hist.tail(80)
        lows = window["Low"].astype(float); highs = window["High"].astype(float)
        pivot_supports = [float(lows.iloc[i]) for i in range(2, len(window)-2) if lows.iloc[i] <= min(lows.iloc[i-2:i+3])]
        pivot_resistances = [float(highs.iloc[i]) for i in range(2, len(window)-2) if highs.iloc[i] >= max(highs.iloc[i-2:i+3])]
        support = max((x for x in pivot_supports if x < last), default=float(recent["Low"].tail(30).min()))
        resistance = min((x for x in pivot_resistances if x > last), default=float(recent["High"].tail(30).max()))
        # Simple, explicit order-block heuristic: last opposite candle before a >= 2-bar displacement.
        ob = None
        bars = hist.tail(80)
        for i in range(len(bars)-3, max(2, len(bars)-35), -1):
            row = bars.iloc[i]
            future = bars.iloc[i+1:min(i+4, len(bars))]
            if len(future) < 2: continue
            avg_range = float((bars["High"] - bars["Low"]).tail(20).mean())
            if avg_range <= 0: continue
            move_up = float(future["Close"].max() - row["High"]) >= 1.2 * avg_range and float(row["Close"]) < float(row["Open"])
            move_down = float(row["Low"] - future["Close"].min()) >= 1.2 * avg_range and float(row["Close"]) > float(row["Open"])
            if move_up or move_down:
                ob = {"type": "BULLISH ORDER BLOCK" if move_up else "BEARISH ORDER BLOCK", "low": float(row["Low"]), "high": float(row["High"]), "time": bars.index[i].strftime("%Y-%m-%d %H:%M"), "direction": "bullish" if move_up else "bearish"}
                break
        # Supply/demand base-pattern heuristic: identify a compact base with impulsive
        # candles before/after it. Pattern labels are approximate OHLC heuristics.
        patterns = []
        pat_bars = hist.tail(100)
        ranges = (pat_bars["High"].astype(float) - pat_bars["Low"].astype(float))
        avg_range = float(ranges.tail(20).mean()) if len(ranges) else 0.0
        if avg_range > 0 and len(pat_bars) >= 8:
            for i in range(len(pat_bars)-4, 2, -1):
                base = pat_bars.iloc[i-1:i+1]
                before = pat_bars.iloc[i-3:i-1]
                after = pat_bars.iloc[i+1:i+3]
                if len(before) < 2 or len(after) < 2: continue
                base_size = float((base["High"].max() - base["Low"].min()))
                up_before = float(before["Close"].iloc[-1] - before["Open"].iloc[0])
                up_after = float(after["Close"].iloc[-1] - after["Open"].iloc[0])
                down_before = -up_before
                down_after = -up_after
                if base_size <= 2.0 * avg_range:
                    label = None
                    if up_before >= 1.0*avg_range and up_after >= 1.0*avg_range: label = "RALLY-BASE-RALLY (demand)"
                    elif down_before >= 1.0*avg_range and down_after >= 1.0*avg_range: label = "DROP-BASE-DROP (supply)"
                    elif up_before >= 1.0*avg_range and down_after >= 1.0*avg_range: label = "RALLY-BASE-DROP (supply)"
                    elif down_before >= 1.0*avg_range and up_after >= 1.0*avg_range: label = "DROP-BASE-RALLY (demand)"
                    if label:
                        patterns.append({"type": label, "low": float(base["Low"].min()), "high": float(base["High"].max()), "time": base.index[0].strftime("%Y-%m-%d %H:%M"), "direction": "demand" if "demand" in label else "supply"})
                        if len(patterns) >= 3: break
        # Fibonacci retracement of the recent 80-bar swing range.
        swing_high = float(window["High"].max()); swing_low = float(window["Low"].min())
        fib_range = swing_high - swing_low
        fib = {"swing_high": swing_high, "swing_low": swing_low, "levels": {}}
        if fib_range > 0:
            fib["levels"] = {str(level): (swing_high - fib_range*level) for level in (0.236, 0.382, 0.5, 0.618, 0.786)}
        # Directional premium/discount filter: bullish/demand OB must be wholly
        # below Fib 0.5 (discount); bearish/supply OB must be wholly above it
        # (premium). This is a heuristic filter, not proof of institutional orders.
        fib_mid = fib["levels"].get("0.5")
        if ob and fib_mid is not None:
            ob_is_valid = (ob.get("direction") == "bullish" and float(ob["high"]) < fib_mid) or (ob.get("direction") == "bearish" and float(ob["low"]) > fib_mid)
            if ob_is_valid:
                ob["fib_valid"] = True
                ob["fib_filter"] = "Bullish OB di bawah Fib 0.5 (discount)" if ob.get("direction") == "bullish" else "Bearish OB di atas Fib 0.5 (premium)"
            else:
                ob = None
        action = "POTENSI BUY" if trend == "BULLISH" else ("POTENSI SELL" if trend == "BEARISH" else "WAIT / KONFIRMASI")
        if ob and ob["direction"] == "bullish" and support <= last and trend == "BULLISH":
            strategy = "Cari peluang BUY hanya jika harga retest zona bullish order block/dekat support lalu muncul candle konfirmasi bullish."
        elif ob and ob["direction"] == "bearish" and trend == "BEARISH":
            strategy = "Cari peluang SELL hanya jika harga retest zona bearish order block/dekat resistance lalu muncul candle konfirmasi bearish."
        else:
            strategy = "Belum ada konfluensi kuat. Tunggu retest order block atau support/resistance dan konfirmasi candle; jangan mengejar harga."
        notes = ["Harga di atas EMA20" if last > float(e20.iloc[-1]) else "Harga di bawah EMA20", "EMA20 di atas EMA50" if float(e20.iloc[-1]) > float(e50.iloc[-1]) else "EMA20 di bawah EMA50", "MACD bullish" if float(macd.iloc[-1]) > float(signal.iloc[-1]) else "MACD bearish", "RSI overbought (>70)" if rsi_v > 70 else ("RSI oversold (<30)" if rsi_v < 30 else f"RSI netral: {rsi_v:.1f}")]
        # Indicative trade plan: prioritize matching OB/base demand-supply zone,
        # then S/R. This is a planning aid, not an order or a guaranteed signal.
        atr = float((hist["High"].astype(float) - hist["Low"].astype(float)).tail(14).mean())
        atr = max(atr, abs(last) * 0.0005, 1e-8)
        bullish_zone = ob if ob and ob.get("direction") == "bullish" else None
        bearish_zone = ob if ob and ob.get("direction") == "bearish" else None
        for pat in patterns:
            if pat.get("direction") == "demand" and bullish_zone is None:
                bullish_zone = pat
            if pat.get("direction") == "supply" and bearish_zone is None:
                bearish_zone = pat
        plan = {"status": "WAIT", "direction": "WAIT", "entry": None, "entry_low": None, "entry_high": None, "stop_loss": None, "take_profit": None, "risk_reward": None, "method": "Belum ada gabungan arah dan zona yang cukup", "reason": "Tunggu konfirmasi; jangan memaksakan entry.", "atr": atr}
        if trend == "BULLISH" and bullish_zone:
            zlow, zhigh = float(bullish_zone["low"]), float(bullish_zone["high"])
            entry = (zlow + zhigh) / 2.0
            sl = zlow - 0.15 * atr
            risk = entry - sl
            # Prefer resistance only if it offers a sensible reward; otherwise use 2R target.
            tp = max(float(resistance), entry + 2.0 * risk)
            plan = {"status": "PLAN BUY / TUNGGU RETEST", "direction": "BUY", "entry": entry, "entry_low": zlow, "entry_high": zhigh, "stop_loss": sl, "take_profit": tp, "risk_reward": (tp-entry)/risk if risk > 0 else None, "method": bullish_zone.get("type", "Demand / bullish zone"), "reason": "Rencana entry pada zona demand/order block; tunggu retest dan candle bullish konfirmasi.", "atr": atr}
        elif trend == "BEARISH" and bearish_zone:
            zlow, zhigh = float(bearish_zone["low"]), float(bearish_zone["high"])
            entry = (zlow + zhigh) / 2.0
            sl = zhigh + 0.15 * atr
            risk = sl - entry
            tp = min(float(support), entry - 2.0 * risk)
            plan = {"status": "PLAN SELL / TUNGGU RETEST", "direction": "SELL", "entry": entry, "entry_low": zlow, "entry_high": zhigh, "stop_loss": sl, "take_profit": tp, "risk_reward": (entry-tp)/risk if risk > 0 else None, "method": bearish_zone.get("type", "Supply / bearish zone"), "reason": "Rencana entry pada zona supply/order block; tunggu retest dan candle bearish konfirmasi.", "atr": atr}
        return respond({"ok": True, "data": {"pair": pair, "timeframe": interval, "price": last, "trend": trend, "signal": action, "bullish_score": bullish, "bearish_score": bearish, "rsi": rsi_v, "ema20": float(e20.iloc[-1]), "ema50": float(e50.iloc[-1]), "macd": float(macd.iloc[-1]), "macd_signal": float(signal.iloc[-1]), "support": support, "resistance": resistance, "order_block": ob, "patterns": patterns, "fibonacci": fib, "strategy": strategy, "trade_plan": plan, "notes": notes, "candles": data, "source": data_source + "; order block dan base pattern adalah heuristik OHLC, bukan data order-flow institusi", "updated_at": datetime.now().astimezone().isoformat(), "refresh_seconds": 0, "streaming": bool(os.environ.get("TWELVEDATA_API_KEY", "").strip())}})
    except Exception as exc:
        log.exception("Forex analysis failed")
        return respond({"ok": False, "error": "Gagal mengambil data forex: " + str(exc)[:180]}, 502)
