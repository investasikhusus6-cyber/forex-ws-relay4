"""quant.py - Modul kuantitatif tambahan untuk stock_analyzer.

- calc_extras   : ATR, rasio volume, posisi terhadap high/low 52 minggu
- monte_carlo   : distribusi return ke depan lewat block bootstrap dari return historis
- chart_series  : deret harga + SMA50/SMA200 yang diperkecil untuk grafik
"""
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

TRADING_DAYS = 252


def _f(x: Any) -> Optional[float]:
    try:
        v = float(x)
        return v if np.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def calc_extras(df: pd.DataFrame) -> Dict[str, Optional[float]]:
    """Indikator tambahan dari data OHLCV. Nilai yang tidak bisa dihitung = None."""
    out: Dict[str, Optional[float]] = {
        "atr_pct": None, "vol_ratio": None, "ret_20d_pct": None,
        "high_52w": None, "low_52w": None, "from_high_52w_pct": None,
    }
    close = df["Close"].dropna()
    if len(close) < 30:
        return out
    last = float(close.iloc[-1])

    if {"High", "Low"} <= set(df.columns) and last > 0:
        prev = df["Close"].shift(1)
        tr = pd.concat([(df["High"] - df["Low"]),
                        (df["High"] - prev).abs(),
                        (df["Low"] - prev).abs()], axis=1).max(axis=1)
        atr = tr.ewm(alpha=1 / 14, adjust=False).mean().iloc[-1]
        v = _f(atr)
        out["atr_pct"] = v / last * 100 if v is not None else None

    if "Volume" in df.columns:
        vol = df["Volume"].astype(float)
        if len(vol) >= 120:
            v20, v120 = float(vol.tail(20).mean()), float(vol.tail(120).mean())
            if v120 > 0 and np.isfinite(v20):
                out["vol_ratio"] = v20 / v120

    if len(close) > 21:
        out["ret_20d_pct"] = float((close.iloc[-1] / close.iloc[-21] - 1) * 100)

    yr = close.tail(TRADING_DAYS)
    hi, lo = float(yr.max()), float(yr.min())
    out["high_52w"], out["low_52w"] = hi, lo
    out["from_high_52w_pct"] = float((last / hi - 1) * 100) if hi > 0 else None
    return out


def _summ(logret_sum: np.ndarray) -> Dict[str, float]:
    ret = np.expm1(logret_sum)
    q = np.percentile(ret, [5, 25, 50, 75, 95]) * 100
    return {
        "p5": float(q[0]), "p25": float(q[1]), "p50": float(q[2]),
        "p75": float(q[3]), "p95": float(q[4]),
        "mean_pct": float(ret.mean() * 100),
        "prob_loss_pct": float((ret < 0).mean() * 100),
        "prob_loss_15_pct": float((ret < -0.15).mean() * 100),
        "prob_gain_10_pct": float((ret > 0.10).mean() * 100),
    }


def monte_carlo(close: pd.Series, horizon: int = 126, sims: int = 4000,
                block: int = 10, seed: int = 42,
                window: int = TRADING_DAYS * 5) -> Dict[str, Any]:
    """Block bootstrap return harian historis (menjaga autokorelasi/volatility clustering).

    Dua skenario: 'historical_drift' (tren 5 tahun terulang) dan 'neutral_drift'
    (median dipusatkan ke 0; murni sebaran risiko). Ini sebaran statistik dari data masa
    lalu, BUKAN prediksi harga.
    """
    c = close.dropna().tail(window + 1)
    if len(c) < 2:
        return {"available": False, "reason": "data harga kosong"}
    r = np.log(c / c.shift(1)).dropna().to_numpy()
    r = r[np.isfinite(r)]
    n = len(r)
    if n < max(250, block * 5):
        return {"available": False, "reason": f"data hanya {n} hari, minimal 250 untuk Monte Carlo"}

    rng = np.random.default_rng(seed)
    nb = int(np.ceil(horizon / block))
    starts = rng.integers(0, n - block + 1, size=(sims, nb))
    idx = starts[:, :, None] + np.arange(block)[None, None, :]
    paths = r[idx].reshape(sims, nb * block)[:, :horizon]
    mu = float(r.mean())
    hist_sums = paths.sum(axis=1)
    # Skenario netral: sebaran historis digeser agar median = 0 (bentuk risiko tetap, tren dihapus).
    # Pusat di median, bukan rata-rata, supaya satu crash masa lalu tidak membuat median "netral" positif.
    neutral_sums = hist_sums - float(np.median(hist_sums))
    return {
        "available": True,
        "horizon_days": int(horizon), "sims": int(sims), "block": int(block),
        "observations": int(n),
        "annual_drift_pct": float(mu * TRADING_DAYS * 100),
        "historical_drift": _summ(hist_sums),
        "neutral_drift": _summ(neutral_sums),
        "note": ("Sebaran statistik dari return historis (block bootstrap), bukan prediksi. "
                 "Skenario netral memusatkan median ke 0 agar tidak terlalu optimistis."),
    }


def chart_series(close: pd.Series, n: int = 160) -> Dict[str, List[Any]]:
    """Harga + SMA50 + SMA200 diperkecil menjadi maksimal n titik."""
    s = close.dropna()
    if s.empty:
        return {"dates": [], "close": [], "sma50": [], "sma200": []}
    sma50 = s.rolling(50).mean()
    sma200 = s.rolling(200).mean()
    if len(s) > n:
        idx = np.unique(np.linspace(0, len(s) - 1, n).round().astype(int))
    else:
        idx = np.arange(len(s))

    def col(x: pd.Series) -> List[Optional[float]]:
        return [None if not np.isfinite(v) else round(float(v), 4) for v in x.iloc[idx]]

    return {
        "dates": [pd.Timestamp(d).strftime("%Y-%m-%d") for d in s.index[idx]],
        "close": col(s), "sma50": col(sma50), "sma200": col(sma200),
    }
