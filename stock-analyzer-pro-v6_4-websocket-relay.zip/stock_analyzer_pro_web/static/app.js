"use strict";
/* Stock Analyzer Pro v5 - antarmuka web */
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, m => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[m]));
const ok = v => v != null && isFinite(v);
const num = (v, d = 2) => ok(v) ? Number(v).toLocaleString("id-ID", {minimumFractionDigits: d, maximumFractionDigits: d}) : "—";
const pct = (v, d = 1, sign = false) => ok(v) ? (sign && v > 0 ? "+" : "") + num(v, d) + "%" : "—";
const frac = (v, d = 1) => ok(v) ? pct(v * 100, d) : "—";
const compact = v => {
  if (!ok(v)) return "—";
  const a = Math.abs(v);
  if (a >= 1e12) return num(v / 1e12, 2) + " T";
  if (a >= 1e9) return num(v / 1e9, 1) + " M";
  if (a >= 1e6) return num(v / 1e6, 1) + " jt";
  return num(v, 0);
};
const cls = s => s > 0 ? "pos" : s < 0 ? "neg" : "zero";
const safeUrl = u => /^https?:\/\//i.test(u || "") ? u : "#";
const verdictClass = l => l === "LAYAK BELI" ? "buy" : l === "TIDAK LAYAK BELI" ? "sell" : "hold";
const confClass = l => l === "TINGGI" ? "buy" : l === "RENDAH" ? "sell" : "hold";

const GROUP_LABEL = {performa: "Kinerja harga", teknikal: "Teknikal", relatif: "Relatif vs indeks",
  fundamental: "Fundamental", riwayat: "Riwayat 5 th", berita: "Berita", umum: "Lainnya"};
const GROUP_FULL = {performa: "Kinerja harga", teknikal: "Teknikal", relatif: "Relatif vs indeks",
  fundamental: "Fundamental (snapshot)", riwayat: "Riwayat fundamental", berita: "Berita", umum: "Lainnya"};
const GROUP_ORDER = ["performa", "teknikal", "relatif", "fundamental", "riwayat", "berita", "umum"];
const C = {teal: "#42e8a2", blue: "#63adff", amber: "#ffc65a", red: "#ff6d83", grid: "#193047", text: "#9eb0c2"};

let charts = {};
let runSeq = 0;
let lastQuery = null;
let fvState = {defaults: null, ticker: null};

function destroyCharts() { Object.values(charts).forEach(c => { try { c.destroy(); } catch (e) {} }); charts = {}; }
function show(id, on) { $(id).classList.toggle("hide", !on); }

async function api(url, ms = 100000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    const res = await fetch(url, {signal: ctl.signal});
    let j = null;
    try { j = await res.json(); } catch (e) { /* respons bukan JSON (mis. timeout platform) */ }
    if (!j) throw new Error(res.status === 504 || res.status === 502
      ? "Server kehabisan waktu. Coba lagi, atau kurangi modul berat." : `Respons tidak valid (HTTP ${res.status}).`);
    return {status: res.status, ...j};
  } catch (e) {
    if (e.name === "AbortError") throw new Error("Permintaan terlalu lama (timeout).");
    throw e;
  } finally { clearTimeout(t); }
}

function showError(msg) { $("err").textContent = msg; show("err", true); }
function setBanner(html, kind = "info") {
  const b = $("banner");
  if (!html) { show("banner", false); return; }
  b.className = "banner " + kind; b.innerHTML = html; show("banner", true);
}

/* ================= Render dashboard ================= */
function card(label, value, sub, c = "") {
  return `<div class="card"><small>${esc(label)}</small><b class="${c}">${value}</b><span>${sub}</span></div>`;
}

function renderHead(d) {
  const v = d.verdict, c = d.confidence, p = d.profile, m = d.metrics;
  const lc = verdictClass(v.final_label);
  const down = v.downgrade_reasons.length
    ? `<div class="down">Diturunkan dari ${esc(v.label)}: ${esc(v.downgrade_reasons.join(", "))}</div>` : "";
  const mk = d.resolved_market === "id" ? "Bursa Indonesia" : "Pasar AS/Global";
  return `<div class="head panel">
    <div><small>SAHAM</small><h2>${esc(d.ticker)}</h2>
      <span>${esc(p.name || "")}</span>
      <div class="tags"><i>${esc(p.profile)}</i><i>${esc(p.sector || "sektor n/a")}</i><i>${mk}</i></div></div>
    <div><small>${d.data_quality && d.data_quality.price_source === "fast_info" ? "HARGA TERBARU" : "HARGA PENUTUPAN TERAKHIR"}</small><h2>${num(m.price, 2)}</h2>
      <span>${esc(p.currency || "")} · waktu analisis ${new Date(d.timestamp).toLocaleString("id-ID")}</span></div>
    <div class="vbox"><div class="verdict ${lc}">${esc(v.final_label)}</div>
      <div class="conf ${confClass(c.label)}">Keyakinan ${esc(c.label)}</div>${down}</div></div>`;
}

function renderCards(d) {
  const m = d.metrics, v = d.verdict, c = d.confidence;
  const rsiSt = m.rsi14 < 30 ? "jenuh jual" : m.rsi14 > 70 ? "jenuh beli" : "normal";
  return `<div class="cards">
    ${card("SKOR GABUNGAN", num(v.score_pct, 1), "dari 100", v.score_pct >= 65 ? "pos" : v.score_pct >= 45 ? "zero" : "neg")}
    ${card("KEYAKINAN", esc(c.label), `${c.points} poin`, confClass(c.label) === "buy" ? "pos" : confClass(c.label) === "sell" ? "neg" : "zero")}
    ${fvCard(d)}
    ${card("CAGR", pct(m.cagr_pct, 1, true), "per tahun", cls(m.cagr_pct))}
    ${card("RETURN", pct(m.total_return_pct, 1, true), `${num(m.years, 1)} tahun`, cls(m.total_return_pct))}
    ${card("RSI 14", num(m.rsi14, 1), rsiSt)}
    ${card("SHARPE / SORTINO", `${num(m.sharpe, 2)} / ${num(m.sortino, 2)}`, "risk adjusted")}
    ${card("MAX DRAWDOWN", pct(m.max_drawdown_pct, 1), "penurunan terdalam", "neg")}
    ${card("ATR 14", pct(m.atr_pct, 1), "gerak harian")}
  </div>`;
}

function renderPriceAndRadar(d) {
  const m = d.metrics;
  const groups = d.verdict.groups || {};
  const bars = GROUP_ORDER.filter(g => g in groups).map(g =>
    `<div class="gbar"><span>${GROUP_FULL[g]}</span><i><u style="width:${Math.max(2, groups[g])}%" class="${groups[g] >= 65 ? "b" : groups[g] >= 45 ? "h" : "s"}"></u></i><b>${num(groups[g], 0)}</b></div>`).join("");
  return `<div class="grid2">
    <article class="panel"><div class="title"><div><h3>Harga &amp; Tren</h3><small>Harga penutupan, SMA50, SMA200 (data asli)</small></div><span class="tag">${num(m.years, 1)}Y</span></div>
      <div class="chart"><canvas id="priceChart"></canvas></div>
      <div class="stats"><span>LOW <b>${num(m.low_5y, 2)}</b></span><span>HIGH <b>${num(m.high_5y, 2)}</b></span>
      <span>52W HIGH <b>${num(m.high_52w, 2)}</b></span><span>DARI HIGH <b>${pct(m.from_high_52w_pct, 1)}</b></span><span>VOL <b>${pct(m.volatility_pct, 1)}</b></span></div></article>
    <article class="panel"><div class="title"><div><h3>Skor per Kelompok</h3><small>Skor gabungan = rata-rata tertimbang</small></div></div>
      <div class="chart radar"><canvas id="radarChart"></canvas></div><div class="gbars">${bars}</div></article></div>`;
}

function renderMonteCarlo(mc) {
  if (!mc || !mc.available) {
    return `<article class="panel"><div class="title"><div><h3>Monte Carlo</h3><small>Sebaran return ke depan</small></div></div>
      <p class="muted">Tidak tersedia: ${esc((mc && mc.reason) || "dilewati (mode cepat atau batas waktu)")}</p></article>`;
  }
  const sc = [["neutral_drift", "Netral (tanpa tren)", "Median dipusatkan ke 0: murni sebaran risiko"],
              ["historical_drift", "Jika tren historis berulang", `Drift historis ${pct(mc.annual_drift_pct, 1, true)}/thn, cenderung optimistis`]];
  const lo = Math.min(...sc.map(([k]) => mc[k].p5)), hi = Math.max(...sc.map(([k]) => mc[k].p95));
  const pad = (hi - lo) * 0.06, a = lo - pad, b = hi + pad;
  const at = v => ((v - a) / (b - a) * 100).toFixed(2);
  const zero = at(0);
  const rows = sc.map(([k, name, sub]) => {
    const s = mc[k];
    return `<div class="mc"><div class="mch"><b>${name}</b><small>${sub}</small></div>
      <div class="mct"><i class="z" style="left:${zero}%"></i>
        <i class="w" style="left:${at(s.p5)}%;width:${(at(s.p95) - at(s.p5)).toFixed(2)}%"></i>
        <i class="x" style="left:${at(s.p25)}%;width:${(at(s.p75) - at(s.p25)).toFixed(2)}%"></i>
        <i class="m" style="left:${at(s.p50)}%"></i></div>
      <div class="mcn"><span>P5 <b class="neg">${pct(s.p5, 1, true)}</b></span><span>P25 <b>${pct(s.p25, 1, true)}</b></span>
        <span>P50 <b>${pct(s.p50, 1, true)}</b></span><span>P75 <b>${pct(s.p75, 1, true)}</b></span><span>P95 <b class="pos">${pct(s.p95, 1, true)}</b></span></div>
      <div class="mcp">Peluang rugi <b>${num(s.prob_loss_pct, 0)}%</b> · rugi &gt;15% <b>${num(s.prob_loss_15_pct, 0)}%</b> · untung &gt;10% <b>${num(s.prob_gain_10_pct, 0)}%</b></div></div>`;
  }).join("");
  return `<article class="panel"><div class="title"><div><h3>Monte Carlo ${mc.horizon_days} hari</h3><small>${num(mc.sims, 0)} simulasi block bootstrap dari ${num(mc.observations, 0)} return harian</small></div><span class="tag">sebaran</span></div>
    ${rows}<p class="note">${esc(mc.note)}</p></article>`;
}

function renderFundamental(d) {
  const f = d.fundamentals, p = d.profile, price = d.metrics.price;
  const items = [["PER", ok(f.pe) ? num(f.pe, 1) + "x" : (f.eps != null && f.eps <= 0 ? "rugi" : "—")],
    ["EPS", num(f.eps, 2)], ["PBV", ok(f.pb) ? num(f.pb, 2) + "x" : "—"], ["ROE", pct(f.roe_pct, 1)], ["ROA", pct(f.roa_pct, 2)],
    ["Net margin", p.profile === "NON_FINANCIAL" ? pct(f.net_margin_pct, 1) : "n/a (bank)"],
    ["DER", p.profile === "NON_FINANCIAL" ? (ok(f.der_pct) ? num(f.der_pct, 0) + "%" : "—") : "n/a (bank)"],
    ["Dividend yield", pct(f.div_yield_pct, 2)], ["PEG", ok(f.peg) ? num(f.peg, 2) : "—"],
    ["Market cap", compact(p.market_cap)]];
  if (ok(f.target_mean) && f.analyst_n >= 3) {
    items.push([`Target analis (${f.analyst_n})`, `${num(f.target_mean, 0)} (${pct((f.target_mean / price - 1) * 100, 1, true)})`]);
  }
  const grid = items.map(([k, v]) => `<div><small>${esc(k)}</small><b>${esc(v)}</b></div>`).join("");
  const note = p.profile !== "NON_FINANCIAL"
    ? "Profil keuangan/bank: DER konvensional dan net margin tidak dinilai agar tidak salah tafsir. NIM/NPL/LDR/CASA tidak tersedia dari Yahoo, jadi tidak ditebak."
    : "Bandingkan PER/PBV dengan rata-rata sektor; angka snapshot dapat berubah setelah laporan terbaru.";
  return `<article class="panel"><div class="title"><div><h3>Fundamental Snapshot</h3><small>Data terbaru dari sumber</small></div></div>
    <div class="fund">${grid}</div><p class="note">${note}</p></article>`;
}

function renderValuationReference(v, currency) {
  if (!v || !v.available) {
    return `<article class="panel"><div class="title"><div><h3>Referensi Valuasi Historis</h3><small>PER/PBV historis perusahaan</small></div></div>
      <p class="muted">Belum bisa dihitung: ${esc((v && v.reason) || "data tidak tersedia")}</p>
      ${v && (Number.isFinite(v.per_periods) || Number.isFinite(v.pbv_periods)) ? `<p class="note">Periode valid: PER ${Number(v.per_periods || 0)} / 3 minimum · PBV ${Number(v.pbv_periods || 0)} / 3 minimum.</p>` : ""}
      <p class="note">${esc((v && v.hint) || "Estimasi hanya ditampilkan jika riwayat multiple memadai. Angka tidak dibuat dari asumsi yang tidak didukung data.")}</p></article>`;
  }
  const methods = v.methods.map(m => `<div class="crit"><div><b>${esc(m.method)}</b><small>Multiple historis ${num(m.multiple, 2)}x</small></div><span class="val">${num(m.price, 2)} ${esc(currency || "")}</span></div>`).join("");
  const gapClass = v.gap_pct > 5 ? "pos" : v.gap_pct < -5 ? "neg" : "zero";
  return `<article class="panel"><div class="title"><div><h3>Referensi Valuasi Historis</h3><small>Bukan nilai intrinsik / target harga</small></div><span class="tag">${esc(v.label)}</span></div>
    <div class="kpis"><span>Harga terakhir <b>${num(v.current_price, 2)} ${esc(currency || "")}</b></span>
    <span>Referensi tengah <b>${num(v.reference_price, 2)} ${esc(currency || "")}</b></span>
    <span>Selisih indikatif <b class="${gapClass}">${pct(v.gap_pct, 1, true)}</b></span></div>
    <div class="tablewrap">${methods}</div><p class="note">${esc(v.disclaimer)}</p></article>`;
}

function renderHistory(h) {
  if (!h || !h.available) {
    return `<article class="panel wide"><div class="title"><div><h3>Riwayat Fundamental</h3><small>Laporan tahunan</small></div></div>
      <p class="muted">Tidak tersedia: ${esc((h && h.reason) || "dilewati (mode cepat atau batas waktu)")}</p></article>`;
  }
  const s = h.summary;
  const body = h.rows.map(r => `<tr><td><b>${esc(r.year)}</b> <span class="muted">${esc(r.period)}</span></td>
    <td>${compact(r.revenue)}</td><td>${compact(r.net_income)}</td><td>${frac(r.roe)}</td><td>${frac(r.roa, 2)}</td><td>${frac(r.npm)}</td>
    <td>${frac(r.revenue_growth)}</td><td>${frac(r.earnings_growth)}</td><td>${ok(r.cfo_ni) ? num(r.cfo_ni, 2) + "x" : "—"}</td>
    <td>${num(r.historical_per, 1)}</td><td>${num(r.historical_pbv, 2)}</td><td>${num(r.year_end_price, 0)}</td></tr>`).join("");
  return `<article class="panel wide"><div class="title"><div><h3>Riwayat Fundamental</h3><small>${s.periods} laporan tahunan (FY) + TTM bila ada. FY saja yang masuk rata-rata dan CAGR</small></div>
    <span class="tag">${s.profit_years}/${s.profit_years_total} tahun laba</span></div>
    <div class="kpis"><span>CAGR laba <b class="${cls(s.net_income_cagr)}">${frac(s.net_income_cagr)}</b></span><span>CAGR pendapatan <b class="${cls(s.revenue_cagr)}">${frac(s.revenue_cagr)}</b></span>
      <span>ROE rata-rata <b>${frac(s.roe_avg)}</b></span><span>NPM rata-rata <b>${frac(s.npm_avg)}</b></span>
      <span>PER hist. <b>${num(s.per_avg, 1)}</b></span><span>PBV hist. <b>${num(s.pbv_avg, 2)}</b></span></div>
    <div class="chart short"><canvas id="histChart"></canvas></div>
    <div class="tablewrap"><table class="table"><thead><tr><th>Periode</th><th>Pendapatan</th><th>Laba bersih</th><th>ROE</th><th>ROA</th><th>NPM</th>
    <th>Gr. pend.</th><th>Gr. laba</th><th>CFO/NI</th><th>PER hist.</th><th>PBV hist.</th><th>Harga akhir thn</th></tr></thead><tbody>${body}</tbody></table></div>
    <p class="note">FY = tahun fiskal. TTM = 12 bulan terakhir (bukan laporan FY penuh). ROE/ROA dihitung dari ekuitas/aset akhir periode. PER/PBV historis best-effort dari Yahoo dan sering kosong. Data kosong tidak diisi asumsi.</p></article>`;
}

function renderCriteria(d) {
  const groups = d.verdict.groups || {};
  const by = {};
  d.criteria.forEach(c => (by[c.group] = by[c.group] || []).push(c));
  const html = GROUP_ORDER.filter(g => by[g]).map(g => {
    const rows = by[g].map(c => `<div class="crit"><div><b>${esc(c.name)}</b><small>${esc(c.note)}</small></div>
      <span class="val">${esc(c.value)}</span><span class="pill ${cls(c.score)}">${c.score > 0 ? "+" : ""}${c.score}</span></div>`).join("");
    const sc = groups[g];
    return `<details open class="grp"><summary><span>${GROUP_FULL[g]}</span><em>${sc != null ? "skor " + num(sc, 0) + "/100" : ""}</em></summary>${rows}</details>`;
  }).join("");
  return `<article class="panel wide"><div class="title"><div><h3>Rincian Faktor</h3><small>Setiap kriteria: nilai, alasan, dan poinnya</small></div></div>${html}</article>`;
}

function renderBacktest(bt) {
  if (!bt || !bt.available) {
    return `<article class="panel"><div class="title"><div><h3>Backtest</h3><small>Walk-forward tanpa look-ahead</small></div></div>
      <p class="muted">Tidak tersedia: ${esc((bt && bt.reason) || "dilewati (mode cepat atau batas waktu)")}</p></article>`;
  }
  const rows = ["LAYAK BELI", "TAHAN / PANTAU", "TIDAK LAYAK BELI"].filter(l => bt.buckets[l]).map(l => {
    const b = bt.buckets[l];
    return `<tr><td><i class="dot ${verdictClass(l)}"></i>${l}</td><td>${b.n}</td><td>${num(b.hit_rate_pct, 0)}%</td>
      <td>${pct(b.avg_fwd_pct, 1, true)}</td><td>${pct(b.median_fwd_pct, 1, true)}</td><td>${ok(b.beat_rate_pct) ? num(b.beat_rate_pct, 0) + "%" : "—"}</td></tr>`;
  }).join("");
  let edge = `<p class="muted">Tidak ada sinyal BUY pada histori saham ini, jadi keunggulan sinyal tidak bisa diuji.</p>`;
  if (bt.buy_edge_pct != null) {
    const sig = bt.significant ? `<b class="pos">signifikan</b>` : `<b class="zero">belum signifikan</b>`;
    edge = `<div class="edge">Keunggulan sinyal BUY vs rata-rata (untung &gt; bunga bebas risiko): <b class="${cls(bt.buy_edge_pct)}">${pct(bt.buy_edge_pct, 1, true)} poin</b>
      (p=${num(bt.p_value, 3)}, sampel efektif ${num(bt.n_eff, 1)}) → ${sig}.`
      + (bt.buy_beat_edge_pct != null ? `<br>Mengalahkan indeks: <b class="${cls(bt.buy_beat_edge_pct)}">${pct(bt.buy_beat_edge_pct, 1, true)} poin</b> (p=${num(bt.beat_p_value, 3)}) → ${bt.significant_beat ? `<b class="pos">signifikan</b>` : `<b class="zero">belum signifikan</b>`}.` : "")
      + `</div>`;
  }
  return `<article class="panel"><div class="title"><div><h3>Backtest</h3><small>${bt.samples} titik sinyal · horizon ${bt.horizon_days} hari</small></div></div>
    <div class="kpis"><span>Base rate untung <b>${num(bt.base_rate_pct, 0)}%</b></span>${bt.base_beat_pct != null ? `<span>Base rate kalahkan indeks <b>${num(bt.base_beat_pct, 0)}%</b></span>` : ""}</div>
    <div class="tablewrap"><table class="table"><thead><tr><th>Sinyal</th><th>n</th><th>Hit</th><th>Rata-rata</th><th>Median</th><th>Kalahkan indeks</th></tr></thead><tbody>${rows}</tbody></table></div>
    ${edge}<p class="note">Hanya menguji komponen harga/teknikal. Fundamental, berita, dan volume historis point-in-time tidak tersedia, jadi tidak diuji. Window tumpang tindih sudah dikoreksi pada sampel efektif.</p></article>`;
}

function renderNews(n) {
  if (!n || !n.available) {
    return `<article class="panel"><div class="title"><div><h3>Berita &amp; Sentimen</h3><small>Berita sebagai rem risiko</small></div></div>
      <p class="muted">Tidak tersedia: ${esc((n && n.reason) || "dilewati (mode cepat atau batas waktu)")}</p></article>`;
  }
  const items = n.items.slice(0, 6).map(it => {
    const mk = it.sentiment > 0.1 ? "pos" : it.sentiment < -0.1 ? "neg" : "zero";
    const age = it.age_hours < 48 ? Math.round(it.age_hours) + " jam" : Math.round(it.age_hours / 24) + " hari";
    return `<div class="newsitem ${mk}"><a href="${esc(safeUrl(it.url))}" target="_blank" rel="noopener noreferrer">${esc(it.title)}</a><small>${esc(it.source)} · ${age} lalu</small></div>`;
  }).join("");
  const flags = (n.critical_flags || []).slice(0, 4).map(f => `<div class="flag">⚠ ${esc(f.flag)}: ${esc(f.title)}</div>`).join("");
  const cata = n.catalysts && n.catalysts.length ? `<p class="muted">Katalis terdeteksi: ${esc(n.catalysts.join(", "))}</p>` : "";
  return `<article class="panel"><div class="title"><div><h3>Berita &amp; Sentimen</h3><small>${n.count} berita · ${n.sources} sumber</small></div>
    <span class="tag ${n.label === "NEGATIF" ? "neg" : n.label === "POSITIF" ? "pos" : ""}">${esc(n.label)} ${num(n.score, 2)}</span></div>
    ${flags}<div class="news">${items}</div>${cata}
    <p class="note">Sentimen dari kamus kata pada judul saja (kasar). Berita hanya bisa menurunkan vonis, tidak menaikkannya.${n.sufficient ? "" : " Jumlah berita kurang dari minimum sehingga tidak ikut skor."}</p></article>`;
}

function renderRisk(d) {
  const flags = d.risk_flags.length ? d.risk_flags.map(f => `<div class="flag">⚠ ${esc(f)}</div>`).join("")
    : `<p class="muted">Tidak ada penanda risiko dari mesin analisis.</p>`;
  const reasons = d.confidence.reasons.map(r => {
    const c = r.startsWith("+") ? "pos" : r.startsWith("-") ? "neg" : "zero";
    return `<div class="rs ${c}">${esc(r)}</div>`;
  }).join("");
  const dq = d.data_quality;
  const dqw = dq.warnings.map(w => `<div class="flag">! ${esc(w)}</div>`).join("");
  return `<article class="panel"><div class="title"><div><h3>Risiko &amp; Keyakinan</h3><small>Mengapa angka ini bisa dipercaya (atau tidak)</small></div>
    <span class="tag ${confClass(d.confidence.label) === "buy" ? "pos" : confClass(d.confidence.label) === "sell" ? "neg" : ""}">${esc(d.confidence.label)}</span></div>
    <h4>Penanda risiko</h4>${flags}<h4>Rincian keyakinan</h4>${reasons}
    <h4>Kualitas data</h4><div class="quality"><span>Skor <b>${dq.score}/100</b></span><i><u style="width:${dq.score}%"></u></i></div>${dqw}${renderSources(d)}</article>`;
}

function renderWhy(d) {
  const pos = d.criteria.filter(c => c.score > 0).map(c => c.name), neg = d.criteria.filter(c => c.score < 0).map(c => c.name);
  return `<article class="panel"><div class="title"><div><h3>Mengapa vonis ini?</h3><small>Ringkasan faktor</small></div></div>
    <div class="reason good"><b>+</b><div><strong>Pendukung</strong><p>${esc(pos.join(", ") || "-")}</p></div></div>
    <div class="reason bad"><b>−</b><div><strong>Penghambat</strong><p>${esc(neg.join(", ") || "-")}</p></div></div>
    <div class="note">⚠ Bukan nasihat keuangan. Keyakinan mengukur keandalan data dan sinyal, bukan kepastian harga. Berita dan keyakinan hanya bisa menurunkan vonis, tidak menaikkannya.</div></article>`;
}

function render(d) {
  destroyCharts();
  $("dash").innerHTML = renderHead(d) + renderCards(d) + renderPriceAndRadar(d) + renderFairValue(d)
    + `<div class="grid2">${renderMonteCarlo(d.montecarlo)}${renderFundamental(d)}</div>`
    + `<div class="grid2">${renderValuationReference(d.valuation_reference, d.profile.currency)}${renderHistory(d.history)}</div>` + renderCriteria(d)
    + `<div class="grid2">${renderBacktest(d.backtest)}${renderNews(d.news)}</div>`
    + `<div class="grid2">${renderRisk(d)}${renderWhy(d)}</div>` + renderPeerPanel(d);
  show("dash", true);
  initFairValue(d);
  bindSources(d);
  const peerButton = $("findPeers");
  if (peerButton) peerButton.addEventListener("click", () => loadPeers(d.ticker, d.resolved_market));
  drawCharts(d);
}

/* ================= Saham serupa ================= */
function renderPeerPanel(d) {
  return `<article class="panel wide" id="peerPanel"><div class="title"><div><h3>Bandingkan dengan Saham Serupa</h3><small>Cari pembanding berdasarkan sektor/industri; jika metadata tidak tersedia, tampilkan kandidat dari pasar yang sama</small></div>
    <button type="button" id="findPeers" class="secondary">Cari saham serupa</button></div>
    <p class="muted" id="peerStatus">Saham utama: <b>${esc(d.ticker)}</b>. Pembanding adalah kandidat untuk diteliti, bukan rekomendasi beli.</p>
    <div id="peerResults" class="chips"></div></article>`;
}

async function loadPeers(ticker, market) {
  const status = $("peerStatus"), results = $("peerResults"), button = $("findPeers");
  if (!status || !results || !button) return;
  button.disabled = true; button.textContent = "Mencari...";
  status.textContent = "Memeriksa kelompok sektor dan kandidat pembanding...";
  results.innerHTML = "";
  try {
    const r = await api(`/api/peers?ticker=${encodeURIComponent(ticker)}&market=${encodeURIComponent(market || "auto")}`);
    if (!r.ok) throw new Error(r.error || "Pencarian saham serupa gagal.");
    if (!r.peers || !r.peers.length) {
      status.textContent = `Belum ada daftar pembanding yang cukup kuat untuk ${ticker}. Kamu tetap bisa mengetik kode saham lain di kolom atas.`;
      return;
    }
    const peers = r.peers;
    status.innerHTML = `Kelompok: <b>${esc(r.group || r.sector || "kelompok bisnis")}</b> · ${peers.length} kandidat. ${esc(r.note || "Periksa kembali kesamaan bisnis sebelum membandingkan.")}`;
    results.innerHTML = `<div class="peer-tools"><label><input type="checkbox" id="selectAllPeers"> Pilih semua kandidat</label><span class="muted">Pilih semua saham serupa yang tersedia, atau centang kandidat tertentu.</span></div>`
      + `<div class="peer-list">${peers.map(p => `<label class="peer-option" title="${esc(p.name || p.ticker)}"><input type="checkbox" class="peer-select" value="${esc(p.ticker)}"><span><b>${esc(p.ticker)}</b><small>${esc(p.name || "Nama belum tersedia")}</small></span></label>`).join("")}</div>`
      + `<button type="button" class="secondary" id="comparePeers">Bandingkan saham terpilih</button>`;
    const selectAll = $("selectAllPeers");
    const selections = () => [...results.querySelectorAll(".peer-select:checked")];
    results.querySelectorAll(".peer-select").forEach(el => el.addEventListener("change", () => {
      const selected = selections();
      if (selectAll) selectAll.checked = selections().length === peers.length;
      const btn = $("comparePeers"); if (btn) btn.textContent = `Bandingkan saham terpilih (${selections().length})`;
    }));
    if (selectAll) selectAll.addEventListener("change", () => {
      const allInputs = [...results.querySelectorAll(".peer-select")];
      allInputs.forEach(el => { el.checked = selectAll.checked; });
      if (selectAll.checked) status.textContent = `Semua ${peers.length} kandidat dipilih. Proses dapat lebih lama jika daftar besar; saham yang gagal dimuat akan ditandai di hasil.`;
      const btn = $("comparePeers"); if (btn) btn.textContent = `Bandingkan saham terpilih (${selections().length})`;
    });
    const compareBtn = $("comparePeers");
    if (compareBtn) compareBtn.addEventListener("click", () => {
      const chosen = selections().map(el => el.value);
      if (!chosen.length) { status.textContent = "Pilih minimal satu saham pembanding terlebih dahulu."; return; }
      const all = [ticker, ...chosen];
      $("ticker").value = all.join(", "); analyzeCompare(all);
    });
  } catch (e) {
    status.textContent = `Tidak bisa mencari saham serupa: ${e.message}`;
  } finally {
    if ($( "findPeers")) { $("findPeers").disabled = false; $("findPeers").textContent = "Cari saham serupa"; }
  }
}

/* ================= Grafik ================= */
const baseOpts = {responsive: true, maintainAspectRatio: false, interaction: {mode: "index", intersect: false},
  plugins: {legend: {labels: {color: C.text, boxWidth: 10, font: {size: 10}}}},
  scales: {x: {ticks: {color: C.text, maxTicksLimit: 8, font: {size: 9}}, grid: {color: "#ffffff08"}},
           y: {ticks: {color: C.text, font: {size: 9}}, grid: {color: C.grid}}}};

function noChart(id) {
  const el = $(id);
  if (el) el.parentElement.innerHTML = `<p class="muted">Grafik tidak dapat dimuat (library Chart.js diblokir/offline).</p>`;
}

function drawCharts(d) {
  if (!window.Chart) { ["priceChart", "radarChart", "histChart"].forEach(noChart); return; }
  Chart.defaults.font.family = "Inter, Arial, sans-serif";
  const ch = d.chart;
  if ($("priceChart") && ch && ch.dates.length) {
    charts.price = new Chart($("priceChart"), {type: "line", data: {labels: ch.dates, datasets: [
      {label: "Harga", data: ch.close, borderColor: C.teal, backgroundColor: "#42e8a214", fill: true, pointRadius: 0, borderWidth: 2, tension: .15},
      {label: "SMA50", data: ch.sma50, borderColor: C.blue, pointRadius: 0, borderWidth: 1.2, borderDash: [4, 3], spanGaps: false},
      {label: "SMA200", data: ch.sma200, borderColor: C.amber, pointRadius: 0, borderWidth: 1.2, borderDash: [4, 3], spanGaps: false}]},
      options: baseOpts});
  }
  const g = d.verdict.groups || {};
  const keys = GROUP_ORDER.filter(k => k in g);
  if ($("radarChart") && keys.length >= 3) {
    charts.radar = new Chart($("radarChart"), {type: "radar", data: {labels: keys.map(k => GROUP_LABEL[k]), datasets: [
      {label: "Skor", data: keys.map(k => g[k]), borderColor: C.teal, backgroundColor: "#42e8a233", pointBackgroundColor: C.teal}]},
      options: {responsive: true, maintainAspectRatio: false, plugins: {legend: {display: false}},
        scales: {r: {min: 0, max: 100, ticks: {display: false, stepSize: 25}, grid: {color: C.grid}, angleLines: {color: C.grid},
          pointLabels: {color: C.text, font: {size: 10}}}}}});
  } else if ($("radarChart")) {
    $("radarChart").parentElement.innerHTML = `<p class="muted">Radar butuh minimal 3 kelompok data.</p>`;
  }
  const h = d.history;
  if ($("histChart") && h && h.available && h.rows.length) {
    const rows = h.rows;
    charts.hist = new Chart($("histChart"), {type: "bar", data: {labels: rows.map(r => r.year + (r.period === "TTM" ? " TTM" : "")), datasets: [
      {type: "bar", label: "Pendapatan", data: rows.map(r => r.revenue), backgroundColor: "#63adff88", yAxisID: "y"},
      {type: "bar", label: "Laba bersih", data: rows.map(r => r.net_income), backgroundColor: "#42e8a2aa", yAxisID: "y"},
      {type: "line", label: "ROE %", data: rows.map(r => r.roe == null ? null : r.roe * 100), borderColor: C.amber, backgroundColor: C.amber, yAxisID: "y1", tension: .2}]},
      options: {...baseOpts, scales: {x: baseOpts.scales.x,
        y: {ticks: {color: C.text, font: {size: 9}, callback: v => compact(v)}, grid: {color: C.grid}},
        y1: {position: "right", ticks: {color: C.amber, font: {size: 9}, callback: v => v + "%"}, grid: {display: false}}}}});
  }
}

/* ================= Perbandingan ================= */
function renderCompare(res) {
  const okRows = res.filter(r => !r.error), bad = res.filter(r => r.error);
  const body = okRows.map((r, i) => {
    const bars = GROUP_ORDER.filter(g => g in r.groups).map(g =>
      `<i title="${GROUP_FULL[g]} ${num(r.groups[g], 0)}"><u style="height:${Math.max(4, r.groups[g])}%" class="${r.groups[g] >= 65 ? "b" : r.groups[g] >= 45 ? "h" : "s"}"></u></i>`).join("");
    return `<tr class="click" data-t="${esc(r.ticker)}" data-m="${esc(r.market)}"><td>${i + 1}</td>
      <td><b>${esc(r.ticker)}</b><br><span class="muted">${esc((r.name || "").slice(0, 28))}</span></td>
      <td><b>${num(r.score, 1)}</b></td><td><span class="verdict mini ${verdictClass(r.label)}">${esc(r.label)}</span></td>
      <td class="${confClass(r.confidence) === "buy" ? "pos" : confClass(r.confidence) === "sell" ? "neg" : "zero"}">${esc(r.confidence)}</td>
      <td class="${cls(r.cagr_pct)}">${pct(r.cagr_pct, 1, true)}</td><td>${pct(r.volatility_pct, 0)}</td><td class="neg">${pct(r.max_drawdown_pct, 0)}</td>
      <td>${ok(r.pe) ? num(r.pe, 1) + "x" : "—"}</td><td>${ok(r.pb) ? num(r.pb, 2) + "x" : "—"}</td><td>${pct(r.roe_pct, 1)}</td><td>${pct(r.div_yield_pct, 1)}</td>
      <td class="${cls(r.fair_gap_pct)}" title="${esc(r.fair_label || "")}">${ok(r.fair_gap_pct) ? pct(r.fair_gap_pct, 0, true) : "—"}</td>
      <td>${num(r.rsi14, 0)}</td><td>${r.risk_flags}</td><td><div class="mini-bars">${bars}</div></td></tr>`;
  }).join("");
  const errs = bad.map(r => `<div class="flag">${esc(r.ticker)}: ${esc(r.error)}</div>`).join("");
  $("cmp").innerHTML = `<article class="panel wide"><div class="title"><div><h3>Perbandingan Saham</h3>
    <small>Analisis cepat (tanpa backtest, riwayat, Monte Carlo, berita). Klik baris untuk analisis penuh</small></div><span class="tag">${okRows.length} saham</span></div>
    <div class="tablewrap"><table class="table cmp"><thead><tr><th>#</th><th>Saham</th><th>Skor</th><th>Vonis</th><th>Keyakinan</th><th>CAGR</th><th>Vol</th><th>Max DD</th>
    <th>PER</th><th>PBV</th><th>ROE</th><th>DY</th><th>Vs wajar</th><th>RSI</th><th>Risk</th><th>Kelompok</th></tr></thead><tbody>${body}</tbody></table></div>${errs}
    <p class="note">Urutan berdasarkan skor gabungan, bukan rekomendasi. &quot;Vs wajar&quot; = potensi ke harga wajar estimasi (parsial pada mode cepat; buka analisis penuh untuk rinciannya). Kelompok: kinerja, teknikal, relatif, fundamental (tanpa riwayat pada mode cepat). Bandingkan hanya dalam sektor yang sama agar PER/PBV bermakna.</p></article>`;
  show("cmp", true);
  $("cmp").querySelectorAll("tr.click").forEach(tr => tr.onclick = () => {
    $("ticker").value = tr.dataset.t; analyzeSingle(tr.dataset.t, {market: tr.dataset.m});
  });
}

/* ================= Alur analisis ================= */
function resetViews() {
  show("err", false); setBanner(null); show("dash", false); show("cmp", false); show("load", false);
}
function setLoading(msg) { $("load").innerHTML = `<span class="spin"></span> ${msg}`; show("load", true); }
function params(market, years, extra = "") { return `market=${encodeURIComponent(market)}&years=${encodeURIComponent(years)}${extra}`; }

async function analyzeSingle(ticker, opt = {}) {
  const seq = ++runSeq;
  resetViews();
  destroyCharts();
  const market = opt.market || $("market").value, years = $("years").value;
  setLoading(`Menganalisis <b>${esc(ticker.toUpperCase())}</b>: harga, teknikal, fundamental...`);
  let fast;
  try {
    fast = await api(`/api/analyze?ticker=${encodeURIComponent(ticker)}&${params(market, years)}&mode=fast`);
  } catch (e) { if (seq === runSeq) { show("load", false); showError(e.message); } return; }
  if (seq !== runSeq) return;
  show("load", false);
  if (!fast.ok) { showError(fast.error || "Gagal menganalisis."); return; }
  render(fast.data);
  history.replaceState(null, "", "#" + encodeURIComponent(fast.data.ticker));
  setBanner(`<span class="spin"></span> Analisis cepat tampil. Memuat analisis mendalam: riwayat fundamental, backtest, Monte Carlo, berita (bisa 10 sampai 40 detik)...`, "info");
  try {
    const full = await api(`/api/analyze?ticker=${encodeURIComponent(fast.data.ticker)}&${params(fast.data.resolved_market, years)}&mode=full`);
    if (seq !== runSeq) return;
    if (!full.ok) throw new Error(full.error || "Analisis mendalam gagal.");
    render(full.data);
    const sk = full.data.skipped || [];
    setBanner(sk.length ? `Modul dilewati karena batas waktu server: <b>${esc(sk.join(", "))}</b>. Keyakinan sudah dikurangi. Selesai dalam ${num(full.data.elapsed_sec, 1)} detik.` : null, "warn");
  } catch (e) {
    if (seq === runSeq) setBanner(`Analisis mendalam gagal: ${esc(e.message)}. Hasil cepat tetap ditampilkan (tanpa backtest, riwayat, Monte Carlo, berita), jadi keyakinannya lebih rendah.`, "warn");
  }
}

async function analyzeCompare(tokens) {
  const seq = ++runSeq;
  resetViews(); destroyCharts();
  setLoading(`Membandingkan <b>${tokens.length}</b> saham secara paralel...`);
  try {
    const r = await api(`/api/compare?tickers=${encodeURIComponent(tokens.join(","))}&${params($("market").value, $("years").value)}`);
    if (seq !== runSeq) return;
    show("load", false);
    if (!r.ok) { showError(r.error || "Perbandingan gagal."); return; }
    renderCompare(r.results);
  } catch (e) { if (seq === runSeq) { show("load", false); showError(e.message); } }
}

function go() {
  hideSugg();
  const tokens = $("ticker").value.split(",").map(s => s.trim()).filter(Boolean);
  if (!tokens.length) { showError("Masukkan kode saham terlebih dahulu."); return; }
  if (tokens.length > 1) analyzeCompare(tokens); else analyzeSingle(tokens[0]);
}

/* ================= Pencarian + autocomplete ================= */
const POPULAR = ["BBCA", "BBRI", "BMRI", "TLKM", "ASII", "UNVR", "GOTO", "AAPL", "NVDA", "TSLA"];
const PRESETS = [["Bank besar", "BBCA,BBRI,BMRI,BBNI"], ["Telko", "TLKM,EXCL,ISAT"], ["Konsumer", "UNVR,ICBP,INDF,MYOR"], ["Tambang", "ADRO,PTBA,ANTM,MDKA"]];
let sT = null, sItems = [], sIdx = -1, sSeq = 0;

$("chips").innerHTML = '<span class="chiplbl">Populer:</span>' + POPULAR.map(c => `<button type="button" class="chip" data-c="${c}">${c}</button>`).join("");
$("presets").innerHTML = '<span class="chiplbl">Bandingkan:</span>' + PRESETS.map(([n, v]) => `<button type="button" class="chip" data-p="${v}">${n}</button>`).join("");
$("chips").addEventListener("click", e => {
  const b = e.target.closest(".chip"); if (!b) return;
  $("ticker").value = b.dataset.c; $("market").value = "auto"; go();
});
$("presets").addEventListener("click", e => {
  const b = e.target.closest(".chip"); if (!b) return;
  $("ticker").value = b.dataset.p.replace(/,/g, ", "); $("market").value = "auto"; go();
});

function currentToken() { const v = $("ticker").value; return v.slice(v.lastIndexOf(",") + 1).trim(); }
function hideSugg() { $("sugg").classList.add("hide"); $("ticker").setAttribute("aria-expanded", "false"); sIdx = -1; }
function showSugg(items, q) {
  sItems = items; sIdx = -1;
  $("sugg").innerHTML = items.length
    ? items.map((x, i) => `<li role="option" data-i="${i}"><b>${esc(x.symbol)}</b><span>${esc(x.name)}</span><em>${esc(x.exchange || (x.market === "id" ? "IDX" : "US"))}</em></li>`).join("")
    : `<li class="empty">Tidak ada hasil untuk "${esc(q)}". Tekan Enter untuk mencoba kode ini langsung.</li>`;
  $("sugg").classList.remove("hide"); $("ticker").setAttribute("aria-expanded", "true");
}
function pick(x) {
  const v = $("ticker").value;
  if (v.includes(",")) {                                   // mode bandingkan: sisipkan, jangan langsung analisis
    $("ticker").value = v.slice(0, v.lastIndexOf(",") + 1) + " " + x.symbol + ", ";
    hideSugg(); $("ticker").focus();
  } else { $("ticker").value = x.symbol; analyzeSingle(x.symbol, {market: x.market}); }
}
function move(d) {
  if (!sItems.length) return;
  sIdx = (sIdx + d + sItems.length) % sItems.length;
  [...$("sugg").children].forEach((li, i) => li.classList.toggle("on", i === sIdx));
  $("sugg").children[sIdx].scrollIntoView({block: "nearest"});
}

$("ticker").addEventListener("input", () => {
  const q = currentToken(); clearTimeout(sT); sItems = []; sIdx = -1;
  if (!q) { hideSugg(); return; }
  sT = setTimeout(async () => {
    const my = ++sSeq;
    try {
      const j = await (await fetch("/api/search?q=" + encodeURIComponent(q))).json();
      if (my !== sSeq || currentToken() !== q) return;
      showSugg(j.ok ? j.results : [], q);
    } catch (e) { if (my === sSeq) showSugg([], q); }
  }, 220);
});
$("ticker").addEventListener("keydown", e => {
  const open = !$("sugg").classList.contains("hide") && sItems.length > 0;
  if (e.key === "ArrowDown" && open) { e.preventDefault(); move(1); }
  else if (e.key === "ArrowUp" && open) { e.preventDefault(); move(-1); }
  else if (e.key === "Escape") hideSugg();
  else if (e.key === "Enter") {
    e.preventDefault();
    if (open && sIdx >= 0) pick(sItems[sIdx]);
    else if (open && !$("ticker").value.includes(",")) {
      const q = currentToken().toUpperCase();
      pick(sItems.find(x => x.symbol.replace(".JK", "") === q) || sItems[0]);
    } else go();
  }
});
$("sugg").addEventListener("mousedown", e => {
  const li = e.target.closest("li[data-i]");
  if (li) { e.preventDefault(); pick(sItems[+li.dataset.i]); }
});
document.addEventListener("click", e => { if (!e.target.closest(".field")) hideSugg(); });
$("go").onclick = go;
$("clearTicker").onclick = () => { $("ticker").value = ""; hideSugg(); runSeq++; resetViews(); destroyCharts(); history.replaceState(null, "", location.pathname); $("ticker").focus(); };

window.addEventListener("DOMContentLoaded", () => {
  const h = decodeURIComponent(location.hash.replace("#", "")).trim();
  if (/^[A-Za-z0-9.\-^=]{1,15}$/.test(h)) { $("ticker").value = h; analyzeSingle(h); }
  else { $("ticker").value = ""; $("ticker").focus(); }
});

/* ================= Harga wajar ================= */
// Presisi mengikuti harga: saham Rp30 tidak boleh ditampilkan dibulatkan ke Rp29 atau Rp30.
function fvDec(p) { return p < 10 ? 2 : p < 100 ? 1 : 0; }
function fvLabelClass(l) { return l === "DI BAWAH HARGA WAJAR" ? "buy" : l === "DI ATAS HARGA WAJAR" ? "sell" : "hold"; }
function fvCtx(d) { return {ticker: d.ticker, market: d.resolved_market, currency: d.profile.currency || "", price: d.metrics.price, mode: d.mode}; }

function fvCard(d) {
  const fv = d.fair_value;
  if (fv && fv.available) return card("HARGA WAJAR", num(fv.base, fvDec(fv.current_price)), `${pct(fv.upside_pct, 1, true)} ke harga wajar`, cls(fv.upside_pct));
  return card("HARGA WAJAR", "—", "belum bisa dihitung");
}

function renderFairValue(d) { return `<div id="fvWrap">${fairValuePanel(d.fair_value, fvCtx(d))}</div>`; }

function fvForm(fv) {
  const a = (fv && fv.assumptions) || {};
  const val = (x, def) => (ok(x) ? x * 100 : def).toFixed(1);
  return `<div class="fvform">
    <label>Biaya modal <input id="fvKe" type="number" step="0.5" min="4" max="30" value="${val(a.ke, 12)}"> %</label>
    <label>Pertumbuhan jangka panjang <input id="fvG" type="number" step="0.5" min="-2" max="8" value="${val(a.g, 4.5)}"> %</label>
    <label>Margin keamanan <input id="fvMos" type="number" step="5" min="0" max="80" value="${val(a.mos, 25)}"> %</label>
    <button type="button" id="fvApply" class="secondary">Hitung ulang</button>
    <button type="button" id="fvReset" class="secondary">Reset</button>
    <span id="fvStatus" class="muted"></span></div>`;
}

function fairValuePanel(fv, ctx) {
  const cur = esc(ctx.currency);
  const lc = fv && fv.available ? fvLabelClass(fv.label) : "";
  const head = `<div class="title"><div><h3>Harga Wajar Saham</h3><small>Estimasi multi-metode: bukan target harga dan bukan sinyal beli</small></div>${fv && fv.available ? `<span class="tag fv-${lc}">${esc(fv.label)}</span>` : ""}</div>`;
  if (!fv) return `<article class="panel wide">${head}<p class="muted">Modul harga wajar dimatikan di konfigurasi.</p></article>`;
  const flags = (fv.flags || []).map(f => `<div class="flag">⚠ ${esc(f)}</div>`).join("");
  const na = (fv.unavailable || []).map(u => `<li><b>${esc(u.name)}</b>: ${esc(u.reason)}</li>`).join("");
  const naBlock = na ? `<details class="fvna"><summary>Metode yang tidak dihitung (${fv.unavailable.length})</summary><ul>${na}</ul></details>` : "";
  const form = fvForm(fv);
  if (!fv.available) {
    const p0 = fv.current_price, px0 = v => num(v, fvDec(p0));
    const iv = fv.indicative;
    const hint = ctx.mode === "fast"
      ? `<div class="banner info">Mode cepat belum memuat riwayat laporan keuangan, jadi metode PER/PBV historis dan DCF belum bisa dihitung. Tunggu analisis mendalam selesai (banner biru di atas hilang); metode tambahan bisa membuat harga wajar tampil.</div>` : "";
    const indBlock = iv ? `<div class="cards">
      ${card("HARGA WAJAR INDIKATIF", px0(iv.price), `hanya 1 metode: ${esc(iv.name)}`, "zero")}
      ${card("HARGA SEKARANG", num(p0, 2), esc(ctx.currency))}
      ${card("SELISIH KE ANGKA INI", pct(iv.upside_pct, 1, true), "bukan kesimpulan", cls(iv.upside_pct))}</div>
      <div class="banner warn">Ini <b>indikasi dari satu metode</b>, bukan harga wajar. Satu metode tidak bisa dicek silang, jadi jangan dijadikan dasar keputusan. ${esc(iv.note)}</div>` : "";
    const reasonsOpen = naBlock.replace('<details class="fvna">', '<details class="fvna" open>');
    return `<article class="panel wide">${head}${hint}${indBlock}<p class="muted">Harga wajar belum tampil: ${esc(fv.reason || "data tidak cukup")}. Harga wajar butuh minimal dua metode yang lolos.</p>${reasonsOpen}${flags}${form}<p class="note">${esc(fv.disclaimer)}</p></article>`;
  }
  const a = fv.assumptions, price = fv.current_price;
  const px = v => num(v, fvDec(price));
  const cards = `<div class="cards">
    ${card("HARGA WAJAR (DASAR)", `${px(fv.base)}`, `rentang metode ${px(fv.low)} - ${px(fv.high)} ${cur}`, lc === "buy" ? "pos" : lc === "sell" ? "neg" : "zero")}
    ${card("HARGA SEKARANG", num(price, 2), fv.in_range ? "di dalam rentang metode" : (price < fv.low ? "di bawah semua metode" : "di atas semua metode"))}
    ${card("POTENSI KE HARGA WAJAR", pct(fv.upside_pct, 1, true), `harga ${fv.premium_pct >= 0 ? "premi" : "diskon"} ${num(Math.abs(fv.premium_pct), 1)}% terhadap wajar`, cls(fv.upside_pct))}
    ${card(`HARGA MASUK (MOS ${num(a.mos * 100, 0)}%)`, px(fv.mos_price), "dengan margin keamanan")}
    ${card("KEYAKINAN ESTIMASI", esc(fv.confidence.label), `${fv.methods.filter(m => m.included).length} metode dipakai`, confClass(fv.confidence.label) === "buy" ? "pos" : confClass(fv.confidence.label) === "sell" ? "neg" : "zero")}</div>`;
  const pts = [fv.low, fv.high, price, fv.mos_price];
  const lo = Math.min(...pts) * 0.92, hi = Math.max(...pts) * 1.06;
  const at = v => ((v - lo) / (hi - lo) * 100).toFixed(2);
  const bar = `<div class="fvr"><i class="band" style="left:${at(fv.low)}%;width:${(at(fv.high) - at(fv.low)).toFixed(2)}%"></i>
    <i class="mk mos" style="left:${at(fv.mos_price)}%"></i><i class="mk base" style="left:${at(fv.base)}%"></i><i class="mk now" style="left:${at(price)}%"></i></div>
    <div class="fvleg"><span><i class="lg band"></i>rentang metode ${px(fv.low)} - ${px(fv.high)}</span><span><i class="lg base"></i>harga wajar ${px(fv.base)}</span>
    <span><i class="lg mos"></i>harga masuk ${px(fv.mos_price)}</span><span><i class="lg now"></i>harga sekarang ${px(price)}</span></div>`;
  const rows = fv.methods.map(m => {
    const gap = (m.price / price - 1) * 100;
    return `<tr class="${m.included ? "" : "excl"}"><td><b>${esc(m.name)}</b></td><td>${num(m.price, 2)}</td><td class="${cls(gap)}">${pct(gap, 0, true)}</td><td>${num(m.weight, 1)}</td>
      <td>${m.included ? "dipakai" : "dikecualikan: " + esc(m.excluded_reason)}</td><td class="wrapcell"><span class="muted">${esc(m.note)}</span></td></tr>`;
  }).join("");
  const s = fv.sensitivity;
  const near = (x, y) => Math.abs(x - y) < 1e-6;
  const sensHead = s.ke_values.map(k => `<th>${num(k * 100, 1)}%</th>`).join("");
  const sensBody = s.g_values.map((g, i) => `<tr><th>g ${num(g * 100, 1)}%</th>${s.grid[i].map((v, j) => {
    if (v == null) return `<td class="muted">—</td>`;
    const c = v > price * 1.15 ? "pos" : v < price * 0.85 ? "neg" : "zero";
    return `<td class="${c}${near(g, a.g) && near(s.ke_values[j], a.ke) ? " basecell" : ""}">${px(v)}</td>`;
  }).join("")}</tr>`).join("");
  const reasons = fv.confidence.reasons.map(r => `<div class="rs ${r.startsWith("+") ? "pos" : r.startsWith("-") ? "neg" : "zero"}">${esc(r)}</div>`).join("");
  const an = fv.analyst ? `<p class="muted">Pembanding: konsensus ${fv.analyst.n} analis menargetkan <b>${px(fv.analyst.target)} ${cur}</b> (${pct(fv.analyst.gap_pct, 1, true)} dari harga). Tidak masuk perhitungan.</p>` : "";
  return `<article class="panel wide">${head}${cards}${bar}
    <h4>Metode</h4><div class="tablewrap"><table class="table"><thead><tr><th>Metode</th><th>Estimasi</th><th>Vs harga</th><th>Bobot</th><th>Status</th><th>Asumsi</th></tr></thead><tbody>${rows}</tbody></table></div>
    ${naBlock}${flags}
    <h4>Sensitivitas (harga wajar dasar bila asumsi berubah)</h4>
    <div class="tablewrap"><table class="table sens"><thead><tr><th>g \\ biaya modal</th>${sensHead}</tr></thead><tbody>${sensBody}</tbody></table></div>
    <p class="note">Hijau = di atas harga sekarang lebih dari 15%, merah = di bawahnya lebih dari 15%. Kotak bergaris = asumsi yang dipakai. Himpunan metode dikunci sama dengan kasus dasar.</p>
    <h4>Asumsi Anda</h4>${form}
    <h4>Keyakinan estimasi</h4>${reasons}${an}
    <p class="note">${esc(fv.disclaimer)}</p></article>`;
}

function initFairValue(d) {
  const a = d.fair_value && d.fair_value.assumptions;
  if (fvState.ticker !== d.ticker || !fvState.defaults) {
    fvState = {defaults: a ? {ke: a.ke, g: a.g, mos: a.mos} : null, ticker: d.ticker};
  }
  bindFvButtons(fvCtx(d));
}

function bindFvButtons(ctx) {
  const apply = $("fvApply"), reset = $("fvReset");
  if (!apply || !reset) return;
  apply.onclick = () => recomputeFairValue(ctx, false);
  reset.onclick = () => recomputeFairValue(ctx, true);
}

async function recomputeFairValue(ctx, useDefaults) {
  const status = $("fvStatus"), btn = $("fvApply");
  const d0 = fvState.defaults || {ke: 0.12, g: 0.045, mos: 0.25};
  let ke, g, mos;
  if (useDefaults) { ke = d0.ke * 100; g = d0.g * 100; mos = d0.mos * 100; }
  else { ke = parseFloat($("fvKe").value); g = parseFloat($("fvG").value); mos = parseFloat($("fvMos").value); }
  const fail = m => { status.textContent = m; };
  if (![ke, g, mos].every(Number.isFinite)) return fail("Isi ketiga asumsi dengan angka.");
  if (ke < 4 || ke > 30) return fail("Biaya modal harus antara 4% dan 30%.");
  if (g < -2 || g > 8) return fail("Pertumbuhan jangka panjang harus antara -2% dan 8%.");
  if (mos < 0 || mos > 80) return fail("Margin keamanan harus antara 0% dan 80%.");
  if (g > ke - 2) return fail("g harus lebih kecil dari biaya modal minus 2 poin persen.");
  btn.disabled = true;
  status.innerHTML = '<span class="spin"></span> Menghitung ulang...';
  try {
    const q = `ticker=${encodeURIComponent(ctx.ticker)}&${params(ctx.market, $("years").value)}&ke=${ke / 100}&g=${g / 100}&mos=${mos / 100}`;
    const r = await api(`/api/fairvalue?${q}`, 60000);
    if (!r.ok) throw new Error(r.error || "Gagal menghitung ulang.");
    if (!$("fvWrap") || fvState.ticker !== ctx.ticker) return;        // pengguna sudah pindah saham
    $("fvWrap").innerHTML = fairValuePanel(r.data.fair_value, {...ctx, mode: "full"});
    bindFvButtons(ctx);
    const st = $("fvStatus");
    if (st) st.textContent = `Dihitung ulang dengan asumsi Anda (${num(r.data.elapsed_sec, 1)} detik).`;
  } catch (e) {
    if ($("fvStatus")) { $("fvStatus").textContent = e.message; if ($("fvApply")) $("fvApply").disabled = false; }
  }
}

/* ================= Sumber data ================= */
function renderSources(d) {
  const s = d.data_sources;
  if (!s) return "";
  const h = s.history || {}, live = s.live || {}, f = s.fundamentals || {};
  const tone = st => st === "ok" ? "pos" : st === "bad" ? "neg" : st === "warn" ? "zero" : "muted";
  const vrows = (h.validators || []).map(v => `<tr><td><b>${esc(v.source)}</b></td><td class="${tone(v.status)}">${esc(v.status)}</td>
    <td>${ok(v.last_close_diff_pct) ? num(v.last_close_diff_pct, 2) + "%" : "—"}</td><td>${ok(v.max_return_diff_pct) ? num(v.max_return_diff_pct, 2) + "%" : "—"}</td>
    <td>${v.common_days || 0}</td><td class="wrapcell"><span class="muted">${esc(v.note || "")}</span></td></tr>`).join("");
  const table = vrows
    ? `<div class="tablewrap"><table class="table"><thead><tr><th>Validator</th><th>Status</th><th>Selisih harga terakhir</th><th>Return harian maks</th><th>Hari sama</th><th>Catatan</th></tr></thead><tbody>${vrows}</tbody></table></div>`
    : `<p class="muted">Belum divalidasi silang: ${s.validation_enabled ? "hanya satu sumber aktif untuk saham ini" : "mode cepat atau validasi dimatikan"}.</p>`;
  const fail = (h.failover || []).map(a => `<li>${esc(a.source)}: ${esc(a.reason)}</li>`).join("");
  const quotes = Object.entries(live.quotes || {}).map(([k, v]) => `${esc(k)} ${num(v, 2)}`).join(" · ");
  const filled = (f.filled || []).map(x => `${esc(x.field)} (${esc(x.source)})`).join(", ");
  const conf = (f.conflicts || []).map(c => `<div class="flag">Fundamental ${esc(c.field)}: ${Object.entries(c.values).map(([k, v]) => esc(k) + " " + num(v, 2)).join(" vs ")} (selisih ${num(c.diff_pct, 0)}%). Nilai sumber utama dipakai.</div>`).join("");
  return `<h4>Sumber data</h4>
    <p class="muted">Harga: <b>${esc(h.primary || "—")}</b> · laporan keuangan: <b>${esc((s.statements || {}).source || "—")}</b> · sumber aktif: ${esc((s.providers_active || []).join(", ") || "—")}${quotes ? " · harga terakhir: " + quotes : ""}</p>
    ${h.switched ? `<div class="flag">Sumber harga diganti ${esc(h.switched.from)} → ${esc(h.switched.to)}: ${esc(h.switched.reason)}</div>` : ""}
    ${fail ? `<p class="muted">Sumber yang gagal sebelum berhasil:</p><ul class="fvind">${fail}</ul>` : ""}
    ${table}${filled ? `<p class="muted">Fundamental diisi dari sumber lain: ${filled}</p>` : ""}${conf}
    <button type="button" id="srcDiag" class="secondary">Uji sumber data</button><div id="srcOut" class="muted"></div>`;
}

function renderDiag(x) {
  const rows = x.providers.map(p => `<tr><td><b>${esc(p.source)}</b></td><td class="${p.status === "ok" ? "pos" : p.status === "gagal" ? "neg" : "muted"}">${esc(p.status)}</td>
    <td>${esc(p.mapped_symbol || "—")}</td><td>${p.history ? `${p.history.rows} baris, terakhir ${esc(p.history.last_date || "—")} @ ${num(p.history.last_close, 2)}` : "—"}</td>
    <td>${p.latency_sec != null ? num(p.latency_sec, 2) + " dtk" : "—"}</td>
    <td class="wrapcell"><span class="muted">${esc(p.error || p.note || (p.key_set === false ? "isi variabel environment kunci API" : ""))}</span></td></tr>`).join("");
  const tips = (x.tips || []).map(t => `<li>${esc(t)}</li>`).join("");
  return `<div class="tablewrap"><table class="table"><thead><tr><th>Sumber</th><th>Status</th><th>Simbol</th><th>Data harga</th><th>Latensi</th><th>Catatan</th></tr></thead><tbody>${rows}</tbody></table></div><ul class="fvind">${tips}</ul>`;
}

function bindSources(d) {
  const b = $("srcDiag");
  if (!b) return;
  b.onclick = async () => {
    const out = $("srcOut");
    b.disabled = true;
    out.innerHTML = '<span class="spin"></span> Menguji tiap sumber (memakai kuota API Anda)...';
    try {
      const r = await api(`/api/sources?ticker=${encodeURIComponent(d.ticker)}&${params(d.resolved_market, $("years").value)}`, 60000);
      if (!r.ok) throw new Error(r.error || "Pengujian gagal.");
      out.innerHTML = renderDiag(r.data);
    } catch (e) { out.textContent = e.message; }
    finally { b.disabled = false; }
  };
}

// Forex technical-analysis bot
let forexChart = null;
let forexRefreshTimer = null;
let forexRefreshBusy = false;
let forexCandleSeries = null;
let forexLastLiveCandle = null;
let forexStream = null;
let forexStreamPair = null;
let forexStreamRetry = null;
let forexStreamHeartbeat = null;
let forexStreamKey = null;
let forexLastTick = null;
const forexTfSeconds = { '1d': 86400, '4h': 14400, '1h': 3600, '15m': 900, '5m': 300 };
async function runForexAnalysis(options = {}) {
  const pair = document.getElementById('fxPair').value;
  const tf = document.getElementById('fxTf').value;
  const err = document.getElementById('fxError');
  const go = document.getElementById('fxGo');
  if (forexRefreshBusy) return;
  forexRefreshBusy = true;
  err.classList.add('hide'); if (!options.silent) { go.disabled = true; go.textContent = 'MENGANALISIS…'; }
  try {
    const res = await fetch(`/api/forex?pair=${encodeURIComponent(pair)}&interval=${encodeURIComponent(tf)}`);
    const json = await res.json();
    if (!res.ok || !json.ok) throw new Error(json.error || 'Analisis forex gagal.');
    const d = json.data;
    const liveStatus = document.getElementById('fxLiveStatus');
    if (liveStatus) liveStatus.textContent = `Data candle diperbarui: ${new Date(d.updated_at || Date.now()).toLocaleString('id-ID')} · menghubungkan streaming tick… · ${d.source}`;
    const fmt = v => Number(v).toLocaleString('en-US', {maximumFractionDigits: 5});
    const trendClass = d.trend === 'BULLISH' ? 'fxbull' : d.trend === 'BEARISH' ? 'fxbear' : '';
    const plan = d.trade_plan || {};
    const planFmt = v => v == null || !Number.isFinite(Number(v)) ? '—' : fmt(v);
    document.getElementById('fxSummary').innerHTML = [
      ['HARGA TERAKHIR', fmt(d.price), d.pair], ['TREN BOT', d.trend, `${d.bullish_score}/4 bullish · ${d.bearish_score}/4 bearish`],
      ['RSI (14)', fmt(d.rsi), d.rsi > 70 ? 'Overbought' : d.rsi < 30 ? 'Oversold' : 'Zona netral'],
      ['SUPPORT', fmt(d.support), 'Pivot terbaru'], ['RESISTANCE', fmt(d.resistance), 'Pivot terbaru'], ['IDE SINYAL', d.signal, 'Perlu konfirmasi']
    ].map((x,i)=>`<div class="fxmetric"><small>${x[0]}</small><b class="${i===1||i===5?trendClass:''}">${x[1]}</b><span>${x[2]}</span></div>`).join('') +
      `<div class="fxmetric fxtradeplan"><small>RENCANA ENTRY</small><b>${plan.direction || 'WAIT'} · ${planFmt(plan.entry)}</b><span>${plan.status || 'Tunggu setup'}${plan.entry_low != null ? ` · zona ${planFmt(plan.entry_low)}–${planFmt(plan.entry_high)}` : ''}</span></div>` +
      `<div class="fxmetric fxtradeplan"><small>STOP LOSS (SL)</small><b>${planFmt(plan.stop_loss)}</b><span>Di luar zona invalidasi perkiraan</span></div>` +
      `<div class="fxmetric fxtradeplan"><small>TAKE PROFIT (TP)</small><b>${planFmt(plan.take_profit)}</b><span>${plan.risk_reward != null ? `R:R sekitar 1:${Number(plan.risk_reward).toFixed(2)}` : 'Belum ada rencana valid'}</span></div>`;
    const ob = d.order_block;
    const obText = ob ? `${ob.type} · zona ${fmt(ob.low)}–${fmt(ob.high)} · ditemukan ${ob.time}` : 'Belum ditemukan zona order block yang memenuhi kriteria sederhana.';
    const fibText = d.fibonacci && d.fibonacci.levels ? Object.entries(d.fibonacci.levels).map(([level,value])=>`${level}: ${fmt(value)}`).join(' · ') : 'Belum tersedia';
    const patternText = d.patterns && d.patterns.length ? d.patterns.map(p=>`${p.type} zona ${fmt(p.low)}–${fmt(p.high)} (${p.time})`).join('<br>') : 'Belum ada pola base yang memenuhi aturan sederhana.';
    document.getElementById('fxNotes').innerHTML = d.notes.map((n,i)=>`<div class="fxnote"><b>${['Trend harga / EMA20','Arah EMA20 vs EMA50','Konfirmasi MACD','Momentum RSI'][i]}:</b> ${n}</div>`).join('') + `<div class="fxnote"><b>Support / Resistance:</b> Support ${fmt(d.support)} · Resistance ${fmt(d.resistance)}. Level memakai swing/pivot terbaru, bukan level pasti.</div><div class="fxnote"><b>Order Block:</b> ${obText}</div><div class="fxnote"><b>Base Pattern:</b> ${patternText}<br><small>RBR/DBD dan RBD/DBR adalah deteksi perkiraan dari candle OHLC, bukan validasi otomatis zona institusi.</small></div><div class="fxnote"><b>Fibonacci retracement:</b> swing low ${fmt(d.fibonacci.swing_low)} · swing high ${fmt(d.fibonacci.swing_high)}<br>${fibText}<br><small>Level Fibonacci adalah area pantau, bukan sinyal entry mandiri.</small></div><div class="fxnote"><b>Strategi OB + S/R:</b> ${d.strategy}</div><div class="fxnote"><b>Rencana trade (${plan.direction || 'WAIT'}):</b> ${plan.reason || 'Belum ada setup yang cukup; tunggu.'}<br><b>Entry:</b> ${planFmt(plan.entry)}${plan.entry_low != null ? ` (zona ${planFmt(plan.entry_low)}–${planFmt(plan.entry_high)})` : ''} · <b>SL:</b> ${planFmt(plan.stop_loss)} · <b>TP:</b> ${planFmt(plan.take_profit)} · <b>R:R:</b> ${plan.risk_reward != null ? `1:${Number(plan.risk_reward).toFixed(2)}` : '—'}<br><small>Ini rencana indikatif dari OHLC dan zona terdeteksi, bukan instruksi transaksi. Periksa spread, berita, dan candle konfirmasi sebelum memutuskan.</small></div><div class="fxnote"><b>Sumber & batasan:</b> ${d.source}</div>`;
    document.getElementById('fxChartLabel').textContent = `${d.pair} · ${d.timeframe} · ${d.candles.length} candle`;
    if (!window.LightweightCharts) throw new Error('Library candlestick tidak tersedia. Periksa koneksi internet.');
    const c = d.candles || [];
    const host = document.getElementById('fxChart');
    if (host._fxResizeObserver) { try { host._fxResizeObserver.disconnect(); } catch (_) {} host._fxResizeObserver = null; }
    if (forexChart) { try { forexChart.remove(); } catch (_) {} forexChart = null; }
    host.innerHTML = '';
    const tv = window.LightweightCharts;
    forexChart = tv.createChart(host, {
      width: host.clientWidth, height: host.clientHeight,
      layout: { background: { type: 'solid', color: '#0b111b' }, textColor: '#a8b7c8', fontFamily: 'Inter, Arial, sans-serif' },
      grid: { vertLines: { color: '#172434' }, horzLines: { color: '#172434' } },
      crosshair: { mode: tv.CrosshairMode.Normal, vertLine: { color: '#75869a', width: 1, style: 3, labelBackgroundColor: '#26384c' }, horzLine: { color: '#75869a', width: 1, style: 3, labelBackgroundColor: '#26384c' } },
      rightPriceScale: { borderColor: '#27384b', scaleMargins: { top: 0.08, bottom: 0.08 } },
      timeScale: { borderColor: '#27384b', timeVisible: true, secondsVisible: false, rightOffset: 6, barSpacing: 8, minBarSpacing: 3 },
      localization: { locale: 'id-ID', priceFormatter: price => Number(price).toLocaleString('en-US', { maximumFractionDigits: 5 }) },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true }
    });
    // Parse provider timestamps robustly: don't append Z to strings that already
    // contain a UTC offset (e.g. +00:00), which would make Date.parse fail.
    const timeOf = value => {
      if (typeof value === 'number' && Number.isFinite(value)) return Math.floor(value);
      const raw = String(value ?? '').trim();
      if (!raw) return NaN;
      const normalized = raw.includes('T') ? raw : raw.replace(' ', 'T');
      const hasZone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(normalized);
      const ms = Date.parse(hasZone ? normalized : `${normalized}Z`);
      return Number.isFinite(ms) ? Math.floor(ms / 1000) : NaN;
    };
    const candles = c.map(x => ({ time: timeOf(x.time), open: Number(x.open), high: Number(x.high), low: Number(x.low), close: Number(x.close) })).filter(x => Number.isFinite(x.time) && [x.open,x.high,x.low,x.close].every(Number.isFinite)).sort((a,b)=>a.time-b.time);
    const candleSeries = forexChart.addCandlestickSeries({
      upColor: '#26a69a', downColor: '#ef5350', borderUpColor: '#26a69a', borderDownColor: '#ef5350', wickUpColor: '#26a69a', wickDownColor: '#ef5350',
      priceLineVisible: true, lastValueVisible: true
    });
    candleSeries.setData(candles);
    forexCandleSeries = candleSeries;
    forexLastLiveCandle = candles.length ? { ...candles[candles.length - 1] } : null;
    const addOverlay = (key, label, color, width=1) => {
      const line = forexChart.addLineSeries({ title: label, color, lineWidth: width, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false, lineStyle: tv.LineStyle.Solid });
      line.setData(c.filter(x => Number.isFinite(Number(x[key]))).map(x => ({ time: timeOf(x.time), value: Number(x[key]) })).sort((a,b)=>a.time-b.time));
    };
    addOverlay('ema20', 'EMA 20', '#26c6a6', 1);
    addOverlay('ema50', 'EMA 50', '#f5b942', 1);
    const addLevel = (price, title, color, style=tv.LineStyle.Dashed) => {
      if (price == null || !Number.isFinite(Number(price))) return;
      candleSeries.createPriceLine({ price: Number(price), title, color, lineWidth: 1, lineStyle: style, axisLabelVisible: true, lineVisible: true });
    };
    addLevel(d.support, 'SUPPORT', '#26a69a');
    addLevel(d.resistance, 'RESISTANCE', '#ef5350');
    if (plan.entry != null) { addLevel(plan.entry, 'ENTRY', '#64a8ff', tv.LineStyle.Dashed); addLevel(plan.stop_loss, 'SL', '#ff5964', tv.LineStyle.Dashed); addLevel(plan.take_profit, 'TP', '#42d392', tv.LineStyle.Dashed); }
    if (ob) { const zoneColor = ob.direction === 'bullish' ? '#26a69a' : '#ef5350'; addLevel(ob.low, `${ob.type} LOW`, zoneColor, tv.LineStyle.Dotted); addLevel(ob.high, `${ob.type} HIGH`, zoneColor, tv.LineStyle.Dotted); }
    Object.entries(d.fibonacci?.levels || {}).forEach(([level, value]) => addLevel(value, `FIB ${level}`, '#9b8afb', tv.LineStyle.Dotted));
    forexChart.timeScale().fitContent();

    // Draw a TradingView-like shaded entry zone over the chart. Prefer the
    // bot's explicit entry range, then the detected OB, then the first pattern.
    const entryZone = (plan.entry_low != null && plan.entry_high != null)
      ? { low: Number(plan.entry_low), high: Number(plan.entry_high), label: `${plan.direction || 'ENTRY'} ZONE`, color: plan.direction === 'SELL' ? '#ef5350' : '#b45cff' }
      : ob ? { low: Number(ob.low), high: Number(ob.high), label: `${ob.type || 'ORDER BLOCK'} · ZONA PANTAU`, color: ob.direction === 'bearish' ? '#ef5350' : '#b45cff' }
      : (d.patterns && d.patterns.length) ? { low: Number(d.patterns[0].low), high: Number(d.patterns[0].high), label: `${d.patterns[0].type} · ZONA PANTAU`, color: '#b45cff' } : null;
    if (entryZone && Number.isFinite(entryZone.low) && Number.isFinite(entryZone.high)) {
      host.style.position = 'relative';
      const zoneEl = document.createElement('div');
      zoneEl.className = 'fx-entry-zone-overlay';
      zoneEl.innerHTML = `<span>${entryZone.label}</span>`;
      zoneEl.style.cssText = `position:absolute;left:38%;right:8px;pointer-events:none;z-index:5;border:1px solid ${entryZone.color};background:${entryZone.color}30;box-shadow:inset 0 0 0 1px ${entryZone.color}20;`;
      zoneEl.querySelector('span').style.cssText = `position:absolute;left:8px;top:2px;font-size:10px;font-weight:700;letter-spacing:.4px;color:#fff;background:${entryZone.color};padding:2px 6px;border-radius:3px;white-space:nowrap;`;
      host.appendChild(zoneEl);
      const placeEntryZone = () => {
        if (!forexChart || !host.contains(zoneEl)) return;
        // Lightweight Charts v4 exposes priceToCoordinate on the series, not the price scale.
        const yHigh = candleSeries.priceToCoordinate(entryZone.high);
        const yLow = candleSeries.priceToCoordinate(entryZone.low);
        if (yHigh == null || yLow == null) { zoneEl.style.display = 'none'; return; }
        const top = Math.min(yHigh, yLow), height = Math.max(3, Math.abs(yLow - yHigh));
        zoneEl.style.display = 'block'; zoneEl.style.top = `${Math.max(0, top)}px`;
        zoneEl.style.height = `${Math.min(host.clientHeight - Math.max(0, top), height)}px`;
      };
      try { placeEntryZone(); } catch (zoneErr) { console.warn('Entry zone overlay:', zoneErr); }
      forexChart.timeScale().subscribeVisibleLogicalRangeChange(() => { try { placeEntryZone(); } catch (zoneErr) { console.warn('Entry zone overlay:', zoneErr); } });
      forexChart.subscribeCrosshairMove(() => {});
      if (window.ResizeObserver) { const zoneRo = new ResizeObserver(() => { try { placeEntryZone(); } catch (zoneErr) { console.warn('Entry zone overlay:', zoneErr); } }); zoneRo.observe(host); host._fxZoneResizeObserver = zoneRo; }
    }
    startForexStream(pair, tf);
    // Keep the chart responsive when the panel changes size.
    if (window.ResizeObserver) { const ro = new ResizeObserver(entries => { if (forexChart && entries[0]) forexChart.applyOptions({ width: Math.max(300, Math.floor(entries[0].contentRect.width)), height: Math.max(280, Math.floor(entries[0].contentRect.height)) }); }); ro.observe(host); host._fxResizeObserver = ro; }
  } catch (e) { err.textContent = e.message; err.classList.remove('hide'); }
  finally { forexRefreshBusy = false; go.disabled = false; go.textContent = 'ANALISIS FOREX →'; }
}
async function startForexStream(pair, tf) {
  const status = document.getElementById('fxLiveStatus');
  const tdSymbol = pair.replace('=X', '').replace(/^([A-Z]{3})([A-Z]{3})$/, '$1/$2');
  if (forexStream && forexStream.readyState <= WebSocket.OPEN) { try { forexStream.close(); } catch (_) {} }
  if (forexStreamRetry) { clearTimeout(forexStreamRetry); forexStreamRetry = null; }
  if (forexStreamHeartbeat) { clearInterval(forexStreamHeartbeat); forexStreamHeartbeat = null; }
  forexStreamPair = tdSymbol;
  try {
    const relayUrl = window.FOREX_RELAY_WS_URL;
    if (!relayUrl || !/^wss:\/\//i.test(relayUrl)) throw new Error('URL relay WebSocket belum dikonfigurasi (FOREX_RELAY_WS_URL)');
    const ws = new WebSocket(relayUrl);
    forexStream = ws;
    ws.onopen = () => {
      if (status) status.textContent = `Relay terhubung · meminta tick ${tdSymbol}…`;
      ws.send(JSON.stringify({ action: 'subscribe', symbol: tdSymbol }));
      forexStreamHeartbeat = setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ action: 'heartbeat' })); }, 20000);
    };
    ws.onmessage = event => {
      let msg; try { msg = JSON.parse(event.data); } catch (_) { return; }
      if ((msg.event === 'price' || msg.type === 'price' || (msg.price != null && msg.symbol)) && Number.isFinite(Number(msg.price))) {
        const price = Number(msg.price); forexLastTick = price;
        const now = Number(msg.timestamp) || Math.floor(Date.now() / 1000);
        const seconds = forexTfSeconds[tf] || 86400; const bucket = Math.floor(now / seconds) * seconds;
        if (forexCandleSeries) {
          if (!forexLastLiveCandle) forexLastLiveCandle = { time: bucket, open: price, high: price, low: price, close: price };
          else if (bucket > forexLastLiveCandle.time) { const prevClose = forexLastLiveCandle.close; forexLastLiveCandle = { time: bucket, open: prevClose, high: Math.max(prevClose, price), low: Math.min(prevClose, price), close: price }; }
          else { const candleTime = forexLastLiveCandle.time; forexLastLiveCandle = { ...forexLastLiveCandle, time: candleTime, high: Math.max(forexLastLiveCandle.high, price), low: Math.min(forexLastLiveCandle.low, price), close: price }; }
          try { forexCandleSeries.update(forexLastLiveCandle); } catch (chartErr) { if (status) status.textContent = `Tick diterima (${price}), tetapi chart menolak pembaruan candle: ${chartErr.message}`; }
        }
        const priceMetric = document.querySelector('#fxSummary .fxmetric b');
        if (priceMetric) priceMetric.textContent = price.toLocaleString('en-US', { maximumFractionDigits: 5 });
        if (status) status.textContent = `● LIVE · ${tdSymbol} ${price.toLocaleString('en-US', { maximumFractionDigits: 5 })} · tick ${new Date(now * 1000).toLocaleTimeString('id-ID')} · harga diperbarui melalui relay`;
      } else if (msg.event === 'status' && status) status.textContent = msg.message || 'Relay aktif';
      else if (msg.event === 'subscribe-status' && status) status.textContent = `Status streaming ${tdSymbol}: ${msg.message || msg.status || 'diproses'}`;
      else if ((msg.status === 'error' || msg.event === 'error') && status) status.textContent = `Streaming error: ${msg.message || msg.code || 'periksa konfigurasi relay/Twelve Data'}`;
    };
    ws.onerror = () => { if (status) status.textContent = 'Koneksi ke relay gagal. Periksa URL WebSocket dan status layanan relay.'; };
    ws.onclose = () => { if (forexStream === ws) forexStream = null; if (forexStreamHeartbeat) { clearInterval(forexStreamHeartbeat); forexStreamHeartbeat = null; } if (status) status.textContent = 'Relay terputus; mencoba menyambungkan kembali…'; if (forexStreamPair === tdSymbol) forexStreamRetry = setTimeout(() => startForexStream(pair, tf), 5000); };
  } catch (e) {
    if (status) status.textContent = `${e.message}. Data chart historis tetap tersedia; streaming real-time belum aktif.`;
  }
}
const forexButton = document.getElementById('fxGo');
if (forexButton) {
  forexButton.addEventListener('click', () => runForexAnalysis());
  runForexAnalysis();
  // No 60-second polling. Tick prices are pushed through Twelve Data WebSocket.
}

