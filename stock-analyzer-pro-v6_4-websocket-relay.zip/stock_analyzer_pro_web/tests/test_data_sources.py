"""Uji lapisan data multi-sumber: parser, failover, validasi silang, penggabungan fundamental, diagnosis, integrasi."""
import json
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (ROOT, os.path.join(ROOT, "api"), os.path.dirname(os.path.abspath(__file__))):
    sys.path.insert(0, p)

import fake_yf  # noqa: E402
fake_yf.install()

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import data_sources as ds  # noqa: E402
import fundamentals_history as fh  # noqa: E402
import stock_analyzer as sa  # noqa: E402
from test_engine import fake_news, make_cfg  # noqa: E402


def prices(sym="X.JK", years=10, scale=1.0, naive=True):
    df = fake_yf.make_prices(sym, years).copy()
    for c in ("Open", "High", "Low", "Close"):
        df[c] = df[c] * scale
    if naive:
        df.index = df.index.tz_localize(None)
    return df


class Fake(ds.Provider):
    def __init__(self, name, df=None, exc=None, quote=None, overview=None, statements=None, offers=None, key_env=None):
        self.name, self.df, self.exc, self._quote = name, df, exc, quote
        self._overview, self._statements = overview, statements
        self.key_env = key_env
        self.offers = offers or {"history": df is not None or exc is not None, "quote": quote is not None,
                                 "overview": overview is not None, "statements": statements is not None}
        self.calls = {"history": 0, "quote": 0, "overview": 0, "statements": 0}

    def history(self, ticker, years, recent=False):
        self.calls["history"] += 1
        if self.exc:
            raise self.exc
        if self.df is None:
            return pd.DataFrame()
        return self.df.tail(130).copy() if recent else self.df.copy()

    def quote(self, ticker):
        self.calls["quote"] += 1
        if self.exc:
            raise self.exc
        return self._quote

    def overview(self, ticker):
        self.calls["overview"] += 1
        if self.exc:
            raise self.exc
        return dict(self._overview or {})

    def statements(self, ticker):
        self.calls["statements"] += 1
        return self._statements


def reset(providers=None):
    ds.set_providers(providers)
    sa._TTL.clear()
    sa._INFO_CACHE.clear()
    sa._HIST_CACHE.clear()


class Base(unittest.TestCase):
    def tearDown(self):
        for k in ("DATA_VALIDATE_MAX", "DATA_SOURCES", "DATA_PRIMARY", "DATA_SYMBOL_MAP", "ALPHAVANTAGE_API_KEY"):
            os.environ.pop(k, None)
        reset(None)


class Parsers(Base):
    def test_stooq_csv(self):
        rows = "\n".join(f"2025-01-{d:02d},10,11,9,{10 + d / 10},{1000 + d}" for d in range(1, 29))
        df = ds.StooqProvider.parse_csv("Date,Open,High,Low,Close,Volume\n" + rows, 1, False)
        self.assertEqual(list(df.columns), ["Open", "High", "Low", "Close", "Volume"])
        self.assertEqual(len(df), 28)
        self.assertAlmostEqual(df["Close"].iloc[-1], 12.8)
        with self.assertRaises(RuntimeError):
            ds.StooqProvider.parse_csv("No data", 1, False)

    def test_alphavantage_harian_dan_error(self):
        payload = {"Time Series (Daily)": {"2025-01-03": {"1. open": "10", "2. high": "12", "3. low": "9", "4. close": "11", "5. volume": "500"},
                                           "2025-01-02": {"1. open": "9", "2. high": "11", "3. low": "8", "4. close": "10", "5. volume": "400"}}}
        df = ds.AlphaVantageProvider.parse_daily(payload, 1, False)
        self.assertEqual(df["Close"].tolist(), [10.0, 11.0])
        self.assertTrue(df.index.is_monotonic_increasing)
        for bad in ({"Note": "limit 25 per hari"}, {"Information": "premium endpoint"}, {"Error Message": "x"}):
            with self.assertRaises(RuntimeError):
                ds.AlphaVantageProvider.check(bad)
        with self.assertRaises(RuntimeError):
            ds.AlphaVantageProvider.parse_daily({}, 1, False)

    def test_alphavantage_ringkasan_none_dibuang(self):
        o = ds.AlphaVantageProvider.normalize_overview({"Symbol": "X", "EPS": "5.5", "BookValue": "40", "PERatio": "None",
                                                         "ReturnOnEquityTTM": "-", "Currency": "USD", "Sector": "TECHNOLOGY"})
        self.assertEqual(o["trailingEps"], 5.5)
        self.assertNotIn("trailingPE", o)
        self.assertNotIn("returnOnEquity", o)
        self.assertEqual(o["sector"], "Technology")
        with self.assertRaises(RuntimeError):
            ds.AlphaVantageProvider.normalize_overview({})

    def test_eodhd_disesuaikan_dengan_adjusted_close(self):
        payload = [{"date": "2025-01-02", "open": 100, "high": 110, "low": 90, "close": 100, "adjusted_close": 50, "volume": 10},
                   {"date": "2025-01-03", "open": 100, "high": 110, "low": 90, "close": 100, "adjusted_close": 100, "volume": 10}]
        df = ds.EodhdProvider.parse_eod(payload, 1, False)
        self.assertEqual(df["Close"].tolist(), [50.0, 100.0])
        self.assertEqual(df["Open"].iloc[0], 50.0)
        with self.assertRaises(RuntimeError):
            ds.EodhdProvider.parse_eod([], 1, False)
        h = ds.EodhdProvider.normalize_highlights({"EarningsShare": 4.0, "BookValue": "30", "PERatio": 12})
        self.assertEqual(h, {"trailingEps": 4.0, "bookValue": 30.0, "trailingPE": 12.0})

    def test_twelvedata(self):
        ok = {"status": "ok", "values": [{"datetime": "2025-01-02", "open": "1", "high": "2", "low": "0.5", "close": "1.5", "volume": "10"}]}
        self.assertEqual(ds.TwelveDataProvider.parse_series(ok, 1, False)["Close"].iloc[0], 1.5)
        with self.assertRaises(RuntimeError):
            ds.TwelveDataProvider.parse_series({"status": "error", "code": 429, "message": "limit"}, 1, False)

    def test_pemetaan_simbol(self):
        st, eo, td, av = ds.StooqProvider(), ds.EodhdProvider(), ds.TwelveDataProvider(), ds.AlphaVantageProvider()
        self.assertEqual(st.map_symbol("AAPL"), "aapl.us")
        self.assertIsNone(st.map_symbol("BBCA.JK"))
        self.assertEqual(st.map_symbol("VOD.L"), "vod.uk")
        self.assertEqual(eo.map_symbol("BBCA.JK"), "BBCA.JK")
        self.assertEqual(eo.map_symbol("AAPL"), "AAPL.US")
        self.assertEqual(td.map_symbol("BBCA.JK"), "BBCA:IDX")
        self.assertEqual(td._params("BBCA.JK"), "symbol=BBCA&exchange=IDX")
        self.assertEqual(av.map_symbol("VOD.L"), "VOD.LON")
        self.assertIsNone(av.map_symbol("BBCA.JK"))
        for p in (st, eo, td, av):
            self.assertIsNone(p.map_symbol("^JKSE"))
        self.assertEqual(ds.YahooProvider().map_symbol("^JKSE"), "^JKSE")

    def test_pemetaan_simbol_dapat_ditimpa_lewat_env(self):
        os.environ["DATA_SYMBOL_MAP"] = json.dumps({"stooq": {"bbca.jk": "bbca.id"}})
        self.assertEqual(ds.StooqProvider().map_symbol("BBCA.JK"), "bbca.id")
        os.environ["DATA_SYMBOL_MAP"] = "{rusak"
        self.assertIsNone(ds.StooqProvider().map_symbol("BBCA.JK"))

    def test_kunci_api_disamarkan(self):
        self.assertNotIn("SECRET", ds._mask("https://x.com/q?function=A&apikey=SECRET123&b=1"))
        self.assertNotIn("SECRET", ds._mask("gagal https://x/?api_token=SECRET9"))

    def test_urutan_penyedia_dari_env(self):
        os.environ["DATA_SOURCES"] = "stooq,yahoo,unknown,stooq"
        os.environ["DATA_PRIMARY"] = "yahoo"
        self.assertEqual([p.name for p in ds.build_providers()], ["yahoo", "stooq"])
        os.environ["DATA_SOURCES"] = ""
        self.assertEqual([p.name for p in ds.build_providers()], ["yahoo"])


class HistoryFailoverAndValidation(Base):
    def test_sumber_utama_pertama_yang_berhasil(self):
        a, b = Fake("a", prices()), Fake("b", prices())
        reset([a, b])
        df, meta = ds.get_history("X.JK", 5, 30, False)
        self.assertEqual((meta["primary"], b.calls["history"], meta["failover"]), ("a", 0, []))
        self.assertGreater(len(df), 1000)

    def test_failover_error_kosong_dan_pendek_dengan_kunci_tersamar(self):
        a = Fake("a", exc=RuntimeError("HTTP 429 https://x/q?apikey=SECRET1"))
        b = Fake("b", pd.DataFrame())
        c = Fake("c", prices(years=0.05))         # ~17 hari
        d = Fake("d", prices())
        reset([a, b, c, d])
        _, meta = ds.get_history("X.JK", 5, 30, False)
        self.assertEqual(meta["primary"], "d")
        reasons = {x["source"]: x["reason"] for x in meta["failover"]}
        self.assertIn("429", reasons["a"])
        self.assertNotIn("SECRET1", json.dumps(meta))
        self.assertEqual(reasons["b"], "kosong")
        self.assertIn("hanya", reasons["c"])

    def test_semua_gagal_pesan_sama_dengan_perilaku_lama(self):
        reset([Fake("a", pd.DataFrame()), Fake("b", exc=RuntimeError("x"))])
        with self.assertRaises(RuntimeError) as c1:
            ds.get_history("ZZ.JK", 5, 30, False)
        self.assertIn("Tidak ada data untuk 'ZZ.JK'", str(c1.exception))
        reset([Fake("a", prices(years=0.05))])
        with self.assertRaises(RuntimeError) as c2:
            ds.get_history("SHORT.JK", 5, 30, False)
        self.assertIn("hanya", str(c2.exception))
        self.assertIn("minimal 30", str(c2.exception))

    def test_kegagalan_di_cache_negatif_tidak_memanggil_ulang(self):
        a = Fake("a", pd.DataFrame())
        reset([a])
        for _ in range(3):
            with self.assertRaises(RuntimeError):
                ds.get_history("NOPE.JK", 5, 30, False)
        self.assertEqual(a.calls["history"], 1)

    def test_validasi_ok_warn_bad(self):
        base = prices()
        warn = base.copy(); warn.iloc[-20:, :4] = warn.iloc[-20:, :4] * 1.03
        bad = prices(scale=1.2)
        for df2, expected in ((base.copy(), "ok"), (warn, "warn"), (bad, "bad")):
            reset([Fake("a", base), Fake("b", df2)])
            _, meta = ds.get_history("X.JK", 5, 30, True)
            self.assertTrue(meta["validated"])
            self.assertEqual(meta["validators"][0]["status"], expected, expected)
            self.assertEqual(meta["primary"], "a")

    def test_validator_gagal_tidak_mengganggu(self):
        reset([Fake("a", prices()), Fake("b", exc=RuntimeError("HTTP 500"))])
        _, meta = ds.get_history("X.JK", 5, 30, True)
        self.assertEqual(meta["validators"][0]["status"], "gagal")
        self.assertFalse(meta["validated"])

    def test_sumber_utama_pencilan_diganti_bila_dua_lainnya_sepakat(self):
        a, b, c = Fake("a", prices()), Fake("b", prices(scale=1.25)), Fake("c", prices(scale=1.25))
        reset([a, b, c])
        df, meta = ds.get_history("X.JK", 5, 30, True)
        self.assertEqual(meta["switched"]["from"], "a")
        self.assertEqual((meta["switched"]["to"], meta["primary"]), ("b", "b"))
        self.assertAlmostEqual(float(df["Close"].iloc[-1]), float(prices(scale=1.25)["Close"].iloc[-1]), places=6)

    def test_tidak_ganti_bila_dua_lainnya_tidak_sepakat(self):
        reset([Fake("a", prices()), Fake("b", prices(scale=1.25)), Fake("c", prices(scale=0.7))])
        _, meta = ds.get_history("X.JK", 5, 30, True)
        self.assertIsNone(meta["switched"])
        self.assertEqual(meta["primary"], "a")

    def test_batas_jumlah_validator(self):
        os.environ["DATA_VALIDATE_MAX"] = "1"
        a, b, c = Fake("a", prices()), Fake("b", prices()), Fake("c", prices())
        reset([a, b, c])
        _, meta = ds.get_history("X.JK", 5, 30, True)
        self.assertEqual(len(meta["validators"]), 1)
        self.assertEqual(c.calls["history"], 0)

    def test_tanpa_validate_tidak_menyentuh_sumber_lain(self):
        b = Fake("b", prices())
        reset([Fake("a", prices()), b])
        ds.get_history("X.JK", 5, 30, False)
        self.assertEqual(b.calls["history"], 0)

    def test_compare_series_data_terlalu_sedikit(self):
        a = pd.Series(range(100, 130), index=pd.bdate_range("2025-01-01", periods=30), dtype=float)
        r = ds.compare_series(a, a.iloc[:10])
        self.assertEqual(r["status"], "tidak_cukup")


class LiveAndInfo(Base):
    def test_harga_live_sumber_dan_validasi(self):
        reset([Fake("yahoo", prices(), quote=100.0), Fake("b", quote=101.0), Fake("c", quote=115.0)])
        price, src, meta = ds.get_live_price("X.JK", 90.0, validate=False)
        self.assertEqual((price, src, meta["status"]), (100.0, "fast_info", "tunggal"))
        _, _, meta = ds.get_live_price("X.JK", 90.0, validate=True)
        self.assertEqual(meta["status"], "bad")
        self.assertAlmostEqual(meta["max_dev_pct"], 15.0)
        reset([Fake("yahoo", prices(), quote=100.0), Fake("b", quote=104.0)])
        self.assertEqual(ds.get_live_price("X.JK", 90.0, True)[2]["status"], "warn")
        reset([Fake("yahoo", prices(), quote=100.0), Fake("b", quote=101.0)])
        self.assertEqual(ds.get_live_price("X.JK", 90.0, True)[2]["status"], "ok")

    def test_harga_live_failover_dan_fallback_close(self):
        reset([Fake("yahoo", prices(), quote=None, offers={"history": True, "quote": True}), Fake("eodhd", quote=55.5)])
        price, src, _ = ds.get_live_price("X.JK", 50.0)
        self.assertEqual((price, src), (55.5, "eodhd"))
        reset([Fake("yahoo", prices(), exc=RuntimeError("x"), offers={"history": True, "quote": True})])
        self.assertEqual(ds.get_live_price("X.JK", 50.0)[1], "close_terakhir")

    def test_merge_info_isi_konflik_dan_mata_uang(self):
        primary = {"trailingEps": 10.0, "bookValue": 100.0, "currency": "IDR"}
        sec = {"trailingEps": 25.0, "bookValue": 101.0, "trailingPE": 12.0, "sharesOutstanding": 1e9, "currency": "IDR"}
        merged, meta = ds.merge_info(primary, "yahoo", [("av", sec)])
        self.assertEqual(merged["trailingEps"], 10.0)                   # sumber utama tidak ditimpa
        self.assertEqual({f["field"] for f in meta["filled"]}, {"trailingPE", "sharesOutstanding"})
        self.assertEqual([c["field"] for c in meta["conflicts"]], ["trailingEps"])
        self.assertAlmostEqual(meta["conflicts"][0]["diff_pct"], abs(10 / 25 - 1) * 100)
        merged2, meta2 = ds.merge_info(primary, "yahoo", [("av", {**sec, "currency": "USD"})])
        self.assertEqual(meta2["conflicts"], [])
        self.assertNotIn("sharesOutstanding", [f["field"] for f in meta2["filled"] if f["field"] in ("trailingEps",)])
        self.assertTrue(meta2["notes"])

    def test_get_info_hanya_mengisi_bila_perlu(self):
        full = {k: 1.0 for k in ds.CORE_KEYS}
        sec = Fake("b", overview={"trailingEps": 1.0})
        reset([Fake("yahoo", overview=full), sec])
        ds.get_info("X.JK", validate=False)
        self.assertEqual(sec.calls["overview"], 0)
        ds.get_info("X.JK", validate=True)
        self.assertEqual(sec.calls["overview"], 1)
        sec2 = Fake("b", overview={"bookValue": 40.0, "trailingPE": 9.0, "returnOnEquity": 0.12})
        reset([Fake("yahoo", overview={"trailingEps": 5.0}), sec2])
        info, meta = ds.get_info("X.JK", validate=False)           # <3 kunci inti: isi celah walau tanpa validasi
        self.assertEqual(sec2.calls["overview"], 1)
        self.assertEqual(info["bookValue"], 40.0)
        self.assertEqual(meta["primary"], "yahoo")

    def test_get_info_utama_gagal_pindah_ke_sumber_lain(self):
        reset([Fake("yahoo", exc=RuntimeError("HTTP 429"), offers={"overview": True}), Fake("b", overview={"trailingEps": 3.0})])
        info, meta = ds.get_info("X.JK")
        self.assertEqual((meta["primary"], info["trailingEps"]), ("b", 3.0))
        self.assertIn("yahoo", meta["errors"])


AV_INC = {"annualReports": [{"fiscalDateEnding": f"{y}-12-31", "totalRevenue": str(r), "netIncome": str(n)}
                            for y, r, n in ((2024, 1000, 100), (2023, 900, 80), (2022, 800, 70))]}
AV_BS = {"annualReports": [{"fiscalDateEnding": f"{y}-12-31", "totalAssets": str(a), "totalShareholderEquity": str(e),
                            "shortLongTermDebtTotal": "50", "commonStockSharesOutstanding": "10"}
                           for y, a, e in ((2024, 2000, 500), (2023, 1800, 450), (2022, 1600, 400))]}
AV_CF = {"annualReports": [{"fiscalDateEnding": f"{y}-12-31", "operatingCashflow": str(c), "capitalExpenditures": "30"}
                           for y, c in ((2024, 150), (2023, 130), (2022, 110))]}


class Statements(Base):
    def test_adaptor_alphavantage_ke_baris_riwayat(self):
        ad = ds.AlphaVantageProvider.statements_adapter(AV_INC, AV_BS, AV_CF)
        rows = fh._annual_rows(ad)
        self.assertEqual([r["year"] for r in rows], ["2022", "2023", "2024"])
        last = rows[-1]
        self.assertEqual((last["revenue"], last["net_income"], last["equity"]), (1000.0, 100.0, 500.0))
        self.assertEqual((last["cfo"], last["fcf"]), (150.0, 120.0))        # CFO - |capex|
        self.assertAlmostEqual(last["roe"], 100 / 500)
        self.assertEqual(last["shares_outstanding"], 10.0)

    def test_cadangan_dipakai_hanya_bila_yahoo_kosong(self):
        ad = ds.AlphaVantageProvider.statements_adapter(AV_INC, AV_BS, AV_CF)
        av = Fake("alphavantage", statements=ad, offers={"history": False, "statements": True})
        reset([ds.YahooProvider(), av])
        close = prices()["Close"]
        r = fh.build_history("NOSTMT.JK", close)
        self.assertTrue(r["available"])
        self.assertEqual(r["source"], "alphavantage")
        self.assertEqual(av.calls["statements"], 1)
        r2 = fh.build_history("BRPT.JK", close)
        self.assertEqual(r2["source"], "yahoo")
        self.assertEqual(av.calls["statements"], 1)                         # tidak dipanggil lagi

    def test_tanpa_cadangan_hasilnya_tidak_tersedia(self):
        reset([ds.YahooProvider()])
        r = fh.build_history("NOSTMT.JK", prices()["Close"])
        self.assertFalse(r["available"])


class Diagnose(Base):
    def test_diagnosis_tidak_membocorkan_kunci(self):
        os.environ["ALPHAVANTAGE_API_KEY"] = "SECRETKEY123"
        boom = Fake("boom", exc=RuntimeError("HTTP 401 https://x/q?apikey=SECRETKEY123"))
        reset([Fake("ok", prices(), quote=10.0, overview={"trailingEps": 1.0}), boom, ds.AlphaVantageProvider()])
        out = ds.diagnose("AAPL")
        text = json.dumps(out)
        self.assertNotIn("SECRETKEY123", text)
        by = {r["source"]: r for r in out["providers"]}
        self.assertEqual(by["ok"]["status"], "ok")
        self.assertEqual(by["ok"]["quote"], 10.0)
        self.assertEqual(by["boom"]["status"], "gagal")
        self.assertTrue(by["alphavantage"]["key_set"])

    def test_status_tanpa_kunci_dan_tidak_didukung(self):
        reset([ds.EodhdProvider(), ds.StooqProvider()])
        by = {r["source"]: r for r in ds.diagnose("BBCA.JK")["providers"]}
        self.assertEqual(by["eodhd"]["status"], "tanpa_kunci")
        self.assertEqual(by["stooq"]["status"], "tidak_didukung")
        self.assertIsNone(by["stooq"]["mapped_symbol"])


class EngineIntegration(Base):
    def setUp(self):
        sa._news_google = fake_news

    def providers(self, secondary):
        reset([ds.YahooProvider(), secondary])

    def sec(self, scale=1.0, **kw):
        return Fake("eodhd", prices("BRPT.JK", 10, scale=scale), quote=kw.pop("quote", None),
                    overview=kw.pop("overview", None), **kw)

    def test_validasi_sepakat_menambah_keyakinan(self):
        self.providers(self.sec())
        r = sa.analyze("BRPT.JK", make_cfg())
        v = r["data_sources"]["history"]["validators"]
        self.assertEqual([x["status"] for x in v], ["ok"])
        self.assertTrue(any("divalidasi silang" in x for x in r["confidence"]["reasons"]))
        self.assertFalse(any("berbeda signifikan" in w for w in r["data_quality"]["warnings"]))
        json.dumps({k: x for k, x in r.items() if k != "_criteria_obj"})

    def test_selisih_besar_menurunkan_kualitas_data(self):
        base = sa.analyze("BRPT.JK", make_cfg())["data_quality"]["score"]
        reset(None); self.providers(self.sec(scale=1.3))
        r = sa.analyze("BRPT.JK", make_cfg())
        self.assertEqual(r["data_sources"]["history"]["validators"][0]["status"], "bad")
        self.assertTrue(any("berbeda signifikan" in w for w in r["data_quality"]["warnings"]))
        self.assertLessEqual(r["data_quality"]["score"], base - 20)
        self.assertTrue(any("sumber data harga berbeda signifikan" in x for x in r["confidence"]["reasons"]))

    def test_konflik_fundamental_masuk_peringatan_dan_harga_wajar(self):
        probe = sa.analyze("BRPT.JK", make_cfg())["fundamentals"]["eps"]
        reset(None)
        self.providers(self.sec(overview={"trailingEps": probe * 2.5, "currency": "IDR"}))
        r = sa.analyze("BRPT.JK", make_cfg())
        self.assertEqual([c["field"] for c in r["data_sources"]["fundamentals"]["conflicts"]], ["trailingEps"])
        self.assertTrue(any("Sumber fundamental berbeda" in w for w in r["data_quality"]["warnings"]))
        self.assertTrue(any("Sumber data berbeda untuk trailingEps" in f for f in r["fair_value"]["flags"]))

    def test_failover_sumber_pertama_gagal(self):
        reset([Fake("eodhd", exc=RuntimeError("HTTP 429")), ds.YahooProvider()])
        r = sa.analyze("BRPT.JK", make_cfg())
        self.assertEqual(r["data_sources"]["history"]["primary"], "yahoo")
        self.assertTrue(any("Sumber harga utama gagal" in w for w in r["data_quality"]["warnings"]))

    def test_mode_cepat_tidak_memvalidasi(self):
        sec = self.sec()
        self.providers(sec)
        r = sa.analyze("BRPT.JK", make_cfg(fast=True))
        self.assertEqual(r["data_sources"]["history"]["validators"], [])
        self.assertFalse(r["data_sources"]["validation_enabled"])
        self.assertEqual(sec.calls["history"], 0)

    def test_dimatikan_lewat_konfigurasi(self):
        sec = self.sec()
        self.providers(sec)
        sa.analyze("BRPT.JK", make_cfg(validate_sources=False))
        self.assertEqual(sec.calls["history"], 0)

    def test_cadangan_laporan_keuangan_terbawa_ke_hasil(self):
        ad = ds.AlphaVantageProvider.statements_adapter(AV_INC, AV_BS, AV_CF)
        reset([ds.YahooProvider(), Fake("alphavantage", statements=ad, offers={"history": False, "statements": True})])
        r = sa.analyze("NOSTMT.JK", make_cfg())
        self.assertEqual(r["data_sources"]["statements"]["source"], "alphavantage")
        self.assertTrue(r["history"]["available"])

    def test_render_cli_menampilkan_sumber(self):
        self.providers(self.sec())
        txt = sa.render(sa.analyze("BRPT.JK", make_cfg()), make_cfg())
        self.assertIn("SUMBER DATA", txt)
        self.assertIn("validator eodhd", txt)


if __name__ == "__main__":
    unittest.main()
