"""Uji mesin analisis dengan yfinance tiruan. Jalankan:  python -m unittest discover -s tests -v"""
import json
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import fake_yf  # noqa: E402
fake_yf.install()

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import fundamentals_history as fh  # noqa: E402
import quant  # noqa: E402
import stock_analyzer as sa  # noqa: E402


def make_cfg(**kw):
    cfg = dict(sa.DEFAULTS)
    cfg.update(market="id", benchmark="^JKSE", news_cache_seconds=0)
    cfg.update(kw)
    return cfg


def fake_news(*a, **k):
    now = datetime.now(timezone.utc)
    mk = lambda t, h: {"title": t, "source": "Contoh", "published": now - timedelta(hours=h), "url": "http://x"}
    return [mk("Laba BBCA naik, saham menguat", 5), mk("BBCA cetak rekor laba", 20), mk("Saham BBCA melonjak", 30)]


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sa._news_google = fake_news
        cls.bank = sa.analyze("BBCA.JK", make_cfg())

    def test_struktur_dan_json(self):
        r = {k: v for k, v in self.bank.items() if k != "_criteria_obj"}
        json.dumps(r)  # semua tipe harus murni Python (bukan numpy)
        for key in ("profile", "metrics", "criteria", "history", "backtest", "montecarlo",
                    "chart", "risk_flags", "confidence", "verdict", "news", "data_quality"):
            self.assertIn(key, r)
        self.assertEqual(self.bank["mode"], "full")
        self.assertLessEqual(len(r["chart"]["dates"]), 160)
        self.assertEqual(len(r["chart"]["dates"]), len(r["chart"]["sma200"]))

    def test_profil_bank_tanpa_der_dan_net_margin(self):
        self.assertEqual(self.bank["profile"]["profile"], "BANK")
        names = [c["name"] for c in self.bank["criteria"]]
        self.assertNotIn("Utang (DER)", names)
        self.assertNotIn("Net margin", names)
        self.assertIn("ROA", names)
        self.assertIn("PBV vs ROE (wajar)", names)

    def test_riwayat_fundamental(self):
        h = self.bank["history"]
        self.assertTrue(h["available"])
        periods = [r["period"] for r in h["rows"]]
        self.assertEqual(periods.count("FY"), 4)
        self.assertEqual(periods[-1], "TTM")
        s = h["summary"]
        self.assertEqual(s["profit_years"], 4)
        # laba 25 -> 40 selama 3 tahun
        self.assertAlmostEqual(s["net_income_cagr"], (40 / 25) ** (1 / 3) - 1, places=6)
        names = [c["name"] for c in self.bank["criteria"]]
        self.assertIn("CAGR laba bersih", names)
        self.assertIn("Valuasi vs riwayat", names)
        self.assertNotIn("Kualitas laba (CFO/NI)", names)  # bank: CFO/NI tidak relevan

    def test_subskor_kelompok(self):
        g = self.bank["verdict"]["groups"]
        for k in ("performa", "teknikal", "relatif", "fundamental", "riwayat", "berita"):
            self.assertIn(k, g)
            self.assertTrue(0 <= g[k] <= 100)
        self.assertTrue(0 <= self.bank["verdict"]["score_pct"] <= 100)

    def test_montecarlo(self):
        mc = self.bank["montecarlo"]
        self.assertTrue(mc["available"])
        for key in ("neutral_drift", "historical_drift"):
            d = mc[key]
            self.assertTrue(d["p5"] <= d["p25"] <= d["p50"] <= d["p75"] <= d["p95"])
        self.assertLess(abs(mc["neutral_drift"]["p50"]), 0.5)  # netral: median dipusatkan ke nol
        self.assertGreater(mc["neutral_drift"]["p95"], 0)
        self.assertLess(mc["neutral_drift"]["p5"], 0)

    def test_backtest_dengan_indeks(self):
        bt = self.bank["backtest"]
        self.assertTrue(bt["available"])
        self.assertTrue(bt["has_benchmark"])
        self.assertIsNotNone(bt["base_beat_pct"])
        self.assertGreater(bt["samples"], 30)

    def test_berita_masuk_kriteria(self):
        self.assertTrue(self.bank["news"]["available"])
        self.assertIn("Sentimen berita", [c["name"] for c in self.bank["criteria"]])

    def test_perusahaan_rugi_tidak_layak_beli(self):
        r = sa.analyze("GOTO.JK", make_cfg())
        crit = {c["name"]: c for c in r["criteria"]}
        self.assertEqual(crit["PER (valuasi laba)"]["score"], -2)
        self.assertNotEqual(r["verdict"]["final_label"], "LAYAK BELI")
        self.assertTrue(any("rugi" in f.lower() for f in r["risk_flags"]))

    def test_mode_cepat(self):
        r = sa.analyze("BBCA.JK", make_cfg(fast=True))
        self.assertEqual(r["mode"], "fast")
        self.assertIsNone(r["backtest"])
        self.assertIsNone(r["history"])
        self.assertIsNone(r["montecarlo"])
        self.assertIsNone(r["news"])
        self.assertEqual(r["skipped"], [])

    def test_batas_waktu_melewati_modul(self):
        r = sa.analyze("BBCA.JK", make_cfg(time_budget=0.0))
        self.assertTrue({"berita", "riwayat fundamental", "backtest", "monte carlo"} <= set(r["skipped"]))
        self.assertTrue(any("batas waktu" in x for x in r["confidence"]["reasons"]))

    def test_data_tidak_ada_dan_terlalu_pendek(self):
        with self.assertRaises(RuntimeError) as c1:
            sa.analyze("ZZZZ.JK", make_cfg())
        self.assertIn("Tidak ada data", str(c1.exception))
        with self.assertRaises(RuntimeError) as c2:
            sa.analyze("NEW.JK", make_cfg())
        self.assertIn("hanya", str(c2.exception))


    def test_saham_histori_pendek_dianalisis_dengan_batasan(self):
        r = sa.analyze("RANS.JK", make_cfg(fast=True))
        self.assertEqual(r["mode"], "fast")
        self.assertLess(len(r["chart"]["dates"]), 250)
        self.assertIsNone(r["metrics"]["sma200"])
        trend = next(c for c in r["criteria"] if c["name"] == "Tren (SMA50/SMA200)")
        self.assertIn("SMA200 belum tersedia", trend["value"])
        self.assertTrue(any("histori hanya" in w for w in r["data_quality"]["warnings"]))

    def test_render_cli(self):
        txt = sa.render(self.bank, make_cfg())
        for kw in ("VONIS", "KEYAKINAN", "MONTE CARLO", "RIWAYAT FUNDAMENTAL", "BACKTEST", "skor kelompok"):
            self.assertIn(kw, txt)


class UnitTests(unittest.TestCase):
    def test_referensi_valuasi_historis_hanya_jika_data_memadai(self):
        no_data = sa.build_valuation_reference(100.0, {"eps": 5.0, "pb": 2.0}, None)
        self.assertFalse(no_data["available"])
        hist = {"available": True, "summary": {"per_avg": 12.0, "per_n": 4,
                "pbv_avg": 1.5, "pbv_n": 4}}
        result = sa.build_valuation_reference(100.0, {"eps": 5.0, "pb": 2.0}, hist)
        self.assertTrue(result["available"])
        self.assertEqual(len(result["methods"]), 2)
        self.assertAlmostEqual(result["reference_price"], 67.5)
        self.assertIn("bukan nilai intrinsik", result["disclaimer"])

    def test_referensi_valuasi_menjelaskan_data_yang_kurang(self):
        result = sa.build_valuation_reference(100.0, {"eps": None, "pb": 2.0},
                    {"available": True, "summary": {"per_avg": None, "per_n": 0,
                     "pbv_avg": 1.5, "pbv_n": 2}})
        self.assertFalse(result["available"])
        self.assertEqual(result["per_periods"], 0)
        self.assertEqual(result["pbv_periods"], 2)
        self.assertIn("EPS terbaru", result["reason"])
        self.assertIn("PBV historis valid hanya 2/3", result["reason"])

    def test_harga_close_fallback_menurunkan_kualitas_data(self):
        import pandas as pd
        idx = pd.bdate_range(end=pd.Timestamp.now().normalize(), periods=300)
        df = pd.DataFrame({"Close": [100.0] * len(idx), "Volume": [100000.0] * len(idx)}, index=idx)
        cfg = dict(sa.DEFAULTS)
        live = sa.check_data_quality(df, 100.0, cfg, "fast_info")
        fallback = sa.check_data_quality(df, 100.0, cfg, "close_terakhir")
        self.assertLess(fallback["score"], live["score"])
        self.assertTrue(any("bukan harga live" in w for w in fallback["warnings"]))

    def test_verdict_melewati_kelompok_kosong(self):
        cfg = make_cfg()
        a = sa.Criterion("x", "", 2, -2, 2, "", "performa")
        b = sa.Criterion("y", "", 2, -2, 2, "", "teknikal")
        v = sa.verdict([a, b], cfg)
        self.assertEqual(v["score_pct"], 100.0)
        self.assertEqual(v["label"], "LAYAK BELI")
        self.assertEqual(sa.verdict([], cfg)["score_pct"], 0.0)

    def test_cagr_dan_konsistensi(self):
        rows = [{"year": str(2021 + i), "period": "FY", "net_income": 100 * 1.1 ** i, "revenue": 1000.0,
                 "roe": 0.15, "roa": 0.05, "npm": 0.1, "de": 0.5, "cfo_ni": 1.1,
                 "revenue_growth": None, "earnings_growth": None} for i in range(5)]
        s = fh.summarize(rows, {})
        self.assertAlmostEqual(s["net_income_cagr"], 0.10, places=6)
        self.assertEqual(s["profit_years"], 5)
        self.assertAlmostEqual(s["roe_avg"], 0.15)
        self.assertIsNone(s["revenue_cagr"] if False else None)

    def test_cagr_butuh_tiga_titik_dan_nilai_positif(self):
        two = [{"year": "2023", "period": "FY", "net_income": 10.0}, {"year": "2024", "period": "FY", "net_income": 12.0}]
        self.assertIsNone(fh._cagr(two, "net_income"))
        neg = [{"year": str(2022 + i), "period": "FY", "net_income": v} for i, v in enumerate((-5.0, 3.0, 9.0))]
        self.assertIsNone(fh._cagr(neg, "net_income"))

    def test_sentimen_judul(self):
        neg, crit, _ = sa.score_headline("Saham ABCD anjlok, laba turun tajam")
        pos, _, _ = sa.score_headline("Saham ABCD melonjak, laba naik")
        flipped, _, _ = sa.score_headline("Laba tidak turun")
        self.assertLess(neg, 0)
        self.assertGreater(pos, 0)
        self.assertGreater(flipped, 0)
        _, flags, cata = sa.score_headline("OJK buka investigasi, emiten umumkan dividen")
        self.assertTrue(any("investigasi" in f for f in flags))
        self.assertIn("dividen", cata)

    def test_monte_carlo_deterministik(self):
        close = fake_yf.make_prices("TEST", 5)["Close"]
        a = quant.monte_carlo(close, 126, 1000, 10, 7)
        b = quant.monte_carlo(close, 126, 1000, 10, 7)
        self.assertEqual(a["neutral_drift"], b["neutral_drift"])
        short = quant.monte_carlo(close.tail(100))
        self.assertFalse(short["available"])

    def test_backtest_beat_dengan_indeks_sama(self):
        close = fake_yf.make_prices("SAMA", 10)["Close"]
        res = sa.run_backtest(close, make_cfg(), bench=close)
        self.assertTrue(res["has_benchmark"])
        self.assertEqual(res["base_beat_pct"], 0.0)   # sama persis dengan indeks -> tidak pernah mengalahkan
        self.assertFalse(sa.run_backtest(close.tail(300), make_cfg())["available"])

    def test_ttl_cache_tidak_menyimpan_kosong(self):
        calls = []

        @sa.ttl_cache(60)
        def f(x):
            calls.append(x)
            return {} if x == "gagal" else {"ok": x}

        f("gagal"); f("gagal"); f("a"); f("a")
        self.assertEqual(calls, ["gagal", "gagal", "a"])


class FairValueEngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sa._news_google = fake_news
        cls.default = sa.analyze("BRPT.JK", make_cfg())
        cls.bank = sa.analyze("BBCA.JK", make_cfg())

    def test_harga_wajar_ada_dan_multi_metode(self):
        fv = self.default["fair_value"]
        self.assertTrue(fv["available"])
        keys = {m["key"] for m in fv["methods"] if m["included"]}
        self.assertGreaterEqual(len(keys), 4)
        self.assertLessEqual(fv["low"], fv["base"])
        self.assertLessEqual(fv["base"], fv["high"])
        self.assertAlmostEqual(fv["mos_price"], fv["base"] * 0.75, places=6)
        self.assertIn(fv["label"], ("DI BAWAH HARGA WAJAR", "MENDEKATI HARGA WAJAR", "DI ATAS HARGA WAJAR"))
        self.assertIn(fv["confidence"]["label"], ("TINGGI", "SEDANG", "RENDAH"))
        json.dumps(fv)                                   # harus JSON murni

    def test_bank_tanpa_dcf_non_bank_dengan_dcf(self):
        self.assertIn("dcf", [m["key"] for m in self.default["fair_value"]["methods"]])
        self.assertIn("dcf", [u["key"] for u in self.bank["fair_value"]["unavailable"]])

    def test_riwayat_membawa_arus_kas_bebas(self):
        fy = [r for r in self.default["history"]["rows"] if r["period"] == "FY"]
        self.assertTrue(all(r.get("fcf") is not None for r in fy))
        self.assertAlmostEqual(fy[-1]["fcf"], 44e9 - 8e9, places=0)       # CFO - |capex| tahun terbaru

    def test_penanda_risiko_premi_besar(self):
        fv = self.bank["fair_value"]
        self.assertGreater(fv["premium_pct"], 40)
        self.assertTrue(any("di atas harga wajar" in f for f in self.bank["risk_flags"]))

    def test_tidak_ikut_skor_secara_bawaan_tapi_bisa_diaktifkan(self):
        names = [c["name"] for c in self.default["criteria"]]
        self.assertNotIn("Harga vs harga wajar", names)
        r = sa.analyze("BRPT.JK", make_cfg(fair_value_in_score=True))
        crit = {c["name"]: c for c in r["criteria"]}
        self.assertIn("Harga vs harga wajar", crit)
        self.assertEqual(crit["Harga vs harga wajar"]["group"], "fundamental")

    def test_asumsi_pengguna_mengubah_hasil(self):
        base = self.default["fair_value"]
        hi_ke = sa.analyze("BRPT.JK", make_cfg(cost_of_equity=0.16))["fair_value"]
        self.assertAlmostEqual(hi_ke["assumptions"]["ke"], 0.16)
        self.assertLess(hi_ke["base"], base["base"])                    # biaya modal lebih tinggi -> lebih murah
        mos = sa.analyze("BRPT.JK", make_cfg(fair_value_mos=0.4))["fair_value"]
        self.assertAlmostEqual(mos["mos_price"], mos["base"] * 0.6, places=6)

    def test_perusahaan_rugi_dan_beda_kurs(self):
        loss = sa.analyze("GOTO.JK", make_cfg())["fair_value"]
        self.assertTrue(any("rugi" in x for x in loss["flags"]))
        self.assertIn("pbv_roe", [u["key"] for u in loss["unavailable"]])
        mis = sa.analyze("MIS.JK", make_cfg())["fair_value"]
        self.assertTrue(any("Mata uang laporan" in x for x in mis["flags"]))
        self.assertNotIn("dcf", [m["key"] for m in mis["methods"]])

    def test_mode_cepat_tetap_menghitung_sebagian(self):
        r = sa.analyze("BRPT.JK", make_cfg(fast=True))
        fv = r["fair_value"]
        self.assertIsNone(r["history"])
        self.assertIn("available", fv)
        self.assertNotIn("dcf", [m["key"] for m in fv["methods"]])      # DCF butuh riwayat arus kas
        self.assertNotIn("per_hist", [m["key"] for m in fv["methods"]])

    def test_dimatikan_lewat_konfigurasi(self):
        self.assertIsNone(sa.analyze("BRPT.JK", make_cfg(run_fair_value=False))["fair_value"])

    def test_fundamental_membawa_field_per_saham(self):
        f = self.default["fundamentals"]
        for k in ("book_value", "dps", "payout", "shares"):
            self.assertIn(k, f)
        self.assertEqual(self.default["profile"]["financial_currency"], "IDR")

    def test_render_cli_memuat_harga_wajar(self):
        txt = sa.render(self.default, make_cfg())
        for kw in ("HARGA WAJAR", "Harga wajar dasar", "margin keamanan", "PBV wajar dari ROE"):
            self.assertIn(kw, txt)


if __name__ == "__main__":
    unittest.main()
