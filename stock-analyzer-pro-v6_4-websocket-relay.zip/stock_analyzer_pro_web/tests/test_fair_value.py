"""Uji modul harga wajar: angka dihitung tangan, bukan mengulang rumus implementasi."""
import math
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import fake_yf  # noqa: E402
fake_yf.install()

import fair_value as fv  # noqa: E402

PRICE = 1000.0


def base_inputs(price=PRICE, **over):
    """Emiten non-keuangan sehat: EPS 100, nilai buku 900, DPS 30; PER dan PBV konsisten dengan harga."""
    f = {"eps": 100.0, "pe": price / 100.0, "pb": price / 900.0, "roe_pct": 20.0, "dps": 30.0,
         "div_yield_pct": 3.0, "payout": 0.3, "shares": 1e9, "book_value": 900.0}
    f.update(over)
    return f


PROFILE = {"profile": "NON_FINANCIAL", "currency": "IDR", "financial_currency": "IDR", "market_cap": 1e12}
PARAMS = {"ke": 0.12, "g": 0.04, "mos": 0.25}


def run(f=None, profile=None, hist=None, vref=None, params=None, price=PRICE):
    return fv.estimate_fair_value(price, f or base_inputs(price), profile or PROFILE, hist, vref, params or PARAMS)


def by_key(res, key):
    return next((m for m in res["methods"] if m["key"] == key), None)


class FairValueMath(unittest.TestCase):
    def test_graham_dan_pbv_roe_dihitung_tangan(self):
        r = run()
        self.assertAlmostEqual(by_key(r, "graham")["price"], math.sqrt(22.5 * 100 * 900), places=6)   # 1423,02
        self.assertAlmostEqual(by_key(r, "pbv_roe")["price"], 900 * (0.20 - 0.04) / (0.12 - 0.04), places=6)  # 1800
        self.assertAlmostEqual(by_key(r, "ddm")["price"], 30 * 1.04 / (0.12 - 0.04), places=6)  # 390

    def test_outlier_dikecualikan_dan_median_tertimbang(self):
        r = run()
        ddm = by_key(r, "ddm")
        self.assertFalse(ddm["included"])                       # 390 < median 1423 / 3
        self.assertIn("outlier", ddm["excluded_reason"])
        self.assertTrue(r["available"])
        self.assertAlmostEqual(r["base"], 1800.0, places=6)     # bobot pbv_roe 1,0 > graham 0,5
        self.assertAlmostEqual(r["low"], math.sqrt(22.5 * 100 * 900), places=6)
        self.assertAlmostEqual(r["high"], 1800.0, places=6)

    def test_label_potensi_dan_margin_keamanan(self):
        r = run()
        self.assertEqual(r["label"], "DI BAWAH HARGA WAJAR")
        self.assertAlmostEqual(r["upside_pct"], 80.0, places=6)
        self.assertAlmostEqual(r["premium_pct"], (1000 / 1800 - 1) * 100, places=6)
        self.assertAlmostEqual(r["mos_price"], 1800 * 0.75, places=6)
        self.assertEqual(run(price=1800.0)["label"], "MENDEKATI HARGA WAJAR")
        self.assertEqual(run(price=2500.0)["label"], "DI ATAS HARGA WAJAR")

    def test_median_tertimbang(self):
        self.assertEqual(fv.weighted_median([(10, 1), (20, 1)]), 15)         # tepat di tengah -> rata-rata
        self.assertEqual(fv.weighted_median([(10, 1), (20, 3)]), 20)
        self.assertEqual(fv.weighted_median([(30, 1), (10, 1), (20, 1)]), 20)

    def test_dcf_pertumbuhan_konstan_sama_dengan_gordon(self):
        got = fv.dcf_per_share(100.0, 10.0, 0.10, 0.03, 0.03)
        self.assertAlmostEqual(got, 100 * 1.03 / (0.10 - 0.03) / 10, places=9)
        self.assertGreater(fv.dcf_per_share(100.0, 10.0, 0.10, 0.08, 0.03), got)   # pertumbuhan awal lebih tinggi
        self.assertLess(fv.dcf_per_share(100.0, 10.0, 0.14, 0.03, 0.03), got)      # diskonto lebih tinggi

    def test_dcf_dari_riwayat_arus_kas(self):
        rows = [{"period": "FY", "fcf": x} for x in (80.0, 90.0, 100.0)]
        hist = {"available": True, "rows": rows, "summary": {"periods": 3}}
        r = run(hist=hist, f=base_inputs(shares=10.0))
        dcf = by_key(r, "dcf")
        self.assertIsNotNone(dcf)
        self.assertGreater(dcf["price"], 0)
        # FCF rata-rata 90 dengan g=g1=4%: sama dengan Gordon 90*1,04/(0,12-0,04)/10
        self.assertAlmostEqual(dcf["price"], 90 * 1.04 / (0.12 - 0.04) / 10, places=6)


class FairValueGuards(unittest.TestCase):
    def test_beda_mata_uang_menonaktifkan_metode_eps_dan_arus_kas(self):
        r = run(profile={**PROFILE, "financial_currency": "USD"})
        self.assertIsNone(by_key(r, "graham"))
        self.assertTrue(any("Mata uang laporan" in x for x in r["flags"]))
        self.assertIn("graham", [u["key"] for u in r["unavailable"]])
        self.assertIn("dcf", [u["key"] for u in r["unavailable"]])
        self.assertIsNotNone(by_key(r, "pbv_roe"))              # berbasis rasio, tetap aman

    def test_eps_tidak_konsisten_dengan_per_dan_harga(self):
        r = run(f=base_inputs(eps=500.0))                       # 500 x PER 10 = 5000 vs harga 1000
        self.assertIsNone(by_key(r, "graham"))
        self.assertTrue(any("EPS dan PER" in x for x in r["flags"]))

    def test_distorsi_buyback_pbv_ekstrem(self):
        r = run(f=base_inputs(pb=40.0, roe_pct=150.0, book_value=25.0))
        self.assertIsNone(by_key(r, "pbv_roe"))
        self.assertTrue(any("ekstrem" in u["reason"] for u in r["unavailable"] if u["key"] == "pbv_roe"))

    def test_perusahaan_rugi(self):
        r = run(f=base_inputs(eps=-20.0, pe=None, roe_pct=-8.0, dps=None, div_yield_pct=None))
        for key in ("graham", "pbv_roe", "ddm"):
            self.assertIsNone(by_key(r, key), key)
        self.assertTrue(any("rugi" in x for x in r["flags"]))

    def test_bank_tanpa_dcf_dan_bobot_pbv_roe_lebih_besar(self):
        r = run(profile={**PROFILE, "profile": "BANK"})
        self.assertIn("dcf", [u["key"] for u in r["unavailable"]])
        self.assertAlmostEqual(by_key(r, "pbv_roe")["weight"], 1.5)

    def test_roe_dibatasi_40_persen(self):
        r = run(f=base_inputs(roe_pct=45.0, pb=2.0, book_value=500.0, eps=50.0, pe=20.0))
        self.assertTrue(r["assumptions"]["roe_used"] <= 0.40 + 1e-9)

    def test_estimasi_di_luar_rentang_dikecualikan(self):
        r = run(f=base_inputs(dps=500.0, div_yield_pct=50.0))   # DDM = 500*1,04/0,08 = 6500 = 6,5x -> dalam band
        self.assertIsNotNone(by_key(r, "ddm"))
        r2 = run(f=base_inputs(dps=3000.0, div_yield_pct=300.0, payout=0.5))
        ddm = by_key(r2, "ddm")
        self.assertFalse(ddm["included"])
        self.assertIn("di luar rentang", ddm["excluded_reason"])

    def test_tidak_cukup_metode(self):
        r = run(f={"eps": None, "pe": None, "pb": None, "roe_pct": None, "dps": None, "div_yield_pct": None})
        self.assertFalse(r["available"])
        self.assertIn("reason", r)
        single = run(f={"eps": None, "pe": None, "pb": PRICE / 900.0, "roe_pct": 20.0, "dps": None, "div_yield_pct": None})
        self.assertFalse(single["available"])
        self.assertEqual(len(single["indications"]), 1)
        self.assertIn("satu metode", single["reason"])

    def test_harga_tidak_valid(self):
        self.assertFalse(fv.estimate_fair_value(0, {}, PROFILE, None, None, PARAMS)["available"])
        self.assertFalse(fv.estimate_fair_value(None, {}, PROFILE, None, None, PARAMS)["available"])

    def test_konsensus_analis_hanya_pembanding(self):
        r = run(f=base_inputs(target_mean=1500.0, analyst_n=10))
        self.assertAlmostEqual(r["analyst"]["gap_pct"], 50.0, places=6)
        self.assertAlmostEqual(r["base"], 1800.0, places=6)     # tidak mengubah hasil


class FairValueSingleMethod(unittest.TestCase):
    """Kasus nyata: hanya Graham yang lolos -> harga wajar ditahan, tetapi angka indikatif tampil."""

    def low_roe_inputs(self, price=50.0):
        # EPS 1, nilai buku 100 -> ROE 1% (di bawah g 4%), tanpa dividen, tanpa riwayat
        return {"eps": 1.0, "pe": price / 1.0, "pb": price / 100.0, "roe_pct": 1.0, "dps": None,
                "div_yield_pct": None, "payout": None, "shares": None, "book_value": 100.0}

    def test_satu_metode_tidak_menjadi_harga_wajar_tetapi_ada_indikasi(self):
        r = run(f=self.low_roe_inputs(), price=50.0)
        self.assertFalse(r["available"])
        self.assertIn("satu metode", r["reason"])
        iv = r["indicative"]
        self.assertAlmostEqual(iv["price"], math.sqrt(22.5 * 1.0 * 100.0), places=6)     # 47,43
        self.assertAlmostEqual(iv["upside_pct"], (math.sqrt(2250) / 50.0 - 1) * 100, places=6)
        reasons = {u["key"]: u["reason"] for u in r["unavailable"]}
        self.assertIn("tidak melebihi", reasons["pbv_roe"])
        self.assertIn("tidak ada dividen", reasons["ddm"])
        self.assertIn("per_hist", reasons)

    def test_tanpa_metode_tidak_ada_indikasi(self):
        r = run(f={"eps": None, "pe": None, "pb": None, "roe_pct": None, "dps": None, "div_yield_pct": None})
        self.assertFalse(r["available"])
        self.assertIsNone(r["indicative"])

    def test_roe_diturunkan_dari_eps_dan_nilai_buku(self):
        # ROE tidak disediakan sumber; EPS 100 / nilai buku 900 = 11,11%
        r = run(f=base_inputs(roe_pct=None, dps=None, div_yield_pct=None, payout=None))
        m = by_key(r, "pbv_roe")
        self.assertIsNotNone(m)
        self.assertAlmostEqual(m["price"], 900 * (100 / 900 - 0.04) / 0.08, places=6)      # 800
        self.assertIn("diturunkan dari EPS", m["note"])
        self.assertTrue(r["available"])                                                       # Graham + PBV-ROE = 2 metode

    def test_roe_dari_sumber_tidak_ditimpa(self):
        m = by_key(run(), "pbv_roe")
        self.assertNotIn("diturunkan", m["note"])


class FairValueSensitivity(unittest.TestCase):
    def test_arah_sensitivitas(self):
        r = run()
        s = r["sensitivity"]
        self.assertEqual(len(s["grid"]), len(s["g_values"]))
        self.assertEqual(len(s["grid"][0]), len(s["ke_values"]))
        mid = s["g_values"].index(0.04)
        row = s["grid"][mid]
        self.assertTrue(all(row[i] >= row[i + 1] for i in range(len(row) - 1)))     # ke naik -> harga wajar turun
        col = [s["grid"][i][s["ke_values"].index(0.12)] for i in range(len(s["g_values"]))]
        self.assertTrue(all(col[i] <= col[i + 1] for i in range(len(col) - 1)))     # g naik -> harga wajar naik

    def test_sel_dasar_sama_dengan_hasil_utama(self):
        r = run()
        s = r["sensitivity"]
        self.assertAlmostEqual(s["grid"][s["g_values"].index(0.04)][s["ke_values"].index(0.12)], r["base"], places=6)

    def test_konfigurasi_tidak_valid_menjadi_none(self):
        r = run(params={"ke": 0.07, "g": 0.06, "mos": 0.25})   # ke - g = 1% < 3% -> metode model dilewati
        for row in r.get("sensitivity", {"grid": []})["grid"]:
            for cell in row:
                self.assertTrue(cell is None or cell > 0)


if __name__ == "__main__":
    unittest.main()
