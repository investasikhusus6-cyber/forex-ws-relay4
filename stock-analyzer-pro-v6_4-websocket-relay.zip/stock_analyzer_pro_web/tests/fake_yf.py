"""fake_yf.py - yfinance tiruan (data sintetis deterministik) untuk uji offline."""
import types
import zlib
from datetime import datetime

import numpy as np
import pandas as pd


def _seed(sym):
    return zlib.crc32(sym.encode()) & 0xFFFFFFFF


def _years(period):
    """Ubah period gaya yfinance ('5y', '6mo') menjadi tahun."""
    if period.endswith("mo"):
        return int(period[:-2]) / 12.0
    return int(period.rstrip("y"))


def make_prices(sym, years=5, drift=0.12, vol=0.25):
    """Satu deret panjang (12 tahun) per simbol; periode pendek = potongan ekor deret yang sama,
    seperti data pasar asli (5y dan 10y konsisten di tanggal yang sama)."""
    total = 12 * 252 + 5
    rng = np.random.default_rng(_seed(sym))
    r = rng.normal(drift / 252, vol / np.sqrt(252), total)
    close = 1000 * np.exp(np.cumsum(r))
    end = pd.Timestamp(datetime.now().date()) - pd.tseries.offsets.BDay(1)
    idx = pd.bdate_range(end=end, periods=total, tz="Asia/Jakarta")
    high = close * (1 + np.abs(rng.normal(0, 0.008, total)))
    low = close * (1 - np.abs(rng.normal(0, 0.008, total)))
    vol_s = rng.integers(1_000_000, 5_000_000, total).astype(float)
    df = pd.DataFrame({"Open": close, "High": high, "Low": low, "Close": close, "Volume": vol_s}, index=idx)
    return df.tail(int(years * 252) + 5)


def _stmt(rows, years):
    cols = [pd.Timestamp(f"{y}-12-31") for y in years]
    return pd.DataFrame({c: [rows[k][i] for k in rows] for i, c in enumerate(cols)}, index=list(rows))


INFO = {
    "BBCA.JK": dict(longName="Bank Central Asia Tbk", sector="Financial Services", industry="Banks - Regional",
                    trailingPE=24.0, priceToBook=4.6, returnOnEquity=0.21, returnOnAssets=0.03, profitMargins=0.40,
                    trailingEps=380.0, debtToEquity=None, trailingAnnualDividendYield=0.027, marketCap=1.1e15),
    "GOTO.JK": dict(longName="GoTo Gojek Tokopedia Tbk", sector="Technology", industry="Internet Content",
                    trailingPE=None, priceToBook=1.2, returnOnEquity=-0.12, returnOnAssets=-0.08,
                    profitMargins=-0.9, trailingEps=-40.0, debtToEquity=12.0, marketCap=8e13),
    "AAPL": dict(longName="Apple Inc.", sector="Technology", industry="Consumer Electronics",
                 trailingPE=30.0, priceToBook=40.0, returnOnEquity=1.5, returnOnAssets=0.22, profitMargins=0.25,
                 trailingEps=6.5, debtToEquity=190.0, trailingAnnualDividendYield=0.005, marketCap=3e12,
                 targetMeanPrice=210.0, numberOfAnalystOpinions=40, recommendationKey="buy"),
}
DEFAULT_INFO = dict(longName="Contoh Tbk", sector="Industrials", industry="Conglomerates", trailingPE=14.0,
                    priceToBook=1.8, returnOnEquity=0.16, returnOnAssets=0.07, profitMargins=0.10,
                    trailingEps=100.0, debtToEquity=60.0, trailingAnnualDividendYield=0.03, marketCap=5e13)

INFO["MIS.JK"] = {**DEFAULT_INFO, "longName": "Beda Kurs Tbk", "currency": "IDR", "financialCurrency": "USD"}
INFO["AAPL"].update(currency="USD", financialCurrency="USD")

STATEMENTS = {}   # sym -> dict diisi test bila perlu


class Ticker:
    def __init__(self, sym):
        self.sym = sym.upper()

    def history(self, period="5y", auto_adjust=True, interval="1d", **kw):
        if self.sym.startswith("^"):
            years = _years(period)
            return make_prices(self.sym, years, drift=0.06, vol=0.16)
        if self.sym.startswith("NODATA") or self.sym in ("ZZZZ", "ZZZZ.JK") or self.sym in ("AAPL.JK", "NVDA.JK", "MSFT.JK"):
            return pd.DataFrame()
        years = _years(period)
        if self.sym == "NEW.JK":
            years = 0.08  # deliberately too short for minimum basic analysis
        if self.sym == "RANS.JK":
            years = 0.3  # newly listed / limited history (~64 trading sessions)
        return make_prices(self.sym, years)

    @property
    def info(self):
        d = dict(INFO.get(self.sym, DEFAULT_INFO))
        # Field per saham dibuat konsisten dengan harga live tiruan, seperti data asli yang sehat.
        px = float(self.history(period="5y")["Close"].iloc[-1]) * 1.002
        if d.get("trailingPE"):
            d["trailingEps"] = px / d["trailingPE"]
        if d.get("priceToBook"):
            d["bookValue"] = px / d["priceToBook"]
        if d.get("trailingAnnualDividendYield"):
            d["trailingAnnualDividendRate"] = px * d["trailingAnnualDividendYield"]
        if d.get("sector") != "Financial Services":
            d["sharesOutstanding"] = 36e9 / (0.05 * px)     # FCF/saham ~ 5% dari harga
        d.setdefault("currency", "IDR")
        d.setdefault("financialCurrency", d["currency"])
        return d

    @property
    def fast_info(self):
        return {"last_price": float(self.history(period="5y")["Close"].iloc[-1]) * 1.002}

    @property
    def news(self):
        return []

    # ---- laporan keuangan
    def get_income_stmt(self, freq="yearly"):
        if self.sym.startswith("NOSTMT"):
            return pd.DataFrame()
        s = STATEMENTS.get(self.sym)
        if s is not None:
            return s["inc"]
        years = [2025, 2024, 2023, 2022]
        rows = {"Total Revenue": [140e9, 125e9, 110e9, 98e9], "Net Income": [40e9, 35e9, 30e9, 25e9]}
        return _stmt(rows, years)

    def get_balance_sheet(self, freq="yearly"):
        if self.sym.startswith("NOSTMT"):
            return pd.DataFrame()
        s = STATEMENTS.get(self.sym)
        if s is not None:
            return s["bs"]
        years = [2025, 2024, 2023, 2022]
        return _stmt({"Total Assets": [1300e9, 1200e9, 1100e9, 1000e9],
                      "Stockholders Equity": [190e9, 170e9, 150e9, 135e9],
                      "Total Debt": [50e9, 48e9, 45e9, 44e9]}, years)

    def get_cashflow(self, freq="yearly"):
        if self.sym.startswith("NOSTMT"):
            return pd.DataFrame()
        s = STATEMENTS.get(self.sym)
        if s is not None:
            return s["cf"]
        years = [2025, 2024, 2023, 2022]
        return _stmt({"Operating Cash Flow": [44e9, 38e9, 31e9, 27e9],
                      "Capital Expenditure": [-8e9, -7e9, -6e9, -5e9]}, years)

    @property
    def ttm_income_stmt(self):
        return pd.DataFrame({pd.Timestamp("2026-06-30"): [150e9, 43e9]}, index=["Total Revenue", "Net Income"])

    def get_valuation_measures(self, freq="yearly", periods=5):
        cols = [pd.Timestamp(f"{y}-12-31") for y in (2025, 2024, 2023, 2022)]
        return pd.DataFrame({c: [20.0 + i, 3.5 + i * 0.2] for i, c in enumerate(cols)},
                            index=["P/E Ratio", "Price/Book"])


class Search:
    def __init__(self, q, **kw):
        self.quotes = []


def install():
    import sys
    existing = sys.modules.get("yfinance")
    if existing is not None and getattr(existing, "__version__", "") == "fake":
        return existing
    m = types.ModuleType("yfinance")
    m.Ticker, m.Search = Ticker, Search
    m.__version__ = "fake"
    sys.modules["yfinance"] = m
    return m
