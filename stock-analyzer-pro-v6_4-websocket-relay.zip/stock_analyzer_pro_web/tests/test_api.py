"""Uji API Flask dengan mesin asli + yfinance tiruan."""
import json
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (ROOT, os.path.join(ROOT, "api"), os.path.dirname(os.path.abspath(__file__))):
    sys.path.insert(0, p)

import fake_yf  # noqa: E402
fake_yf.install()

import index as api  # noqa: E402
import stock_analyzer as sa  # noqa: E402
from test_engine import fake_news  # noqa: E402


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sa._news_google = fake_news
        api.yahoo_search = lambda q, n: []
        cls.c = api.app.test_client()

    def get(self, url):
        r = self.c.get(url)
        return r.status_code, r.get_json()

    def test_health_dan_statis(self):
        code, j = self.get("/api/health")
        self.assertEqual((code, j["version"]), (200, "v6.0"))
        for path in ("/", "/app.js", "/style.css"):
            r = self.c.get(path)
            self.assertEqual(r.status_code, 200, path)
            self.assertEqual(r.headers["Cache-Control"], "no-cache")

    def test_analisis_penuh(self):
        code, j = self.get("/api/analyze?ticker=bbca&market=auto")
        self.assertEqual(code, 200)
        d = j["data"]
        self.assertEqual((d["ticker"], d["resolved_market"], d["mode"]), ("BBCA.JK", "id", "full"))
        for k in ("montecarlo", "history", "backtest", "chart", "confidence", "verdict", "risk_flags"):
            self.assertIsNotNone(d[k], k)

    def test_mode_cepat(self):
        code, j = self.get("/api/analyze?ticker=BBCA&mode=fast")
        d = j["data"]
        self.assertEqual((code, d["mode"]), (200, "fast"))
        self.assertIsNone(d["backtest"])
        self.assertIsNone(d["montecarlo"])
        self.assertIsNotNone(d["chart"])

    def test_opsi_modul_dimatikan(self):
        _, j = self.get("/api/analyze?ticker=BBCA&backtest=0&news=0&history=0&mc=0")
        d = j["data"]
        self.assertEqual((d["backtest"], d["news"], d["history"], d["montecarlo"]), (None, None, None, None))

    def test_auto_pasar_ke_as(self):
        code, j = self.get("/api/analyze?ticker=AAPL&mode=fast")
        self.assertEqual((code, j["data"]["ticker"], j["data"]["resolved_market"]), (200, "AAPL", "us"))
        code, j = self.get("/api/analyze?ticker=AAPL&market=id&mode=fast")
        self.assertEqual(code, 404)

    def test_error_terkontrol(self):
        self.assertEqual(self.get("/api/analyze?ticker=ZZZZ&mode=fast")[0], 404)
        self.assertEqual(self.get("/api/analyze?ticker=NEW&mode=fast")[0], 422)
        self.assertEqual(self.get("/api/analyze?ticker=bad%20ticker!")[0], 400)
        self.assertEqual(self.get("/api/analyze?ticker=")[0], 400)
        self.assertEqual(self.get("/api/analyze?ticker=BBCA&years=99")[0], 400)
        self.assertEqual(self.get("/api/analyze?ticker=BBCA&market=eu")[0], 400)

    def test_bandingkan(self):
        code, j = self.get("/api/compare?tickers=BBCA,GOTO,BRPT,ZZZZ")
        self.assertEqual(code, 200)
        res = j["results"]
        self.assertEqual(len(res), 4)
        ok = [r for r in res if "error" not in r]
        self.assertEqual(len(ok), 3)
        scores = [r["score"] for r in ok]
        self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertEqual(res[-1]["ticker"], "ZZZZ")       # yang gagal ditaruh di akhir
        self.assertIn("error", res[-1])
        self.assertEqual(self.get("/api/compare?tickers=BBCA")[0], 400)
        # Perbandingan tidak memiliki batas jumlah tetap di level aplikasi.
        code, many = self.get("/api/compare?tickers=" + ",".join(["BBCA", "GOTO", "BRPT", "TLKM", "BBRI", "BMRI", "BBNI"]))
        self.assertEqual(code, 200)
        self.assertEqual(len(many["results"]), 7)
        code, many = self.get("/api/compare?tickers=" + ",".join(f"A{i}" for i in range(1, 102)))
        self.assertEqual(code, 200)
        self.assertEqual(len(many["results"]), 101)

    def test_saham_serupa(self):
        code, j = self.get("/api/peers?ticker=BBCA&market=auto")
        self.assertEqual(code, 200)
        self.assertTrue(j["ok"])
        self.assertEqual(j["group"], "bank besar")
        self.assertIn("BBRI", [x["ticker"] for x in j["peers"]])
        self.assertNotIn("BBCA", [x["ticker"] for x in j["peers"]])
        self.assertEqual(self.get("/api/peers?ticker=bad%20ticker")[0], 400)
        code, wirg = self.get("/api/peers?ticker=WIRG.JK&market=auto")
        self.assertEqual(code, 200)
        self.assertEqual(wirg["group"], "solusi dan ekosistem digital")
        self.assertGreaterEqual(len(wirg["peers"]), 5)
        self.assertNotIn("WIRG", [x["ticker"] for x in wirg["peers"]])
        # Endpoint mengembalikan semua kandidat di kelompok; bukan hanya lima teratas.
        self.assertIn("EDGE", [x["ticker"] for x in wirg["peers"]])
        # Saham yang tidak ada di daftar kurasi tetap mendapat kandidat pembanding.
        code, dada = self.get("/api/peers?ticker=DADA.JK&market=auto")
        self.assertEqual(code, 200)
        self.assertTrue(dada["peers"])
        self.assertNotIn("DADA", [x["ticker"] for x in dada["peers"]])

    def test_pencarian(self):
        _, j = self.get("/api/search?q=telkom")
        self.assertEqual([x["symbol"] for x in j["results"]], ["TLKM"])
        self.assertEqual(self.get("/api/search?q=")[1]["results"], [])

    def test_json_aman_dari_nan(self):
        out = api.clean({"a": float("nan"), "b": [float("inf"), 1.5], "c": {"d": float("-inf")}})
        self.assertEqual(out, {"a": None, "b": [None, 1.5], "c": {"d": None}})


class FairValueApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sa._news_google = fake_news
        api.yahoo_search = lambda q, n: []
        cls.c = api.app.test_client()

    def get(self, url):
        r = self.c.get(url)
        return r.status_code, r.get_json()

    def test_endpoint_harga_wajar(self):
        code, j = self.get("/api/fairvalue?ticker=BRPT")
        d = j["data"]
        self.assertEqual((code, d["ticker"], d["resolved_market"]), (200, "BRPT.JK", "id"))
        self.assertTrue(d["fair_value"]["available"])
        self.assertIn("valuation_reference", d)
        self.assertNotIn("montecarlo", d)                               # ringan: tanpa modul berat

    def test_asumsi_persen_atau_desimal(self):
        _, a = self.get("/api/fairvalue?ticker=BRPT&ke=14&g=3&mos=30")
        _, b = self.get("/api/fairvalue?ticker=BRPT&ke=0.14&g=0.03&mos=0.30")
        fa, fb = a["data"]["fair_value"], b["data"]["fair_value"]
        self.assertAlmostEqual(fa["assumptions"]["ke"], 0.14)
        self.assertAlmostEqual(fa["assumptions"]["g"], 0.03)
        self.assertAlmostEqual(fa["assumptions"]["mos"], 0.30)
        self.assertAlmostEqual(fa["base"], fb["base"], places=6)
        _, base = self.get("/api/fairvalue?ticker=BRPT")
        self.assertLess(fa["base"], base["data"]["fair_value"]["base"])  # ke 14% > 12% bawaan

    def test_validasi_asumsi(self):
        for q in ("ke=2", "ke=40", "g=12", "g=-5", "mos=90", "ke=abc", "ke=10&g=9"):
            self.assertEqual(self.get(f"/api/fairvalue?ticker=BRPT&{q}")[0], 400, q)
        self.assertEqual(self.get("/api/fairvalue?ticker=")[0], 400)
        self.assertEqual(self.get("/api/fairvalue?ticker=ZZZZ")[0], 404)

    def test_analyze_menerima_asumsi_dan_membawa_harga_wajar(self):
        _, j = self.get("/api/analyze?ticker=BRPT&mode=fast&ke=15")
        self.assertAlmostEqual(j["data"]["fair_value"]["assumptions"]["ke"], 0.15)

    def test_bandingkan_memuat_selisih_harga_wajar(self):
        _, j = self.get("/api/compare?tickers=BRPT,BBCA")
        for row in j["results"]:
            self.assertIn("fair_gap_pct", row)
            self.assertIn("fair_label", row)


class SourcesApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sa._news_google = fake_news
        cls.c = api.app.test_client()

    def setUp(self):
        import data_sources as ds
        self.ds = ds
        api._LAST_DIAG[0] = 0.0
        os.environ.pop("SOURCES_TOKEN", None)

    def tearDown(self):
        os.environ.pop("SOURCES_TOKEN", None)
        self.ds.set_providers(None)

    def get(self, url):
        r = self.c.get(url)
        return r.status_code, r.get_json()

    def test_health_menampilkan_sumber_aktif_tanpa_kunci(self):
        code, j = self.get("/api/health")
        self.assertEqual(code, 200)
        self.assertIn("yahoo", j["sources"])
        self.assertNotIn("KEY", json.dumps(j).upper().replace("KEY_SET", ""))

    def test_diagnosis_sumber(self):
        code, j = self.get("/api/sources?ticker=BBCA")
        self.assertEqual(code, 200)
        self.assertEqual(j["data"]["ticker"], "BBCA.JK")
        names = {p["source"] for p in j["data"]["providers"]}
        self.assertTrue({"yahoo", "eodhd", "stooq"} <= names)
        yahoo = next(p for p in j["data"]["providers"] if p["source"] == "yahoo")
        self.assertEqual(yahoo["status"], "ok")

    def test_dibatasi_frekuensi(self):
        self.assertEqual(self.get("/api/sources?ticker=BBCA")[0], 200)
        code, j = self.get("/api/sources?ticker=BBCA")
        self.assertEqual(code, 429)
        self.assertIn("Terlalu sering", j["error"])

    def test_token_opsional(self):
        os.environ["SOURCES_TOKEN"] = "rahasia"
        self.assertEqual(self.get("/api/sources?ticker=BBCA")[0], 403)
        self.assertEqual(self.get("/api/sources?ticker=BBCA&token=salah")[0], 403)
        self.assertEqual(self.get("/api/sources?ticker=BBCA&token=rahasia")[0], 200)

    def test_validasi_input(self):
        self.assertEqual(self.get("/api/sources?ticker=")[0], 400)
        self.assertEqual(self.get("/api/sources?ticker=bad%20ticker!")[0], 400)

    def test_analisis_memuat_meta_sumber(self):
        code, j = self.get("/api/analyze?ticker=BRPT&mode=fast")
        meta = j["data"]["data_sources"]
        self.assertEqual((code, meta["history"]["primary"]), (200, "yahoo"))
        self.assertIn("providers_active", meta)


if __name__ == "__main__":
    unittest.main()
