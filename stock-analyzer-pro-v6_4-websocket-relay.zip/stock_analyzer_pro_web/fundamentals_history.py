"""fundamentals_history.py - Riwayat fundamental tahunan (FY) + TTM dari Yahoo Finance.

Diport dari Stock Screener V5.1 dan dirapikan:
- hanya FY yang dipakai untuk rata-rata / CAGR (TTM ditampilkan terpisah agar tidak tumpang tindih)
- tidak ada angka yang ditebak: data kosong tetap None
- tambahan: arus kas operasi (CFO) untuk menilai kualitas laba
"""
import logging
import math
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import yfinance as yf

import data_sources

LOG = logging.getLogger("stock_analyzer.history")

ROWS = {
    "revenue": ["Total Revenue", "Operating Revenue", "TotalRevenue"],
    "net_income": ["Net Income", "Net Income Common Stockholders", "NetIncome"],
    "assets": ["Total Assets", "TotalAssets"],
    "equity": ["Stockholders Equity", "Total Stockholder Equity", "Common Stock Equity",
               "Total Equity Gross Minority Interest", "Stockholders' Equity"],
    "debt": ["Total Debt", "TotalDebt"],
    "cfo": ["Operating Cash Flow", "Cash Flow From Continuing Operating Activities",
            "Total Cash From Operating Activities"],
    "fcf": ["Free Cash Flow", "FreeCashFlow"],
    "capex": ["Capital Expenditure", "Capital Expenditures", "Purchase Of PPE"],
    "eps": ["Diluted EPS", "Basic EPS", "Diluted Earnings Per Share", "Basic Earnings Per Share"],
    "avg_shares": ["Diluted Average Shares", "Basic Average Shares", "Weighted Average Shares"],
    "shares_outstanding": ["Ordinary Shares Number", "Share Issued", "Common Stock Shares Outstanding",
                          "Ordinary Shares Number Issue"] ,
}


def _num(v: Any) -> Optional[float]:
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def _row_value(df: Optional[pd.DataFrame], names: List[str], col: Any) -> Optional[float]:
    if df is None or getattr(df, "empty", True) or col not in df.columns:
        return None
    for name in names:
        if name in df.index:
            return _num(df.loc[name, col])
    wanted = {n.lower().replace(" ", "") for n in names}
    for idx in df.index:
        if str(idx).lower().replace(" ", "") in wanted:
            return _num(df.loc[idx, col])
    return None


def _ts(x: Any) -> pd.Timestamp:
    try:
        return pd.Timestamp(x)
    except Exception:
        return pd.Timestamp.min


def _safe_call(fn, *a, **kw):
    try:
        return fn(*a, **kw)
    except Exception as exc:
        LOG.debug("%s gagal: %s", getattr(fn, "__name__", fn), exc)
        return None


def _ratio(a: Optional[float], b: Optional[float]) -> Optional[float]:
    return a / b if a is not None and b not in (None, 0) else None


def _annual_rows(t: Any) -> List[Dict[str, Any]]:
    inc = _safe_call(t.get_income_stmt, freq="yearly")
    if inc is None or getattr(inc, "empty", True):
        inc = getattr(t, "income_stmt", None)
    bs = _safe_call(t.get_balance_sheet, freq="yearly")
    if bs is None or getattr(bs, "empty", True):
        bs = getattr(t, "balance_sheet", None)
    cf = _safe_call(t.get_cashflow, freq="yearly")
    if cf is None or getattr(cf, "empty", True):
        cf = getattr(t, "cashflow", None)

    cols: List[Any] = []
    for df in (inc, bs, cf):
        if df is not None and not getattr(df, "empty", True):
            for c in df.columns:
                if c not in cols:
                    cols.append(c)
    cols = sorted(cols, key=_ts, reverse=True)[:6]

    rows: List[Dict[str, Any]] = []
    for c in reversed(cols):
        revenue = _row_value(inc, ROWS["revenue"], c)
        ni = _row_value(inc, ROWS["net_income"], c)
        assets = _row_value(bs, ROWS["assets"], c)
        equity = _row_value(bs, ROWS["equity"], c)
        debt = _row_value(bs, ROWS["debt"], c)
        cfo = _row_value(cf, ROWS["cfo"], c)
        fcf = _row_value(cf, ROWS["fcf"], c)
        if fcf is None and cfo is not None:
            capex = _row_value(cf, ROWS["capex"], c)
            if capex is not None:
                fcf = cfo - abs(capex)          # capex di Yahoo bertanda negatif; abs() aman untuk dua konvensi
        eps = _row_value(inc, ROWS["eps"], c)
        avg_shares = _row_value(inc, ROWS["avg_shares"], c)
        shares_outstanding = _row_value(bs, ROWS["shares_outstanding"], c)
        if eps is None and ni is not None and avg_shares not in (None, 0):
            eps = ni / avg_shares
        if all(v is None for v in (revenue, ni, assets, equity)):
            continue
        rows.append({
            "year": str(_ts(c).year), "period": "FY", "date": str(_ts(c).date()),
            "revenue": revenue, "net_income": ni, "assets": assets, "equity": equity,
            "debt": debt, "cfo": cfo, "fcf": fcf, "eps": eps,
            "avg_shares": avg_shares, "shares_outstanding": shares_outstanding,
            "roe": _ratio(ni, equity), "roa": _ratio(ni, assets),
            "npm": _ratio(ni, revenue), "de": _ratio(debt, equity),
            "cfo_ni": _ratio(cfo, ni) if ni is not None and ni > 0 else None,
        })
    rows = rows[-5:]
    for i, row in enumerate(rows):
        prev = rows[i - 1] if i else None
        row["revenue_growth"] = (_ratio(row["revenue"], prev["revenue"]) - 1
                                 if prev and _ratio(row["revenue"], prev["revenue"]) is not None else None)
        row["earnings_growth"] = (_ratio(row["net_income"], prev["net_income"]) - 1
                                  if prev and prev["net_income"] and prev["net_income"] > 0
                                  and row["net_income"] is not None else None)
    return rows


def _ttm_row(t: Any, fy: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    ttm = getattr(t, "ttm_income_stmt", None)
    if ttm is None or getattr(ttm, "empty", True):
        return None
    col = ttm.columns[0]
    revenue = _row_value(ttm, ROWS["revenue"], col)
    ni = _row_value(ttm, ROWS["net_income"], col)
    if revenue is None and ni is None:
        return None
    last = fy[-1] if fy else None
    year = str(datetime.now().year)
    if last and last["year"] == year:
        return None
    equity = last["equity"] if last else None
    assets = last["assets"] if last else None
    return {
        "year": year, "period": "TTM", "date": str(_ts(col).date()),
        "revenue": revenue, "net_income": ni, "assets": assets, "equity": equity,
        "debt": last["debt"] if last else None, "cfo": None,
        "roe": _ratio(ni, equity), "roa": _ratio(ni, assets), "npm": _ratio(ni, revenue),
        "de": last["de"] if last else None, "cfo_ni": None,
        "revenue_growth": (_ratio(revenue, last["revenue"]) - 1
                           if last and _ratio(revenue, last["revenue"]) is not None else None),
        "earnings_growth": (_ratio(ni, last["net_income"]) - 1
                            if last and last["net_income"] and last["net_income"] > 0
                            and ni is not None else None),
    }


def _valuation_measures(t: Any) -> Dict[str, Dict[str, Optional[float]]]:
    """Best-effort PER/PBV historis dari yfinance (tidak selalu tersedia)."""
    out: Dict[str, Dict[str, Optional[float]]] = {}
    if not hasattr(t, "get_valuation_measures"):
        return out
    df = _safe_call(t.get_valuation_measures, freq="yearly", periods=5)
    if df is None or getattr(df, "empty", True):
        return out
    aliases = {"per": ["p/e ratio", "pe ratio", "trailing p/e", "trailing pe"],
               "pbv": ["price/book", "price to book", "p/b ratio", "price/book value"]}

    def find(names: List[str]) -> Any:
        for idx in df.index:
            if str(idx).strip().lower() in names:
                return idx
        for idx in df.index:
            if any(n in str(idx).strip().lower() for n in names):
                return idx
        return None

    rows = {k: find(v) for k, v in aliases.items()}
    for col in df.columns:
        if str(col).lower() == "current":
            continue
        dt = pd.to_datetime(col, errors="coerce")
        if pd.isna(dt):
            continue
        out[str(dt.year)] = {k: (_num(df.loc[r, col]) if r is not None else None) for k, r in rows.items()}
    return out


def _year_end_price(close: pd.Series, year: str, latest: bool) -> Optional[float]:
    s = close.dropna()
    if s.empty:
        return None
    if latest:
        return _num(s.iloc[-1])
    part = s[s.index.year == int(year)]
    return _num(part.iloc[-1]) if not part.empty else None


def _avg(rows: List[Dict[str, Any]], key: str) -> Tuple[Optional[float], int]:
    vals = [r[key] for r in rows if r.get(key) is not None]
    return (float(np.mean(vals)), len(vals)) if vals else (None, 0)


def _cagr(rows: List[Dict[str, Any]], key: str) -> Optional[float]:
    pts = [(int(r["year"]), r[key]) for r in rows if r.get(key) is not None]
    if len(pts) < 3:
        return None
    (y0, v0), (y1, v1) = pts[0], pts[-1]
    n = y1 - y0
    if n <= 0 or v0 <= 0 or v1 <= 0:
        return None
    return float((v1 / v0) ** (1 / n) - 1)


def summarize(rows: List[Dict[str, Any]], valuation: Dict[str, Dict[str, Optional[float]]]) -> Dict[str, Any]:
    fy = [r for r in rows if r["period"] == "FY"]
    s: Dict[str, Any] = {"periods": len(fy)}
    for key in ("roe", "roa", "npm", "revenue_growth", "earnings_growth", "de", "cfo_ni"):
        v, n = _avg(fy, key)
        s[key + "_avg"], s[key + "_n"] = v, n
    with_ni = [r for r in fy if r["net_income"] is not None]
    s["profit_years"] = sum(1 for r in with_ni if r["net_income"] > 0)
    s["profit_years_total"] = len(with_ni)
    s["profit_years_fraction"] = (s["profit_years"] / len(with_ni)) if with_ni else None
    s["net_income_cagr"] = _cagr(fy, "net_income")
    s["revenue_cagr"] = _cagr(fy, "revenue")
    roes = [r["roe"] for r in fy if r["roe"] is not None]
    s["roe_std"] = float(np.std(roes)) if len(roes) >= 3 else None
    for k in ("per", "pbv"):
        vals = [v[k] for v in valuation.values() if v.get(k) is not None and v[k] > 0]
        s[k + "_avg"] = float(np.mean(vals)) if vals else None
        s[k + "_n"] = len(vals)
    return s


def build_history(ticker: str, close: pd.Series, cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Kembalikan {'available', 'rows', 'summary', 'valuation', 'reason'}. Tidak pernah melempar."""
    try:
        t = yf.Ticker(ticker)
        fy = _annual_rows(t)
        source = "yahoo"
        if not fy:
            alt = data_sources.statements_fallback(ticker)       # cadangan bila Yahoo kosong
            if alt is not None:
                fy_alt = _annual_rows(alt)
                if fy_alt:
                    fy, t, source = fy_alt, alt, alt.source
        if not fy:
            return {"available": False, "reason": "laporan keuangan tahunan tidak tersedia dari sumber",
                    "rows": [], "summary": {"periods": 0}, "valuation": {}}
        ttm = _safe_call(_ttm_row, t, fy)
        rows = fy + ([ttm] if ttm else [])
        valuation = _valuation_measures(t)
        for row in rows:
            row["year_end_price"] = _year_end_price(close, row["year"], row["period"] == "TTM")
            v = valuation.setdefault(row["year"], {})
            per, pbv = v.get("per"), v.get("pbv")
            # Fallback transparan: hitung dari harga akhir tahun dan data laporan
            # keuangan tahun yang sama, hanya jika multiple dari provider tidak tersedia.
            px = row.get("year_end_price")
            eps = row.get("eps")
            if per is None and px is not None and eps is not None and eps > 0:
                candidate = px / eps
                if math.isfinite(candidate) and 0 < candidate <= 200:
                    per = candidate
            equity = row.get("equity")
            shares = row.get("shares_outstanding")
            if pbv is None and px is not None and equity is not None and equity > 0 and shares not in (None, 0):
                book_per_share = equity / shares
                candidate = px / book_per_share if book_per_share > 0 else None
                if candidate is not None and math.isfinite(candidate) and 0 < candidate <= 50:
                    pbv = candidate
            row["historical_per"], row["historical_pbv"] = per, pbv
            # Simpan fallback hasil per periode supaya ringkasan dapat menggunakannya.
            v["per"] = per if per is not None else v.get("per")
            v["pbv"] = pbv if pbv is not None else v.get("pbv")
        return {"available": True, "rows": rows, "summary": summarize(rows, valuation),
                "valuation": valuation, "reason": None, "source": source}
    except Exception as exc:
        LOG.warning("Riwayat fundamental gagal untuk %s: %s", ticker, exc)
        return {"available": False, "reason": str(exc), "rows": [], "summary": {"periods": 0}, "valuation": {}}
