"""data_sources.py - Lapisan data multi-sumber: failover, validasi silang, dan pengisian celah.

Urutan prioritas bawaan: yahoo, eodhd, twelvedata, alphavantage, stooq
  yahoo        tanpa kunci (yfinance)
  eodhd        EODHD_API_KEY        harga EOD + harga terakhir + ringkasan fundamental (simbol BEI: .JK)
  twelvedata   TWELVEDATA_API_KEY   harga + harga terakhir (cakupan bursa tergantung paket)
  alphavantage ALPHAVANTAGE_API_KEY harga harian, harga terakhir, ringkasan fundamental, laporan keuangan
  stooq        tanpa kunci          harga harian CSV (terutama bursa AS/Eropa)

Perilaku:
- HARGA: sumber utama = yang pertama berhasil. Jika gagal/kosong/terlalu pendek, pindah ke sumber berikutnya (failover).
  Mode validasi membandingkan sumber utama dengan sumber lain (harga terakhir dan return harian);
  jika sumber utama menjadi pencilan dari dua sumber lain yang saling sepakat, sumber utama diganti.
- FUNDAMENTAL: Yahoo sebagai dasar; celah diisi dari sumber lain; selisih besar dicatat sebagai konflik
  (nilai sumber utama TIDAK ditimpa diam-diam).
- LAPORAN KEUANGAN: Yahoo; bila kosong, cadangan Alpha Vantage lewat adaptor.

PENTING: format respons selain Yahoo ditulis dari dokumentasi publik dan BELUM diuji ke server asli.
Cakupan bursa (terutama BEI) dan batas paket gratis dapat berbeda dari dugaan; gunakan diagnose() / GET /api/sources.
Kunci API hanya dibaca dari environment, tidak pernah dicatat di log atau dikirim ke klien.
"""
import json
import logging
import math
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from io import StringIO
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote_plus
from urllib.request import Request, urlopen

import numpy as np
import pandas as pd
import yfinance as yf

LOG = logging.getLogger("stock_analyzer.sources")

TRADING_DAYS = 252
DEFAULT_ORDER = "yahoo,eodhd,twelvedata,alphavantage,stooq"
# ambang validasi silang (persen)
LAST_CLOSE_WARN, LAST_CLOSE_BAD = 2.0, 10.0
RET_WARN, RET_BAD = 7.0, 20.0           # selisih return harian maksimum; ex-dividen/split bisa wajar
LIVE_WARN, LIVE_BAD = 3.0, 10.0
RECENT_DAYS = 130                        # jendela data untuk validator (hemat kuota)

_lock = threading.Lock()
_CACHE: Dict[Tuple[Any, ...], Tuple[float, Any]] = {}
_NEG: Dict[Tuple[Any, ...], Tuple[float, str]] = {}


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def settings() -> Dict[str, Any]:
    return {
        "http_timeout": _env_float("DATA_HTTP_TIMEOUT", 8.0),
        "validate_max": int(_env_float("DATA_VALIDATE_MAX", 2)),
        "validate_ttl": _env_float("DATA_VALIDATE_TTL", 21600.0),
        "neg_ttl": _env_float("DATA_NEGATIVE_TTL", 120.0),
    }


# ------------------------------------------------------------------ HTTP ---
def _mask(text: str) -> str:
    """Hapus kunci API dari URL/pesan sebelum dicatat atau ditampilkan."""
    return re.sub(r"(?i)(apikey|api_token|apiKey|token|key)=[^&\s]+", r"\1=***", str(text))


def http_get(url: str, timeout: Optional[float] = None, max_bytes: int = 20_000_000) -> bytes:
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 (stock_analyzer)"})
    with urlopen(req, timeout=timeout or settings()["http_timeout"]) as resp:
        data = resp.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise ValueError("respons terlalu besar")
    return data


def _get_text(url: str) -> str:
    try:
        return http_get(url).decode("utf-8", errors="replace")
    except HTTPError as exc:
        raise RuntimeError(f"HTTP {exc.code}") from None
    except (URLError, OSError, ValueError) as exc:
        raise RuntimeError(_mask(f"koneksi gagal: {exc}")) from None


def _get_json(url: str) -> Any:
    text = _get_text(url)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        raise RuntimeError("respons bukan JSON") from None


def _num(v: Any) -> Optional[float]:
    try:
        if isinstance(v, str) and v.strip().lower() in ("", "none", "-", "n/a", "na", "null", "nan"):
            return None
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def _frame(rows: List[Dict[str, Any]], years: float, recent: bool) -> pd.DataFrame:
    """rows: dict dengan date/open/high/low/close/volume -> DataFrame OHLCV indeks tanggal naif."""
    df = pd.DataFrame(rows)
    if df.empty or "date" not in df or "close" not in df:
        return pd.DataFrame()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in ("open", "high", "low", "close", "volume"):
        df[c] = pd.to_numeric(df.get(c), errors="coerce")
    df = df.dropna(subset=["date", "close"]).set_index("date").sort_index()
    df = df[~df.index.duplicated(keep="last")]
    for c in ("open", "high", "low"):
        df[c] = df[c].fillna(df["close"])
    df["volume"] = df["volume"].fillna(0.0)
    out = df[["open", "high", "low", "close", "volume"]]
    out.columns = ["Open", "High", "Low", "Close", "Volume"]
    if recent:
        return out.tail(RECENT_DAYS)
    cutoff = out.index[-1] - pd.DateOffset(years=int(math.ceil(years)))
    return out[out.index >= cutoff]


# ------------------------------------------------------------- penyedia ---
class Provider:
    name = "base"
    key_env: Optional[str] = None
    offers = {"history": True, "quote": False, "overview": False, "statements": False}

    def key(self) -> Optional[str]:
        return os.environ.get(self.key_env) if self.key_env else None

    def configured(self) -> bool:
        return self.key_env is None or bool(self.key())

    def map_symbol(self, ticker: str) -> Optional[str]:
        override = _symbol_overrides().get(self.name, {}).get(ticker.upper())
        return override if override else self._default_symbol(ticker)

    def _default_symbol(self, ticker: str) -> Optional[str]:
        return ticker

    def supports(self, ticker: str) -> bool:
        return self.configured() and self.map_symbol(ticker) is not None

    def history(self, ticker: str, years: float, recent: bool = False) -> pd.DataFrame:
        raise NotImplementedError

    def quote(self, ticker: str) -> Optional[float]:
        return None

    def overview(self, ticker: str) -> Dict[str, Any]:
        return {}


def _symbol_overrides() -> Dict[str, Dict[str, str]]:
    """DATA_SYMBOL_MAP='{"stooq":{"BBCA.JK":"bbca.id"},"twelvedata":{"BBCA.JK":"BBCA:IDX"}}'"""
    raw = os.environ.get("DATA_SYMBOL_MAP")
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return {str(k).lower(): {str(a).upper(): str(b) for a, b in v.items()} for k, v in data.items()
                if isinstance(v, dict)}
    except (json.JSONDecodeError, AttributeError):
        LOG.warning("DATA_SYMBOL_MAP tidak valid; diabaikan")
        return {}


class YahooProvider(Provider):
    name = "yahoo"
    offers = {"history": True, "quote": True, "overview": True, "statements": True}

    def history(self, ticker: str, years: float, recent: bool = False) -> pd.DataFrame:
        period = "6mo" if recent else f"{int(math.ceil(years))}y"
        df = yf.Ticker(ticker).history(period=period, auto_adjust=True)
        return df if df is not None else pd.DataFrame()

    def quote(self, ticker: str) -> Optional[float]:
        try:
            return _num(yf.Ticker(ticker).fast_info["last_price"])
        except Exception as exc:
            LOG.debug("fast_info gagal: %s", exc)
            return None

    def overview(self, ticker: str) -> Dict[str, Any]:
        return yf.Ticker(ticker).info or {}


class StooqProvider(Provider):
    name = "stooq"

    def _default_symbol(self, ticker: str) -> Optional[str]:
        t = ticker.lower()
        if t.startswith("^"):
            return None
        if "." not in t:
            return t + ".us"
        if t.endswith(".l"):
            return t[:-2] + ".uk"
        return None                       # bursa lain (termasuk BEI) tidak diketahui tercakup; pakai DATA_SYMBOL_MAP

    @staticmethod
    def parse_csv(text: str, years: float, recent: bool) -> pd.DataFrame:
        if "date" not in text[:200].lower():
            raise RuntimeError("tidak ada data")
        raw = pd.read_csv(StringIO(text))
        raw.columns = [str(c).strip().lower() for c in raw.columns]
        if "volume" not in raw:
            raw["volume"] = 0.0
        return _frame(raw.to_dict("records"), years, recent)

    def history(self, ticker: str, years: float, recent: bool = False) -> pd.DataFrame:
        sym = self.map_symbol(ticker)
        return self.parse_csv(_get_text(f"https://stooq.com/q/d/l/?s={quote_plus(sym)}&i=d"), years, recent)


class AlphaVantageProvider(Provider):
    name = "alphavantage"
    key_env = "ALPHAVANTAGE_API_KEY"
    offers = {"history": True, "quote": True, "overview": True, "statements": True}
    BASE = "https://www.alphavantage.co/query"

    def _default_symbol(self, ticker: str) -> Optional[str]:
        t = ticker.upper()
        if t.startswith("^"):
            return None
        if "." not in t:
            return t
        if t.endswith(".L"):
            return t[:-2] + ".LON"
        return None

    @staticmethod
    def check(payload: Any) -> Dict[str, Any]:
        if not isinstance(payload, dict):
            raise RuntimeError("format respons tidak dikenal")
        for k in ("Error Message", "Note", "Information"):
            if payload.get(k):
                raise RuntimeError(f"{k}: {str(payload[k])[:120]}")
        return payload

    @staticmethod
    def parse_daily(payload: Dict[str, Any], years: float, recent: bool) -> pd.DataFrame:
        series = payload.get("Time Series (Daily)")
        if not isinstance(series, dict) or not series:
            raise RuntimeError("tidak ada data")
        rows = [{"date": d, "open": v.get("1. open"), "high": v.get("2. high"), "low": v.get("3. low"),
                 "close": v.get("4. close"), "volume": v.get("5. volume")} for d, v in series.items()]
        return _frame(rows, years, recent)

    def _q(self, **params: Any) -> Dict[str, Any]:
        qs = "&".join(f"{k}={quote_plus(str(v))}" for k, v in params.items())
        return self.check(_get_json(f"{self.BASE}?{qs}&apikey={self.key()}"))

    def history(self, ticker: str, years: float, recent: bool = False) -> pd.DataFrame:
        size = "compact" if recent else "full"
        return self.parse_daily(self._q(function="TIME_SERIES_DAILY", symbol=self.map_symbol(ticker), outputsize=size),
                                years, recent)

    def quote(self, ticker: str) -> Optional[float]:
        p = self._q(function="GLOBAL_QUOTE", symbol=self.map_symbol(ticker))
        return _num((p.get("Global Quote") or {}).get("05. price"))

    @staticmethod
    def normalize_overview(p: Dict[str, Any]) -> Dict[str, Any]:
        if not p.get("Symbol"):
            raise RuntimeError("tidak ada data ringkasan")
        out = {
            "trailingEps": _num(p.get("EPS")), "bookValue": _num(p.get("BookValue")),
            "trailingPE": _num(p.get("PERatio")), "priceToBook": _num(p.get("PriceToBookRatio")),
            "trailingAnnualDividendRate": _num(p.get("DividendPerShare")),
            "trailingAnnualDividendYield": _num(p.get("DividendYield")),
            "returnOnEquity": _num(p.get("ReturnOnEquityTTM")), "returnOnAssets": _num(p.get("ReturnOnAssetsTTM")),
            "profitMargins": _num(p.get("ProfitMargin")), "sharesOutstanding": _num(p.get("SharesOutstanding")),
            "marketCap": _num(p.get("MarketCapitalization")), "payoutRatio": _num(p.get("PayoutRatio")),
            "currency": p.get("Currency") or None, "sector": (p.get("Sector") or "").title() or None,
            "industry": (p.get("Industry") or "").title() or None, "longName": p.get("Name") or None,
        }
        return {k: v for k, v in out.items() if v is not None}

    def overview(self, ticker: str) -> Dict[str, Any]:
        return self.normalize_overview(self._q(function="OVERVIEW", symbol=self.map_symbol(ticker)))

    @staticmethod
    def statements_adapter(inc: Dict[str, Any], bs: Dict[str, Any], cf: Dict[str, Any]) -> "StatementsAdapter":
        """Ubah laporan tahunan Alpha Vantage menjadi DataFrame bergaya yfinance (baris = nama akun)."""
        def table(payload: Dict[str, Any], mapping: Dict[str, List[str]]) -> pd.DataFrame:
            reports = payload.get("annualReports") or []
            cols: Dict[pd.Timestamp, Dict[str, float]] = {}
            for r in reports:
                try:
                    c = pd.Timestamp(r["fiscalDateEnding"])
                except (KeyError, ValueError, TypeError):
                    continue
                vals: Dict[str, float] = {}
                for label, keys in mapping.items():
                    parts = [_num(r.get(k)) for k in keys]
                    parts = [x for x in parts if x is not None]
                    if parts:
                        vals[label] = float(sum(parts))
                cols[c] = vals
            return pd.DataFrame(cols) if cols else pd.DataFrame()
        return StatementsAdapter(
            table(inc, {"Total Revenue": ["totalRevenue"], "Net Income": ["netIncome"]}),
            table(bs, {"Total Assets": ["totalAssets"], "Stockholders Equity": ["totalShareholderEquity"],
                       "Total Debt": ["shortLongTermDebtTotal"],
                       "Ordinary Shares Number": ["commonStockSharesOutstanding"]}),
            table(cf, {"Operating Cash Flow": ["operatingCashflow"],
                       "Capital Expenditure": ["capitalExpenditures"]}))

    def statements(self, ticker: str) -> "StatementsAdapter":
        sym = self.map_symbol(ticker)
        parts = [self._q(function=fn, symbol=sym) for fn in ("INCOME_STATEMENT", "BALANCE_SHEET", "CASH_FLOW")]
        ad = self.statements_adapter(*parts)
        if ad.get_income_stmt().empty:
            raise RuntimeError("laporan keuangan kosong")
        return ad


class StatementsAdapter:
    """Meniru bagian objek yfinance.Ticker yang dipakai fundamentals_history."""
    source = "alphavantage"

    def __init__(self, inc: pd.DataFrame, bs: pd.DataFrame, cf: pd.DataFrame):
        self._inc, self._bs, self._cf = inc, bs, cf
        self.ttm_income_stmt = None

    def get_income_stmt(self, freq: str = "yearly") -> pd.DataFrame:
        return self._inc

    def get_balance_sheet(self, freq: str = "yearly") -> pd.DataFrame:
        return self._bs

    def get_cashflow(self, freq: str = "yearly") -> pd.DataFrame:
        return self._cf


class EodhdProvider(Provider):
    name = "eodhd"
    key_env = "EODHD_API_KEY"
    offers = {"history": True, "quote": True, "overview": True, "statements": False}
    BASE = "https://eodhd.com/api"

    def _default_symbol(self, ticker: str) -> Optional[str]:
        t = ticker.upper()
        if t.startswith("^"):
            return None
        if t.endswith(".JK"):
            return t                      # kode bursa BEI di EODHD: JK
        if "." not in t:
            return t + ".US"
        return None

    @staticmethod
    def parse_eod(payload: Any, years: float, recent: bool) -> pd.DataFrame:
        if not isinstance(payload, list) or not payload:
            raise RuntimeError("tidak ada data")
        rows = []
        for r in payload:
            close, adj = _num(r.get("close")), _num(r.get("adjusted_close"))
            f = (adj / close) if close and adj else 1.0       # selaraskan dengan harga yang disesuaikan (seperti Yahoo)
            rows.append({"date": r.get("date"), "open": (_num(r.get("open")) or close or 0) * f,
                         "high": (_num(r.get("high")) or close or 0) * f, "low": (_num(r.get("low")) or close or 0) * f,
                         "close": adj if adj else close, "volume": r.get("volume")})
        return _frame(rows, years, recent)

    def history(self, ticker: str, years: float, recent: bool = False) -> pd.DataFrame:
        start = (datetime.now() - timedelta(days=200 if recent else int(365.25 * math.ceil(years)) + 10)).strftime("%Y-%m-%d")
        url = f"{self.BASE}/eod/{self.map_symbol(ticker)}?api_token={self.key()}&fmt=json&period=d&from={start}"
        return self.parse_eod(_get_json(url), years, recent)

    def quote(self, ticker: str) -> Optional[float]:
        p = _get_json(f"{self.BASE}/real-time/{self.map_symbol(ticker)}?api_token={self.key()}&fmt=json")
        return _num(p.get("close")) if isinstance(p, dict) else None

    @staticmethod
    def normalize_highlights(h: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(h, dict) or not h:
            raise RuntimeError("tidak ada data ringkasan")
        out = {"trailingEps": _num(h.get("EarningsShare")), "bookValue": _num(h.get("BookValue")),
               "trailingPE": _num(h.get("PERatio")), "trailingAnnualDividendRate": _num(h.get("DividendShare")),
               "trailingAnnualDividendYield": _num(h.get("DividendYield")),
               "returnOnEquity": _num(h.get("ReturnOnEquityTTM")), "returnOnAssets": _num(h.get("ReturnOnAssetsTTM")),
               "profitMargins": _num(h.get("ProfitMargin")), "marketCap": _num(h.get("MarketCapitalization"))}
        return {k: v for k, v in out.items() if v is not None}

    def overview(self, ticker: str) -> Dict[str, Any]:
        p = _get_json(f"{self.BASE}/fundamentals/{self.map_symbol(ticker)}?api_token={self.key()}&filter=Highlights")
        return self.normalize_highlights(p)


class TwelveDataProvider(Provider):
    name = "twelvedata"
    key_env = "TWELVEDATA_API_KEY"
    offers = {"history": True, "quote": True, "overview": False, "statements": False}
    BASE = "https://api.twelvedata.com"

    def _default_symbol(self, ticker: str) -> Optional[str]:
        t = ticker.upper()
        if t.startswith("^"):
            return None
        if t.endswith(".JK"):
            return t[:-3] + ":IDX"        # symbol:exchange
        if "." not in t:
            return t
        return None

    def _params(self, ticker: str) -> str:
        sym = self.map_symbol(ticker)
        if ":" in sym:
            s, ex = sym.split(":", 1)
            return f"symbol={quote_plus(s)}&exchange={quote_plus(ex)}"
        return f"symbol={quote_plus(sym)}"

    @staticmethod
    def parse_series(payload: Any, years: float, recent: bool) -> pd.DataFrame:
        if not isinstance(payload, dict):
            raise RuntimeError("format respons tidak dikenal")
        if payload.get("status") == "error" or payload.get("code"):
            raise RuntimeError(str(payload.get("message") or "error")[:120])
        vals = payload.get("values")
        if not vals:
            raise RuntimeError("tidak ada data")
        rows = [{"date": v.get("datetime"), "open": v.get("open"), "high": v.get("high"), "low": v.get("low"),
                 "close": v.get("close"), "volume": v.get("volume")} for v in vals]
        return _frame(rows, years, recent)

    def history(self, ticker: str, years: float, recent: bool = False) -> pd.DataFrame:
        n = RECENT_DAYS if recent else min(5000, int(years * 260) + 20)
        url = f"{self.BASE}/time_series?{self._params(ticker)}&interval=1day&outputsize={n}&order=ASC&apikey={self.key()}"
        return self.parse_series(_get_json(url), years, recent)

    def quote(self, ticker: str) -> Optional[float]:
        p = _get_json(f"{self.BASE}/price?{self._params(ticker)}&apikey={self.key()}")
        if isinstance(p, dict) and p.get("status") == "error":
            raise RuntimeError(str(p.get("message"))[:120])
        return _num(p.get("price")) if isinstance(p, dict) else None


def build_providers() -> List[Provider]:
    registry = {c.name: c for c in (YahooProvider, EodhdProvider, TwelveDataProvider, AlphaVantageProvider, StooqProvider)}
    order = [n.strip().lower() for n in os.environ.get("DATA_SOURCES", DEFAULT_ORDER).split(",") if n.strip()]
    primary = os.environ.get("DATA_PRIMARY", "").strip().lower()
    if primary in order:
        order.remove(primary)
        order.insert(0, primary)
    seen, out = set(), []
    for n in order:
        if n in registry and n not in seen:
            seen.add(n)
            out.append(registry[n]())
    return out or [YahooProvider()]


_PROVIDERS: List[Provider] = build_providers()


def set_providers(providers: Optional[List[Provider]]) -> None:
    """Untuk uji/konfigurasi runtime. None = bangun ulang dari environment."""
    global _PROVIDERS
    with _lock:
        _PROVIDERS = providers if providers is not None else build_providers()
        _CACHE.clear()
        _NEG.clear()


def providers() -> List[Provider]:
    return list(_PROVIDERS)


def active_providers(ticker: Optional[str] = None) -> List[Provider]:
    return [p for p in _PROVIDERS if p.configured() and (ticker is None or p.supports(ticker))]


# ------------------------------------------------------------- cache kecil ---
def _cached(key: Tuple[Any, ...], ttl: float, fn: Callable[[], Any]) -> Any:
    now = time.time()
    with _lock:
        hit = _CACHE.get(key)
    if hit and now - hit[0] < ttl:
        return hit[1]
    val = fn()
    with _lock:
        _CACHE[key] = (now, val)
    return val


# ------------------------------------------------------------- harga ---
def _norm_close(df: pd.DataFrame) -> pd.Series:
    s = df["Close"].dropna()
    idx = pd.DatetimeIndex(s.index)
    if idx.tz is not None:
        idx = idx.tz_localize(None)
    s = pd.Series(s.to_numpy(dtype=float), index=idx.normalize())
    return s[~s.index.duplicated(keep="last")].sort_index()


def compare_series(a: pd.Series, b: pd.Series) -> Dict[str, Any]:
    """Bandingkan dua deret penutupan pada tanggal yang sama (maksimum 90 sesi terakhir milik a)."""
    common = a.index[-90:].intersection(b.index)
    if len(common) < 20:
        return {"status": "tidak_cukup", "common_days": int(len(common)), "last_close_diff_pct": None,
                "max_return_diff_pct": None, "note": "tanggal yang sama kurang dari 20 hari"}
    x, y = a.loc[common], b.loc[common]
    last = abs(float(x.iloc[-1]) / float(y.iloc[-1]) - 1) * 100 if y.iloc[-1] else None
    rx, ry = x.pct_change().dropna(), y.pct_change().dropna()
    diff = (rx - ry).abs() * 100
    mx = float(diff.max()) if len(diff) else 0.0
    status = "ok"
    note = "harga terakhir dan return harian sepakat"
    if (last is not None and last > LAST_CLOSE_BAD) or mx > RET_BAD:
        status, note = "bad", "selisih besar: salah satu sumber kemungkinan keliru (split, data basi, atau simbol berbeda)"
    elif (last is not None and last > LAST_CLOSE_WARN) or mx > RET_WARN:
        status, note = "warn", "ada selisih; ex-dividen/split pada tanggal tertentu bisa menjelaskannya"
    return {"status": status, "common_days": int(len(common)),
            "last_close_diff_pct": float(last) if last is not None else None,
            "max_return_diff_pct": mx, "note": note}


def _fetch_recent(p: Provider, ticker: str) -> Tuple[str, Optional[pd.Series], Optional[str]]:
    ttl = settings()["validate_ttl"]
    key = ("recent", p.name, ticker)
    try:
        df = _cached(key, ttl, lambda: p.history(ticker, 1.0, recent=True))
        if df is None or df.empty:
            return p.name, None, "kosong"
        return p.name, _norm_close(df), None
    except Exception as exc:
        return p.name, None, _mask(str(exc))[:140]


def get_history(ticker: str, years: float, min_rows: int = 30, validate: bool = False) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """Kembalikan (DataFrame OHLCV, meta). Melempar RuntimeError bila semua sumber gagal."""
    cfg = settings()
    neg = _NEG.get(("hist", ticker, int(math.ceil(years))))
    if neg and time.time() - neg[0] < cfg["neg_ttl"]:
        raise RuntimeError(neg[1])

    attempts: List[Dict[str, Any]] = []
    chosen: Optional[Provider] = None
    df_ok: Optional[pd.DataFrame] = None
    best_short = 0
    for p in _PROVIDERS:
        if not p.supports(ticker):
            continue
        try:
            df = p.history(ticker, years)
            df = df.dropna(subset=["Close"]) if df is not None and not df.empty else pd.DataFrame()
            if df.empty:
                attempts.append({"source": p.name, "ok": False, "reason": "kosong"})
                continue
            if len(df) < min_rows:
                best_short = max(best_short, len(df))
                attempts.append({"source": p.name, "ok": False, "reason": f"hanya {len(df)} hari"})
                continue
            attempts.append({"source": p.name, "ok": True, "rows": int(len(df))})
            chosen, df_ok = p, df
            break
        except Exception as exc:
            attempts.append({"source": p.name, "ok": False, "reason": _mask(str(exc))[:140]})
            LOG.info("Sumber %s gagal untuk %s: %s", p.name, ticker, _mask(str(exc)))

    if chosen is None or df_ok is None:
        msg = (f"Data '{ticker}' hanya {best_short} hari; minimal {min_rows} hari untuk analisis dasar."
               if best_short else f"Tidak ada data untuk '{ticker}'. Cek kode saham / koneksi.")
        with _lock:
            _NEG[("hist", ticker, int(math.ceil(years)))] = (time.time(), msg)
        raise RuntimeError(msg)

    meta: Dict[str, Any] = {"primary": chosen.name, "rows": int(len(df_ok)), "attempts": attempts,
                            "failover": [a for a in attempts if not a["ok"]], "validators": [], "switched": None,
                            "validated": False}
    if validate:
        _validate_history(ticker, chosen, df_ok, meta, cfg)
        if meta["switched"]:
            new = next(p for p in _PROVIDERS if p.name == meta["switched"]["to"])
            try:
                alt = new.history(ticker, years)
                alt = alt.dropna(subset=["Close"]) if alt is not None and not alt.empty else pd.DataFrame()
                if len(alt) >= min_rows:
                    meta["primary"], meta["rows"] = new.name, int(len(alt))
                    return alt, meta
            except Exception as exc:
                LOG.info("Gagal berpindah ke %s: %s", new.name, _mask(str(exc)))
            meta["switched"] = None
    return df_ok, meta


def _validate_history(ticker: str, primary: Provider, df: pd.DataFrame, meta: Dict[str, Any], cfg: Dict[str, Any]) -> None:
    others = [p for p in _PROVIDERS if p is not primary and p.supports(ticker) and p.offers.get("history")]
    others = others[: max(0, cfg["validate_max"])]
    if not others:
        meta["validated"] = False
        return
    base = _norm_close(df)
    with ThreadPoolExecutor(max_workers=len(others)) as pool:
        results = list(pool.map(lambda p: _fetch_recent(p, ticker), others))
    series: Dict[str, pd.Series] = {}
    for name, s, err in results:
        if s is None:
            meta["validators"].append({"source": name, "status": "gagal", "note": err or "tidak ada data",
                                       "common_days": 0, "last_close_diff_pct": None, "max_return_diff_pct": None})
            continue
        series[name] = s
        cmp_ = compare_series(base, s)
        meta["validators"].append({"source": name, **cmp_})
    meta["validated"] = any(v["status"] in ("ok", "warn", "bad") for v in meta["validators"])

    # primary = pencilan dari dua sumber lain yang saling sepakat -> ganti
    bad = [v for v in meta["validators"] if v["status"] == "bad"]
    if len(bad) >= 2:
        names = [v["source"] for v in bad]
        pair = compare_series(series[names[0]], series[names[1]])
        if pair["status"] == "ok":
            meta["switched"] = {"from": primary.name, "to": names[0],
                                "reason": f"{primary.name} berbeda jauh dari {names[0]} dan {names[1]}, yang saling sepakat"}


def get_live_price(ticker: str, fallback: float, validate: bool = False) -> Tuple[float, str, Dict[str, Any]]:
    """Harga terbaru. Sumber pertama yang berhasil; validasi membandingkan dengan sumber lain."""
    cfg = settings()
    quotes: Dict[str, float] = {}
    errors: Dict[str, str] = {}
    price: Optional[float] = None
    source = "close_terakhir"
    for p in _PROVIDERS:
        if not (p.supports(ticker) and p.offers.get("quote")):
            continue
        try:
            q = p.quote(ticker)
        except Exception as exc:
            errors[p.name] = _mask(str(exc))[:100]
            continue
        if q is not None and q > 0:
            quotes[p.name] = float(q)
            price, source = float(q), ("fast_info" if p.name == "yahoo" else p.name)
            break
        errors[p.name] = "kosong"
    meta: Dict[str, Any] = {"quotes": dict(quotes), "errors": errors, "max_dev_pct": None, "status": "tunggal"}
    if price is None:
        return float(fallback), "close_terakhir", meta
    if validate:
        primary_name = next(iter(quotes))
        others = [p for p in _PROVIDERS if p.name != primary_name and p.supports(ticker) and p.offers.get("quote")]
        for p in others[: max(0, cfg["validate_max"])]:
            try:
                q = _cached(("quote", p.name, ticker), 300.0, lambda p=p: p.quote(ticker))
                if q is not None and q > 0:
                    quotes[p.name] = float(q)
                else:
                    errors[p.name] = "kosong"
            except Exception as exc:
                errors[p.name] = _mask(str(exc))[:100]
        meta["quotes"] = dict(quotes)
        if len(quotes) >= 2:
            devs = [abs(v / price - 1) * 100 for k, v in quotes.items() if k != primary_name]
            meta["max_dev_pct"] = float(max(devs))
            meta["status"] = "bad" if meta["max_dev_pct"] > LIVE_BAD else ("warn" if meta["max_dev_pct"] > LIVE_WARN else "ok")
    return price, source, meta


def get_benchmark(symbol: str, years: float) -> Optional[pd.Series]:
    for p in _PROVIDERS:
        if not p.supports(symbol):
            continue
        try:
            df = p.history(symbol, years)
            if df is not None and not df.empty:
                return df["Close"].dropna()
        except Exception as exc:
            LOG.info("Benchmark %s dari %s gagal: %s", symbol, p.name, _mask(str(exc)))
    return None


# --------------------------------------------------------- fundamental ---
# (kunci info, toleransi relatif, selisih mutlak minimum agar dianggap konflik)
CHECK_FIELDS: List[Tuple[str, float, float]] = [
    ("trailingEps", 0.25, 0.0), ("bookValue", 0.25, 0.0), ("trailingPE", 0.35, 1.0),
    ("sharesOutstanding", 0.15, 0.0), ("returnOnEquity", 0.35, 0.05),
    ("trailingAnnualDividendRate", 0.30, 0.0), ("marketCap", 0.25, 0.0),
]
FILL_FIELDS = ["trailingEps", "bookValue", "trailingPE", "priceToBook", "sharesOutstanding", "returnOnEquity",
               "returnOnAssets", "profitMargins", "trailingAnnualDividendRate", "trailingAnnualDividendYield",
               "marketCap", "payoutRatio", "sector", "industry", "longName", "currency"]
CORE_KEYS = ("trailingEps", "bookValue", "trailingPE", "returnOnEquity", "profitMargins", "marketCap")


def _missing(info: Dict[str, Any], keys: Tuple[str, ...]) -> int:
    return sum(1 for k in keys if _num(info.get(k)) is None)


def merge_info(primary: Dict[str, Any], primary_name: str,
               secondaries: List[Tuple[str, Dict[str, Any]]]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Isi celah dari sumber lain; catat konflik. Nilai sumber utama tidak ditimpa."""
    info = dict(primary)
    filled: List[Dict[str, str]] = []
    conflicts: List[Dict[str, Any]] = []
    skipped: List[str] = []
    for name, sec in secondaries:
        cur_a, cur_b = (str(info.get("currency") or "").upper(), str(sec.get("currency") or "").upper())
        same_cur = not cur_a or not cur_b or cur_a == cur_b
        for key in FILL_FIELDS:
            if info.get(key) in (None, "") and sec.get(key) not in (None, ""):
                if key in ("trailingEps", "bookValue", "trailingAnnualDividendRate") and not same_cur:
                    continue                                   # beda mata uang: jangan campur
                info[key] = sec[key]
                filled.append({"field": key, "source": name})
        if not same_cur:
            skipped.append(f"{name}: mata uang {cur_b} berbeda dari {cur_a}; perbandingan nilai dilewati")
            continue
        for key, rel_tol, min_abs in CHECK_FIELDS:
            a, b = _num(primary.get(key)), _num(sec.get(key))
            if a is None or b is None or a == 0 or b == 0:
                continue
            rel = abs(a / b - 1)
            if rel > rel_tol and abs(a - b) > min_abs:
                conflicts.append({"field": key, "values": {primary_name: a, name: b}, "diff_pct": float(rel * 100)})
    return info, {"primary": primary_name, "secondary": [n for n, _ in secondaries], "filled": filled,
                  "conflicts": conflicts, "notes": skipped}


def get_info(ticker: str, validate: bool = False) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    cfg = settings()
    primary_info: Dict[str, Any] = {}
    primary_name = None
    errors: Dict[str, str] = {}
    for p in _PROVIDERS:
        if not (p.supports(ticker) and p.offers.get("overview")):
            continue
        try:
            info = p.overview(ticker)
        except Exception as exc:
            errors[p.name] = _mask(str(exc))[:120]
            continue
        if info:
            primary_info, primary_name = info, p.name
            break
        errors[p.name] = "kosong"
    if primary_name is None:
        return {}, {"primary": None, "secondary": [], "filled": [], "conflicts": [], "errors": errors, "notes": []}

    need_fill = _missing(primary_info, CORE_KEYS) >= 3
    secondaries: List[Tuple[str, Dict[str, Any]]] = []
    if validate or need_fill:
        others = [p for p in _PROVIDERS if p.name != primary_name and p.supports(ticker) and p.offers.get("overview")]
        for p in others[: max(0, cfg["validate_max"])]:
            try:
                sec = _cached(("overview", p.name, ticker), cfg["validate_ttl"], lambda p=p: p.overview(ticker))
                if sec:
                    secondaries.append((p.name, sec))
            except Exception as exc:
                errors[p.name] = _mask(str(exc))[:120]
    merged, meta = merge_info(primary_info, primary_name, secondaries)
    meta["errors"] = errors
    return merged, meta


def statements_fallback(ticker: str) -> Optional[StatementsAdapter]:
    """Dipakai hanya bila laporan keuangan Yahoo kosong."""
    for p in _PROVIDERS:
        if p.name == "yahoo" or not (p.supports(ticker) and p.offers.get("statements")):
            continue
        try:
            return _cached(("statements", p.name, ticker), 86400.0, lambda p=p: p.statements(ticker))
        except Exception as exc:
            LOG.info("Laporan keuangan dari %s gagal: %s", p.name, _mask(str(exc)))
    return None


# ----------------------------------------------------------- diagnosis ---
def diagnose(ticker: str) -> Dict[str, Any]:
    """Uji tiap sumber terhadap satu saham. Memakai kuota API Anda (beberapa panggilan per sumber)."""
    rows: List[Dict[str, Any]] = []

    def probe(p: Provider) -> Dict[str, Any]:
        r: Dict[str, Any] = {"source": p.name, "needs_key": p.key_env is not None, "key_set": p.configured(),
                             "mapped_symbol": p.map_symbol(ticker), "offers": dict(p.offers)}
        if not p.configured():
            r["status"] = "tanpa_kunci"
            return r
        if r["mapped_symbol"] is None:
            r["status"] = "tidak_didukung"
            r["note"] = "kombinasi bursa ini belum dipetakan; isi DATA_SYMBOL_MAP bila sumber ini mencakupnya"
            return r
        t0 = time.time()
        try:
            df = p.history(ticker, 1.0, recent=True)
            r["history"] = {"rows": int(len(df)), "last_date": str(df.index[-1].date()) if len(df) else None,
                            "last_close": float(df["Close"].iloc[-1]) if len(df) else None}
            r["status"] = "ok" if len(df) else "kosong"
        except Exception as exc:
            r["status"], r["error"] = "gagal", _mask(str(exc))[:140]
        r["latency_sec"] = round(time.time() - t0, 2)
        for kind in ("quote", "overview"):
            if p.offers.get(kind) and r["status"] == "ok":
                try:
                    v = p.quote(ticker) if kind == "quote" else p.overview(ticker)
                    r[kind] = v if kind == "quote" else {"fields": len(v)}
                except Exception as exc:
                    r[kind + "_error"] = _mask(str(exc))[:100]
        return r

    with ThreadPoolExecutor(max_workers=max(1, len(_PROVIDERS))) as pool:
        rows = list(pool.map(probe, _PROVIDERS))
    return {"ticker": ticker, "providers": rows,
            "tips": ["Sumber 'tanpa_kunci' butuh variabel environment (ALPHAVANTAGE_API_KEY, EODHD_API_KEY, TWELVEDATA_API_KEY).",
                     "Sumber 'tidak_didukung' belum punya pemetaan simbol untuk bursa ini.",
                     "Format respons non-Yahoo belum diuji ke server asli oleh pengembang; hasil di sini adalah uji pertama Anda."]}
