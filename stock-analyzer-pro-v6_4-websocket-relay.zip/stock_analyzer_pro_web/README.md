## Pembaruan v6.3 — Forex auto-refresh dan provider harga

- Panel Forex memuat ulang data dan analisis otomatis setiap 60 detik selama halaman terbuka.
- Jika `TWELVEDATA_API_KEY` diisi di environment, endpoint Forex mengambil candle dari Twelve Data terlebih dahulu; cakupan real-time, interval, dan batas kuota bergantung pada paket penyedia.
- Tanpa kunci, sistem memakai Yahoo Finance sebagai fallback dan secara jelas memberi label bahwa harga dapat tertunda. Refresh otomatis bukan jaminan harga tick real-time.
- Bot menampilkan EMA20/EMA50, RSI, MACD, support/resistance, heuristik Order Block, pola RBR/DBD/RBD/DBR, Fibonacci, dan strategi konfluensi yang tersedia pada endpoint.
- Untuk Vercel: buka Project Settings → Environment Variables, tambahkan `TWELVEDATA_API_KEY`, lalu redeploy. Jangan masukkan API key ke kode frontend atau unggah ke GitHub.
- Catatan: sinyal adalah bantuan analisis, bukan rekomendasi pasti. Validasi hasil pada akun demo dan data broker Anda sebelum mengambil keputusan.

# Stock Analyzer Pro Web v6.0

Gabungan **Stock Analyzer Pro** (teknikal, backtest, berita, kualitas data) dan **Stock Screener V5.1**
(riwayat fundamental tahunan + TTM, profil bank/non-bank), ditambah Monte Carlo dan skor per kelompok.

## Pembaruan v6.0 - Data multi-sumber
Sebelumnya semua data (harga, harga terakhir, fundamental, laporan keuangan) berasal dari Yahoo Finance saja.
Sekarang ada lapisan `data_sources.py`:
- **Harga: failover.** Sumber pertama yang berhasil menjadi sumber utama. Jika Yahoo gagal, kosong, atau datanya terlalu pendek,
  aplikasi pindah ke sumber berikutnya. Kegagalan sumber tercatat di panel dan menurunkan skor kualitas data sedikit.
- **Harga: validasi silang** (mode penuh saja). Sumber utama dibandingkan dengan sumber lain pada harga terakhir dan return harian
  90 sesi terakhir. Status ok/warn/bad masuk skor kualitas data dan tingkat keyakinan. Jika sumber utama menjadi pencilan dari
  dua sumber lain yang saling sepakat, sumber utama diganti. Selisih return pada tanggal ex-dividen/split bisa wajar (itu sebabnya hanya "warn").
- **Harga terakhir:** dibandingkan antar sumber (selisih >3% = warn, >10% = bad).
- **Fundamental:** Yahoo sebagai dasar; celah (mis. EPS atau nilai buku kosong) diisi dari sumber lain; selisih besar dicatat sebagai
  **konflik** dan menurunkan keyakinan harga wajar. Nilai sumber utama tidak ditimpa diam-diam, dan nilai beda mata uang tidak dicampur.
- **Laporan keuangan:** Yahoo; jika kosong, cadangan Alpha Vantage lewat adaptor (laporan tahunan saja, tanpa TTM).
- Panel "Sumber data" di kartu Risiko & Keyakinan, plus tombol **Uji sumber data** (`GET /api/sources?ticker=BBCA`) dan CLI `--diagnose-sources`.
- Sumber: `yahoo` (tanpa kunci), `eodhd` (EODHD_API_KEY), `twelvedata` (TWELVEDATA_API_KEY), `alphavantage` (ALPHAVANTAGE_API_KEY), `stooq` (tanpa kunci).
  Lihat `.env.example`. Kunci hanya dibaca dari environment, disamarkan di log, dan tidak pernah dikirim ke browser.

**Keterbatasan yang harus Anda ketahui:**
- Format respons semua sumber selain Yahoo ditulis dari dokumentasi publik dan **belum diuji ke server asli**. Gunakan **Uji sumber data**
  untuk memastikan tiap sumber benar-benar bekerja untuk saham Anda.
- **Cakupan Bursa Efek Indonesia tidak terjamin.** Pemetaan bawaan: EODHD `BBCA.JK`, Twelve Data `BBCA:IDX` (tergantung paket),
  Alpha Vantage dan Stooq tidak dipetakan untuk `.JK`. Jika sumber Anda memakai simbol lain, isi `DATA_SYMBOL_MAP`.
  Tanpa sumber tambahan yang mencakup saham BEI, harga tetap hanya dari Yahoo dan panel akan menyebut "belum divalidasi silang".
- Paket gratis punya batas panggilan (mis. Alpha Vantage 25/hari). Validator dipanggil hanya di mode penuh, maksimal `DATA_VALIDATE_MAX`
  sumber, dan hasilnya di-cache `DATA_VALIDATE_TTL` detik. Di serverless, cache tidak dibagi antar instance.
- Laporan keuangan dan berita tetap sebagian besar satu sumber (berita sudah memakai Yahoo + Google News RSS).
- Validasi silang menangkap data yang salah, bukan analisis yang salah; dua sumber bisa sama-sama keliru.

## Pembaruan v5.9.2
- Jika hanya satu metode yang lolos, panel kini menampilkan **angka indikatif** (jelas berlabel "1 metode, bukan harga wajar")
  beserta selisihnya ke harga sekarang, dan daftar alasan metode lain gagal langsung terbuka. Harga wajar tetap butuh minimal dua metode.
- Mode cepat menampilkan petunjuk bahwa metode PER/PBV historis dan DCF baru tersedia setelah analisis mendalam selesai.
- ROE yang tidak disediakan Yahoo kini diturunkan dari EPS / nilai buku per saham (hanya bila keduanya lolos pemeriksaan konsistensi),
  sehingga metode "PBV wajar dari ROE" lebih sering bisa dihitung untuk emiten kecil. Catatan metode menyebutkan bila ROE diturunkan.

## Pembaruan v5.9.1
- Presisi tampilan harga wajar mengikuti harga saham: di bawah 10 dua desimal, di bawah 100 satu desimal, selebihnya bilangan bulat.
  Saham Rp30 tidak lagi dibulatkan ke Rp29 atau Rp30 (selisih 1 sampai 3%).

## Pembaruan v5.9 - Harga Wajar Saham
- Modul baru `fair_value.py`: estimasi harga wajar dari beberapa metode independen, lalu **median tertimbang**
  (tahan terhadap satu metode yang meleset), rentang metode, harga masuk dengan margin keamanan, dan tingkat keyakinan estimasi.
- Metode: PER historis x EPS, PBV historis x nilai buku (memakai Referensi Valuasi Historis v5.1), Graham Number,
  PBV wajar dari ROE, model dividen (Gordon), dan DCF arus kas bebas 5 tahun (bukan untuk bank/keuangan).
- Metode yang datanya tidak ada atau tidak andal **dilewati dengan alasan**, bukan ditebak: perusahaan rugi, beda mata uang
  laporan vs perdagangan, EPS/PER/nilai buku tidak konsisten dengan harga, ROE/PBV ekstrem akibat buyback, FCF tidak positif.
  Estimasi di luar 0,1x - 10x harga atau outlier (>3x median metode lain) dikecualikan.
- Tabel **sensitivitas** (biaya modal x pertumbuhan jangka panjang). Himpunan metode dikunci sama dengan kasus dasar.
- Panel web "Harga Wajar Saham": rentang, penanda harga, tabel metode, asumsi yang bisa Anda ubah lalu **Hitung ulang**.
- Endpoint baru `GET /api/fairvalue?ticker=BBCA&ke=12&g=4.5&mos=25` (persen atau desimal). Parameter yang sama juga
  diterima `/api/analyze`. Perbandingan saham mendapat kolom **Vs wajar**.
- Riwayat fundamental sekarang membawa arus kas bebas (FCF) per tahun, dan laporan keuangan di-cache 30 menit sehingga hitung ulang cepat.
- **Tidak ikut skor secara bawaan** (sejalan dengan prinsip v5.1). Aktifkan lewat config `fair_value_in_score: true`.
  Bila harga >40% di atas harga wajar, muncul penanda risiko.
- Config: `terminal_growth` (id 4,5%, us 3%), `cost_of_equity`, `fair_value_mos`, `fair_value_weights`, `run_fair_value`.
- Perbaikan: uji versi API dan urutan kelompok pembanding WIRG (kelompok spesifik "solusi dan ekosistem digital" kini diperiksa lebih dulu,
  sesuai catatan v5.4 dan uji yang sudah ada).
- Keterbatasan: harga wajar adalah estimasi model dari data Yahoo, sangat sensitif pada asumsi, tidak memperhitungkan
  valuasi relatif terhadap sektor, dan **bukan target harga atau sinyal beli**.

## Pembaruan v5.8
- Endpoint saham serupa mengembalikan semua kandidat dalam kelompok yang dikurasi, tanpa memotong daftar menjadi lima.
- Panel menampilkan seluruh kandidat dalam daftar yang bisa dipilih; panel memungkinkan memilih seluruh kandidat yang tersedia. Endpoint tidak menetapkan batas jumlah saham buatan aplikasi; seluruh kandidat yang tersedia dalam kelompok kategori dapat dipilih. Kapasitas runtime, batas penyedia data, dan waktu eksekusi tetap berlaku.

## Pembaruan v5.4
- Memperluas daftar saham pembanding untuk WIRG.JK dengan kelompok solusi/ekosistem digital (DMMX, MCAS, NFCX, DIVA).
- Menambahkan nama perusahaan untuk pencarian saham populer terkait.
- Kandidat ini merupakan pembanding awal lintas model bisnis digital; periksa laporan segmen dan sumber pendapatan sebelum menyimpulkan valuasi relatif.

## Pembaruan v5.3
- Panel **Bandingkan dengan Saham Serupa** pada hasil analisis tunggal.
- Endpoint `/api/peers` menyediakan kandidat pembanding berdasarkan kelompok bisnis yang dikurasi untuk beberapa saham IDX dan AS.
- Bisa membandingkan satu saham dengan satu kandidat atau seluruh kandidat sekaligus (tanpa batas jumlah tetap dari aplikasi).
- Kandidat diberi catatan bahwa daftar bukan rekomendasi dan harus diverifikasi terhadap sektor/model bisnis terbaru.

## Pembaruan v5.2
- Saham dengan histori terbatas (minimal 30 sesi perdagangan) tetap bisa dianalisis untuk indikator dasar.
- SMA50/SMA200 yang belum punya cukup observasi ditandai tidak tersedia, bukan diperlakukan sebagai sinyal bearish palsu.
- Histori di bawah 250 sesi memberi peringatan dan penalti kualitas data; Monte Carlo dan backtest tetap dinyatakan tidak tersedia bila sampelnya tidak memadai.

## Pembaruan v5.1
- Sumber harga ditandai: `fast_info` atau close terakhir. Jika harga live gagal, kualitas data dikurangi dan UI tidak lagi menyebutnya harga live.
- Referensi valuasi historis PER/PBV ditampilkan hanya bila tersedia minimal 3 observasi historis yang layak. Referensi ini bukan nilai intrinsik dan tidak menjadi sinyal beli otomatis.
- Dashboard menampilkan metode estimasi dan disclaimer agar pengguna tidak salah menafsirkan angka valuasi.

## Yang dinilai
| Kelompok | Isi | Bobot default |
|---|---|---|
| Kinerja harga | CAGR, Sharpe, drawdown, volatilitas | 1.0 |
| Teknikal | SMA50/200, RSI, MACD, posisi di rentang, konfirmasi volume | 1.0 |
| Relatif vs indeks | selisih CAGR, beta, rezim pasar (indeks vs SMA200) | 0.6 |
| Fundamental snapshot | PER, PBV, ROE, ROA, net margin, DER (non-bank), dividen, PEG, PBV vs ROE | 1.4 |
| Riwayat fundamental | konsistensi laba, ROE rata-rata, CAGR laba & pendapatan, valuasi vs riwayat, CFO/laba | 1.2 |
| Berita | sentimen judul (kamus kata), bobot kecil | 0.3 |

Skor gabungan = rata-rata tertimbang skor tiap kelompok; kelompok tanpa data dilewati, bukan dihitung nol.
Bobot dan ambang vonis bisa diubah lewat file config (`group_weights`, `buy_threshold`, `hold_threshold`).

## Pengaman akurasi (bukan jaminan akurasi)
- **Backtest walk-forward** tanpa look-ahead, dengan uji signifikansi (p-value) dan perbandingan terhadap indeks.
  Hanya komponen harga/teknikal yang bisa diuji; fundamental dan berita historis point-in-time tidak tersedia gratis.
- **Monte Carlo** (block bootstrap): sebaran return 126 hari, skenario netral dan skenario tren historis. Bukan prediksi.
- **Validasi data**: data basi, celah, lonjakan mencurigakan, likuiditas, selisih harga live.
- **Tingkat keyakinan** TINGGI/SEDANG/RENDAH. Vonis LAYAK BELI otomatis turun ke TAHAN/PANTAU bila keyakinan RENDAH,
  ada berita berisiko tinggi, atau perusahaan rugi. Berita dan keyakinan hanya bisa menurunkan vonis.
- Profil **bank/keuangan**: DER konvensional dan net margin tidak dinilai; ambang ROA berbeda.
- Data kosong tidak pernah diisi asumsi.

Tidak ada alat yang bisa menjamin akurasi. Ini alat bantu keputusan, bukan nasihat keuangan.

## Pemakaian web
- Ketik kode atau nama (`BBCA`, `Telkom`, `AAPL`), pilih dari saran. Koma = bandingkan beberapa saham; aplikasi tidak menetapkan batas jumlah tetap.
- Alur dua tahap: **analisis cepat** tampil dalam beberapa detik, lalu **analisis mendalam** (riwayat fundamental,
  backtest, Monte Carlo, berita) menyusul. Jika tahap dua gagal/timeout, hasil cepat tetap tampil dengan keyakinan lebih rendah.
- Link langsung: `/#BBCA`.

## Lokal (Windows)
    python -m venv .venv
    .venv\Scripts\activate
    pip install -r requirements.txt
    python -m flask --app api.index run --debug

## CLI
    python stock_analyzer.py BBCA
    python stock_analyzer.py BBCA TLKM BBRI --fast        # peringkat cepat
    python stock_analyzer.py AAPL --market us --json
    python stock_analyzer.py BBCA --no-news --no-mc --time-budget 20

## API
- `GET /api/analyze?ticker=BBCA&market=auto|id|us&years=5&mode=fast|full` (+ `backtest|news|history|mc=0`)
- `GET /api/compare?tickers=BBCA,BBRI,BMRI`
- `GET /api/peers?ticker=BBCA&market=auto|id|us`
- `GET /api/fairvalue?ticker=BBCA&ke=12&g=4.5&mos=25`
- `GET /api/sources?ticker=BBCA` (uji sumber data; dibatasi frekuensi, opsional `SOURCES_TOKEN`)
- `GET /api/search?q=telkom`
- `GET /api/health`

## Vercel
Deploy seperti sebelumnya (`vercel.json` tidak berubah). Analisis mendalam butuh waktu beberapa puluh detik:
- Naikkan **Function Max Duration** di pengaturan proyek Vercel jika paket Anda mengizinkan.
- Set env `ANALYZER_TIME_BUDGET` (detik, default 40) sedikit di bawah batas durasi itu. Modul opsional yang melewati
  anggaran waktu dilewati dan keyakinan dikurangi, bukan error. Pada batas 10 detik, pakai nilai sekitar 6.
- Cache berjalan di memori instance (bukan disk), jadi aman di serverless tetapi tidak dibagi antar instance.

## Uji
    python -m unittest discover -s tests -v
Uji memakai yfinance tiruan (`tests/fake_yf.py`) sehingga berjalan tanpa internet.


## v5.8 — pembanding untuk ticker di luar daftar kurasi
- Endpoint `/api/peers` mencoba memakai metadata sektor/industri Yahoo Finance untuk mengarahkan saham ke kelompok pembanding.
- Jika sektor tidak dikenali atau metadata tidak tersedia, endpoint tetap mengembalikan kandidat dari pasar yang sama dengan peringatan bahwa kandidat bukan semuanya peer langsung.
- Respons menyertakan `match_method` agar UI/klien bisa membedakan kelompok kurasi, estimasi metadata, dan fallback pasar.
- Daftar kandidat tetap merupakan semesta simbol yang diketahui proyek, bukan katalog real-time seluruh saham bursa.

## Forex live streaming (local testing)

The Forex Analyzer now uses Twelve Data's WebSocket price stream for pushed tick updates instead of polling the analysis endpoint every 60 seconds. Historical candles and technical-analysis zones are loaded by `/api/forex`; live ticks update the current price and the forming chart candle.

**Security note:** the local-only endpoint `/api/forex-stream-config` sends the Twelve Data key to the browser because the provider requires it in the WebSocket URL. This endpoint returns 403 when `VERCEL` is set, and must not be enabled on a public deployment. For production, use a private streaming relay on a persistent server and keep the key server-side. Vercel serverless functions are not a suitable host for a persistent inbound WebSocket relay. Twelve Data WebSocket access and symbols depend on the user's plan.
